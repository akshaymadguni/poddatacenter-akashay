import { writeFile } from "fs/promises";
import seedPod from "@/lib/seedPod";
import { POD_DATA_FILE } from "@/lib/podFile";

// Overwrites public/pod-data.json with freshly randomized values
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  try {
    const data = seedPod();
    await writeFile(POD_DATA_FILE, JSON.stringify(data, null, 2) + "\n");
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
