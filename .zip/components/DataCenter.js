import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, OrbitControls, OrthographicCamera, PerspectiveCamera } from "@react-three/drei";
import { EffectComposer, Bloom, ToneMapping } from "@react-three/postprocessing";
import { ToneMappingMode } from "postprocessing";
import * as THREE from "three";
import ServerRack, { RACK } from "./ServerRack";
import { AisleBundle, BUNDLE_Y, RackLinks, Tray, TRAY_OFFSET, TRAY_RISE } from "./Cabling";
import { grilleTextures } from "./textures";
import DetailsPanel from "./DetailsPanel";
import { rackHealth } from "./health";
import { HudOverlay, HudProjector } from "./RackHuds";
import usePodData from "./usePodData";
import { LEGEND_GRADIENT, THERMAL_STOPS } from "./thermal";
import styles from "@/styles/DataCenter.module.css";

const COLD_AISLE = 2.4; // gap between the two rows (2x the original 1.2 m)
const RACK_GAP = 1.2; // gap between racks in the same row (R01–R02, R03–R04)
const AISLE_STRIPE = 0.08; // width of the black stripes marking the cold aisle edges
const RACK_PITCH = RACK.width + RACK_GAP;
const FLOOR_SIZE = 60;
const TILE = 0.6; // raised-floor tile size
const AISLE_TILE = TILE * 2; // cold-aisle tiles are double size; aisle width and length are whole multiples
const BUNDLE_LENGTH = 30; // runs well past the racks in both directions

const ROW_X = COLD_AISLE / 2 + RACK.depth / 2; // rack-center distance from the aisle centerline

const CAMERA_POSITION = [5, 4.5, 6];
const CAMERA_DISTANCE = Math.hypot(...CAMERA_POSITION);
const ORBIT_TARGET = [0, 1, 0];
const TOP_POSITION = [0, 20, 0];
const TOP_TARGET = [0, 0, 0];
const TOP_UP = [0, 0, -1]; // screen-up is -z when looking straight down
const DEFAULT_FOV = 45;
const FOCUS_MARGIN = 1.12; // breathing room around a focused rack
const FOCUS_MAX_DISTANCE = COLD_AISLE - 0.3; // stay inside the aisle, short of the opposite row

// Camera distance and fov that fit a whole rack face. If the ideal distance at the default fov
// would put the camera inside the opposite row, it stays in the aisle and widens the fov instead.
function fitRack(aspect) {
  const halfH = (RACK.height / 2) * FOCUS_MARGIN;
  const halfW = (RACK.width / 2) * FOCUS_MARGIN;
  const tanHalf = Math.tan(THREE.MathUtils.degToRad(DEFAULT_FOV / 2));
  const ideal = Math.max(halfH / tanHalf, halfW / (tanHalf * aspect));
  const distance = Math.min(ideal, FOCUS_MAX_DISTANCE);
  const fovFor = (half) => THREE.MathUtils.radToDeg(2 * Math.atan(half / distance));
  const fov = Math.max(DEFAULT_FOV, fovFor(halfH), fovFor(halfW / aspect));
  return { distance, fov };
}

// Both cameras stay mounted, each with its own controls, so the perspective view
// keeps its last position, rotation and target while the top view is active.
function Cameras({ top, extentX, extentZ, focus }) {
  const [persp, setPersp] = useState(null);
  const [ortho, setOrtho] = useState(null);
  const perspControls = useRef();
  const orthoControls = useRef();
  const flight = useRef(null);
  const { width, height } = useThree((s) => s.size);

  // Start a camera flight to the requested rack face
  useEffect(() => {
    if (!focus) return;
    const { distance, fov } = fitRack(width / height);
    const target = new THREE.Vector3(...focus.front);
    const position = target.clone().addScaledVector(new THREE.Vector3(...focus.normal), distance);
    // Look slightly down (~7°): a dead-level camera would sit past OrbitControls' maxPolarAngle
    position.y += distance * 0.12;
    flight.current = { target, position, fov };
    // `focus` changes identity per click; size is read but shouldn't retrigger a flight
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focus]);

  // Any user drag/zoom cancels a flight in progress
  useEffect(() => {
    const controls = perspControls.current;
    if (!controls) return;
    const cancel = () => (flight.current = null);
    controls.addEventListener("start", cancel);
    return () => controls.removeEventListener("start", cancel);
  }, [persp]);

  useFrame((_, delta) => {
    const f = flight.current;
    const controls = perspControls.current;
    if (!f || !persp || !controls) return;
    const k = 1 - Math.exp(-delta * 4);
    persp.position.lerp(f.position, k);
    controls.target.lerp(f.target, k);
    persp.fov += (f.fov - persp.fov) * k;
    persp.updateProjectionMatrix();
    controls.update();
    if (persp.position.distanceTo(f.position) < 0.005 && controls.target.distanceTo(f.target) < 0.005) {
      flight.current = null;
    }
  });

  // Fit every rack in the top view (also refits when the details panel resizes the canvas)
  useEffect(() => {
    if (!top || !ortho) return;
    ortho.zoom = Math.min(width / extentX, height / extentZ) * 0.9;
    ortho.updateProjectionMatrix();
  }, [top, ortho, width, height, extentX, extentZ]);

  // Re-center whenever the top view is entered
  useEffect(() => {
    if (!top || !ortho || !orthoControls.current) return;
    orthoControls.current.target.set(...TOP_TARGET);
    ortho.position.set(...TOP_POSITION);
    orthoControls.current.update();
  }, [top, ortho]);

  return (
    <>
      <PerspectiveCamera ref={setPersp} makeDefault={!top} position={CAMERA_POSITION} fov={DEFAULT_FOV} />
      <OrthographicCamera ref={setOrtho} makeDefault={top} position={TOP_POSITION} up={TOP_UP} near={0.1} far={50} />
      {persp && (
        <OrbitControls
          ref={perspControls}
          camera={persp}
          enabled={!top}
          target={ORBIT_TARGET}
          maxPolarAngle={Math.PI / 2.05}
          minDistance={2}
          maxDistance={CAMERA_DISTANCE * 1.2}
        />
      )}
      {ortho && (
        <OrbitControls
          ref={orthoControls}
          camera={ortho}
          enabled={top}
          enableRotate={false}
          screenSpacePanning
          target={TOP_TARGET}
        />
      )}
    </>
  );
}

function ViewToolbar({ top, thermal, racks, onToggleTop, onToggleThermal, onFocusRack }) {
  return (
    <>
      {thermal && (
        <div className={styles.legend}>
          <span>{THERMAL_STOPS[0][0]} °C</span>
          <span className={styles.legendBar} style={{ background: LEGEND_GRADIENT }} />
          <span>{THERMAL_STOPS.at(-1)[0]} °C</span>
        </div>
      )}
      <div className={styles.viewToolbar}>
        <button className={`${styles.toolButton} ${top ? styles.active : ""}`} onClick={onToggleTop} aria-pressed={top}>
          Top view
        </button>
        <button
          className={`${styles.toolButton} ${thermal ? styles.active : ""}`}
          onClick={onToggleThermal}
          aria-pressed={thermal}
        >
          Thermal
        </button>
        {racks.length > 0 && <span className={styles.divider} aria-hidden="true" />}
        {racks.map((rack) => (
          <button key={rack.id} className={styles.toolButton} onClick={() => onFocusRack(rack)} title={`Go to ${rack.name}`}>
            {rack.name}
          </button>
        ))}
      </div>
    </>
  );
}

function useGrille(holes, repeatX, repeatY) {
  const textures = useMemo(() => {
    const t = grilleTextures(holes);
    t.map.repeat.set(repeatX, repeatY);
    t.bump.repeat.set(repeatX, repeatY);
    return t;
  }, [holes, repeatX, repeatY]);
  useEffect(() => () => [textures.map, textures.bump].forEach((t) => t.dispose()), [textures]);
  return textures;
}

// Raised floor of steel grille tiles with square cooling holes; the cold aisle tiles are
// more open (higher airflow) than the rest
function Floor({ aisleLength }) {
  const floor = useGrille(12, FLOOR_SIZE / TILE, FLOOR_SIZE / TILE);
  const aisle = useGrille(18, COLD_AISLE / AISLE_TILE, aisleLength / AISLE_TILE);
  const steel = { metalness: 0.55, roughness: 0.5, clearcoat: 0.15, bumpScale: 1.5 };

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[FLOOR_SIZE, FLOOR_SIZE]} />
        <meshPhysicalMaterial map={floor.map} bumpMap={floor.bump} {...steel} />
      </mesh>

      {/* Cold aisle tiles, aligned to the floor grid */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]}>
        <planeGeometry args={[COLD_AISLE, aisleLength]} />
        <meshPhysicalMaterial map={aisle.map} bumpMap={aisle.bump} {...steel} />
      </mesh>

      {/* Black stripes along both edges of the cold aisle, marking it off from the rest of the floor */}
      {[-1, 1].map((s) => (
        <mesh key={s} rotation={[-Math.PI / 2, 0, 0]} position={[(s * COLD_AISLE) / 2, 0.002, 0]}>
          <planeGeometry args={[AISLE_STRIPE, aisleLength]} />
          <meshStandardMaterial color="#050505" roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

// Row A sits on -x facing +x, row B on +x facing -x; slots run along z
function rackTransform(rack, rowCount) {
  const z = (rack.slot - (rowCount - 1) / 2) * RACK_PITCH;
  return rack.row === "A"
    ? { position: [-ROW_X, 0, z], rotation: [0, Math.PI / 2, 0] }
    : { position: [ROW_X, 0, z], rotation: [0, -Math.PI / 2, 0] };
}

// Overhead tray above each row, with patch cables linking neighbouring racks
function RowCabling({ racks, rowCount }) {
  return ["A", "B"].map((row) => {
    const inRow = racks.filter((r) => r.row === row);
    if (!inRow.length) return null;
    const x = (row === "A" ? -1 : 1) * (ROW_X - TRAY_OFFSET);
    const half = (inRow.length * RACK_PITCH) / 2 + 0.6;
    const zs = inRow.map((r) => rackTransform(r, rowCount(row)).position[2]);
    return (
      <group key={row}>
        <Tray x={x} y={RACK.height + TRAY_RISE} from={-half} to={half} width={0.3} />
        <RackLinks x={x} rackTop={RACK.height} zs={zs} />
      </group>
    );
  });
}

export default function DataCenter() {
  const { data, error, loading, seeding, updatedAt, refresh, seed } = usePodData();
  const [selection, setSelection] = useState({ rackId: null, serverId: null });
  const [top, setTop] = useState(false);
  const [thermal, setThermal] = useState(false);
  const [focus, setFocus] = useState(null);
  const [openRackId, setOpenRackId] = useState(null);
  const hudElements = useRef({});

  const racks = data?.pod?.racks ?? [];
  const rowCount = (row) => racks.filter((r) => r.row === row).length;
  const maxRow = Math.max(rowCount("A"), rowCount("B"), 1);
  // Whole tile pairs so the perforated strip stays centered on the floor grid
  const aisleLength = Math.ceil((maxRow * RACK_PITCH) / (TILE * 2)) * TILE * 2;

  // Resolve against the latest data so the panel reflects file edits
  const selectedRack = racks.find((r) => r.id === selection.rackId) ?? null;
  const selectedServer = selectedRack?.servers.find((s) => s.id === selection.serverId) ?? null;

  const selectRack = (rackId) =>
    setSelection((s) => (s.rackId === rackId ? s : { rackId, serverId: null }));
  const selectServer = (rackId, serverId) =>
    setSelection((s) => (s.serverId === serverId ? { rackId, serverId: null } : { rackId, serverId }));
  // Only one rack open at a time: opening another closes the previous one,
  // and its pulled-out server slides back in because the selection moves with it
  const openRack = (rackId) => {
    setOpenRackId(rackId);
    selectRack(rackId);
  };
  // From a server card in the panel: open that rack and pull the server out
  // (clicking the already-selected card pushes it back in)
  const pickServer = (rackId, serverId) => {
    setOpenRackId(rackId);
    setSelection((s) => (s.serverId === serverId ? { rackId, serverId: null } : { rackId, serverId }));
  };
  const closeRack = (rackId) => {
    setOpenRackId((id) => (id === rackId ? null : id));
    setSelection((s) => (s.rackId === rackId ? { rackId, serverId: null } : s));
  };

  // Fly the perspective camera to face a rack's door, leaving the top view if needed
  const focusRack = (rack) => {
    const { position } = rackTransform(rack, rowCount(rack.row));
    const facing = rack.row === "A" ? 1 : -1; // doors face the aisle
    setTop(false);
    setFocus({
      front: [position[0] + (facing * RACK.depth) / 2, RACK.height / 2, position[2]],
      normal: [facing, 0, 0],
    });
  };

  const sortedRacks = [...racks].sort((a, b) => a.name.localeCompare(b.name));

  // Status tag per rack, anchored just above the top front edge (the door side, facing the aisle)
  const huds = racks.map((rack) => {
    const { position } = rackTransform(rack, rowCount(rack.row));
    const facing = rack.row === "A" ? 1 : -1;
    return {
      id: rack.id,
      name: rack.name,
      health: rackHealth(rack),
      anchor: [position[0] + (facing * RACK.depth) / 2, RACK.height + 0.16, position[2]],
    };
  });

  return (
    <div className={styles.root}>
      <header className={styles.topbar}>
        <h1 className={styles.brand}>POD A Digital Twin</h1>
        <div className={styles.sync}>
          {error ? (
            <span className={styles.error}>Load failed: {error}</span>
          ) : (
            updatedAt && <span>Synced {updatedAt.toLocaleTimeString()}</span>
          )}
          <button className={styles.button} onClick={refresh} disabled={loading || seeding}>
            {loading ? "Refreshing…" : "Refresh"}
          </button>
          <button className={styles.button} onClick={seed} disabled={loading || seeding}>
            {seeding ? "Seeding…" : "Seed"}
          </button>
        </div>
      </header>

      <div className={styles.split}>
        <div className={styles.viewport}>
          <Canvas>
            <color attach="background" args={["#ffffff"]} />

            <Cameras
              top={top}
              extentX={2 * (ROW_X + RACK.depth / 2) + 1.2}
              extentZ={maxRow * RACK_PITCH + 1.2}
              focus={focus}
            />

            {/* Lighting: city environment for reflections on the metals, soft ambient fill, and a
                point light over the cold aisle, halfway between the rack tops and the network line.
                The environment only lights the scene; the background stays plain white. */}
            {/* The preset's HDR is downloaded from a CDN; its own Suspense keeps the scene from waiting on it */}
            <Suspense fallback={null}>
              <Environment preset="city" />
            </Suspense>
            <ambientLight intensity={0.5} />
            {/* <pointLight position={[0, (RACK.height + BUNDLE_Y) / 2, 0]} intensity={30} /> */}

            <Floor aisleLength={aisleLength} />

            {racks.map((rack) => (
              <ServerRack
                key={rack.id}
                rack={rack}
                {...rackTransform(rack, rowCount(rack.row))}
                aisleOffset={ROW_X}
                thermal={thermal}
                open={openRackId === rack.id}
                selectedServerId={selection.rackId === rack.id ? selection.serverId : null}
                onOpen={openRack}
                onClose={closeRack}
                onSelectServer={selectServer}
              />
            ))}

            <HudProjector huds={huds} elements={hudElements} visible={!top} />
            <RowCabling racks={racks} rowCount={rowCount} />
            <AisleBundle length={BUNDLE_LENGTH} />

            <EffectComposer>
              {/* <Bloom mipmapBlur luminanceThreshold={1} intensity={1.2} /> */}
              {/* <ToneMapping mode={ToneMappingMode.ACES_FILMIC} /> */}
            </EffectComposer>
          </Canvas>

          {/* Rack status tags (hidden in the top view), positioned by HudProjector */}
          <HudOverlay huds={huds} elements={hudElements} />

          <ViewToolbar
            top={top}
            thermal={thermal}
            racks={sortedRacks}
            onToggleTop={() => setTop((t) => !t)}
            onToggleThermal={() => setThermal((t) => !t)}
            onFocusRack={focusRack}
          />
        </div>

        {/* Only mounted when something is selected, so the canvas takes the full width otherwise */}
        <DetailsPanel
          rack={selectedRack}
          server={selectedServer}
          onClose={() => setSelection({ rackId: null, serverId: null })}
          onPickServer={pickServer}
        />
      </div>
    </div>
  );
}
