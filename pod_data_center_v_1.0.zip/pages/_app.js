import { Inter, JetBrains_Mono, Orbitron } from "next/font/google";
import "@/styles/globals.css";

// Inter for interface text, JetBrains Mono for data values (IPs, IDs, readings), Orbitron for
// the sci-fi display type (brand, titles, buttons). All variable fonts, so no weight list.
const ui = Inter({ subsets: ["latin"], variable: "--font-ui" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });
const display = Orbitron({ subsets: ["latin"], variable: "--font-display" });

export default function App({ Component, pageProps }) {
  return (
    <div className={`${ui.variable} ${mono.variable} ${display.variable}`} style={{ height: "100%" }}>
      <Component {...pageProps} />
    </div>
  );
}
