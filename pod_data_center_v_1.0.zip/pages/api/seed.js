import seedPod, { reseedPod } from "@/lib/seedPod";
import { parseFloor, readFloorText, writeFloor } from "@/lib/podFile";

// POST /api/seed?floor=N: re-randomises the live readings of that floor only (statuses,
// temperatures, power) while keeping its layout fixed. Falls back to a brand-new floor if its
// file is invalid.
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  const floor = parseFloor(req.query.floor);
  if (!floor) return res.status(400).json({ error: "floor must be 1–10" });
  try {
    let current = null;
    try {
      current = JSON.parse(await readFloorText(floor));
    } catch {
      // unusable file: generate a full floor below
    }
    const data = current?.pod?.racks?.length ? reseedPod(current) : seedPod(floor);
    await writeFloor(floor, data);
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
