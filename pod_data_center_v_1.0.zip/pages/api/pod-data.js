import { parseFloor, readFloorText } from "@/lib/podFile";

// GET /api/pod-data?floor=N: that floor's pod (default floor 1). Reads the file on every request
// so edits show up without a rebuild.
export default async function handler(req, res) {
  const floor = parseFloor(req.query.floor);
  if (!floor) return res.status(400).json({ error: "floor must be 1–10" });
  try {
    const text = await readFloorText(floor);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Type", "application/json");
    res.status(200).send(text);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
