import { rackHealth } from "@/components/health";
import { latestTemp } from "@/components/temperature";
import { FLOORS, readFloorText } from "@/lib/podFile";

// GET /api/building: a light summary of every floor for the building view: each rack's place,
// health and hottest server, plus per-floor totals. (The full floor files are ~0.5 MB each, so
// the building view doesn't load them.)
export default async function handler(req, res) {
  try {
    const floors = await Promise.all(
      Array.from({ length: FLOORS }, async (_, i) => {
        const floor = i + 1;
        const { pod } = JSON.parse(await readFloorText(floor));
        const racks = pod.racks.map((r) => {
          const h = rackHealth(r);
          const active = r.servers.filter((s) => s.status === "active");
          return {
            id: r.id,
            row: r.row,
            slot: r.slot,
            level: h.level,
            temp: active.length ? Math.max(...active.map((s) => latestTemp(s.temperature))) : latestTemp(r.temperature),
          };
        });
        const servers = pod.racks.flatMap((r) => r.servers);
        const active = servers.filter((s) => s.status === "active");
        return {
          floor,
          name: pod.name,
          racks,
          alerts: racks.filter((r) => r.level === "alert").length,
          serversActive: active.length,
          serversTotal: servers.length,
          avgTemp: active.length ? active.reduce((sum, s) => sum + latestTemp(s.temperature), 0) / active.length : null,
          powerKw: pod.racks.reduce((sum, r) => sum + (r.powerKw ?? 0), 0),
        };
      })
    );
    res.setHeader("Cache-Control", "no-store");
    res.status(200).json({ floors });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
