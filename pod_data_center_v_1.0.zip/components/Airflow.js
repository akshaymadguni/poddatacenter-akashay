import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { isActive } from "./health";
import { RACK, U } from "./rackGeometry";
import { latestTemp } from "./temperature";
import { tempColor } from "./thermal";
import { DUCT_Y, hvacLayout } from "./HVAC";

// CFD view: one airflow simulation for the whole hall, so every rack, row and aisle shares the
// same air and their flows interact (plumes merge, intakes compete, air short-circuits through
// gaps between racks, cool exhaust is carried along by its neighbours' flow).
//
// The room is a coarse 3D grid (H-metre cells) holding air velocity and temperature, stepped with
// a simple stable-fluids scheme:
//   sources   – cold-aisle floor tiles blow supply air up at SUPPLY_TEMP
//   fans      – rack cells at the height of a running server pull air front → back; the rear cells
//               are held at that server's temperature, so exhaust matches its thermal colour
//   solids    – rack cells with no running server block the air (blanking panels / idle slots)
//   returns   – ceiling openings above the hot aisles and along the walls let air leave
//   buoyancy  – air warmer than the room accelerates up, cooler air sinks (Boussinesq, g·β·ΔT)
//   advection – velocity and temperature are carried along by the flow (semi-Lagrangian)
//   pressure  – a Gauss–Seidel pressure solve keeps the flow mass-conserving, so pushing air in
//               one place draws it in somewhere else
// Smoke puffs and line trails are massless tracers carried by this field and coloured by the air
// temperature where they are.

const H = 0.35; // cell size (m)
const CEILING_Y = RACK.height + 2.1;
const SUPPLY_TEMP = 18; // °C from the floor tiles
const ROOM_TEMP = 24; // buoyancy reference
const TILE_SPEED = 0.45; // m/s up through the perforated tiles
const FAN_SPEED = 1.4; // m/s through a running server
const FAN_SUCTION = 2.2; // m/s up into each inline HVAC return fan
const BUOYANCY = 9.81 / 300; // g·β for air, m/s² per °C
const PRESSURE_ITERS = 10;
const SOR = 1.7; // over-relaxation for the pressure solve
const MAX_SPEED = 3;
const TIME_SCALE = 0.7; // animation slower than real time, so the flow stays readable
const MAX_DT = 0.08;
const STEP_EVERY = 2; // frames per simulation step (the step covers all of them)
const WARMUP_STEPS = 50; // pre-run so the flow is developed when CFD opens

const FLUID = 0;
const SOLID = 1;
const FAN = 2;
const TILE = 3;

// ---------- Room setup ----------

function buildRoom({ racks, coldAislesX, coldAisle, hotAislesX, hotAisle, aisleLength, floorHalfX, hvac }) {
  const { depth, width, height } = RACK;
  const ox = -floorHalfX;
  const oz = -aisleLength / 2;
  const nx = Math.ceil((2 * floorHalfX) / H);
  const ny = Math.ceil(CEILING_Y / H);
  const nz = Math.ceil(aisleLength / H);
  const n = nx * ny * nz;
  const idx = (i, j, k) => i + nx * (j + ny * k);
  const cx = (i) => ox + (i + 0.5) * H;
  const cy = (j) => (j + 0.5) * H;
  const cz = (k) => oz + (k + 0.5) * H;

  const type = new Uint8Array(n);
  const fix = { u: new Float32Array(n), v: new Float32Array(n), w: new Float32Array(n), T: new Float32Array(n).fill(NaN) };

  // Racks: fan cells where a running server sits, solid elsewhere inside the cabinet
  for (const { rack, x: rx, z: rz, facing: f } of racks) {
    const rackU = rack.totalU ?? 42;
    const base = (height - rackU * U) / 2;
    const running = rack.servers
      .filter(isActive)
      .map((s) => ({ y0: base + (s.uPosition - 1) * U, y1: base + (s.uPosition - 1 + s.heightU) * U, t: latestTemp(s.temperature) }));
    for (let k = 0; k < nz; k++) {
      if (Math.abs(cz(k) - rz) > width / 2) continue;
      for (let i = 0; i < nx; i++) {
        const dx = cx(i) - rx;
        if (Math.abs(dx) > depth / 2) continue;
        for (let j = 0; j < ny && cy(j) < height; j++) {
          const id = idx(i, j, k);
          const lo = cy(j) - H / 2;
          const hi = cy(j) + H / 2;
          const here = running.filter((s) => s.y1 > lo && s.y0 < hi);
          if (!here.length) {
            type[id] = SOLID;
            continue;
          }
          // Fan strength scales with how much of the cell's height is running servers
          const cover = here.reduce((sum, s) => sum + Math.min(s.y1, hi) - Math.max(s.y0, lo), 0) / H;
          type[id] = FAN;
          fix.u[id] = -f * FAN_SPEED * Math.min(1, cover + 0.25); // doors face +f, so air moves −f
          if (dx * -f > depth * 0.15) fix.T[id] = Math.max(...here.map((s) => s.t)); // rear: exhaust temp
        }
      }
    }
  }

  // Perforated tiles along each cold aisle floor
  const tiles = [];
  for (let k = 1; k < nz - 1; k++) {
    for (let i = 0; i < nx; i++) {
      if (!coldAislesX.some((ax) => Math.abs(cx(i) - ax) < coldAisle / 2 - 0.05)) continue;
      const id = idx(i, 0, k);
      if (type[id] !== FLUID) continue;
      type[id] = TILE;
      fix.v[id] = TILE_SPEED;
      fix.T[id] = SUPPLY_TEMP;
      tiles.push(id);
    }
  }

  // Ceiling returns: the intake grilles of the HVAC return ducts (0.9 m wide) over the hot aisles
  // and along the walls behind the outermost rows
  const returnsX = [...hotAislesX, -(floorHalfX - 0.45), floorHalfX - 0.45];
  const vent = new Uint8Array(nx * nz);
  for (let k = 0; k < nz; k++) {
    for (let i = 0; i < nx; i++) {
      const x = cx(i);
      if (returnsX.some((rx) => Math.abs(x - rx) < 0.45 + H * 0.5)) {
        vent[i + nx * k] = 1;
      }
    }
  }

  // Inline return-fan units: strong suction just below each one, so nearby air is visibly drawn
  // up into the duct (the top-layer cell pulls hardest, the one below it pulls too)
  const hvacFans = []; // [cell, nominal speed], scaled live by the toolbar's fan speed
  for (const dx of hvac.ducts) {
    for (const uz of hvac.units) {
      for (let k = 0; k < nz; k++) {
        if (Math.abs(cz(k) - uz) > 0.7) continue;
        for (let i = 0; i < nx; i++) {
          if (Math.abs(cx(i) - dx) > 0.55) continue;
          [[ny - 1, FAN_SUCTION], [ny - 2, FAN_SUCTION * 0.5]].forEach(([j, speed]) => {
            const id = idx(i, j, k);
            if (type[id] !== FLUID) return;
            type[id] = FAN;
            fix.v[id] = speed;
            hvacFans.push([id, speed]);
          });
        }
      }
    }
  }

  // The room's real walls (the grid is rounded up to whole cells, so it runs slightly past them)
  const walls = { x0: -floorHalfX, x1: floorHalfX, z0: -aisleLength / 2, z1: aisleLength / 2 };

  return { nx, ny, nz, n, ox, oz, idx, type, fix, tiles, vent, walls, hvacFans };
}

// ---------- Simulation ----------

function createSim(room) {
  const { n } = room;
  const sim = {
    room,
    u: new Float32Array(n),
    v: new Float32Array(n),
    w: new Float32Array(n),
    T: new Float32Array(n).fill(ROOM_TEMP),
    p: new Float32Array(n),
    u2: new Float32Array(n),
    v2: new Float32Array(n),
    w2: new Float32Array(n),
    T2: new Float32Array(n),
    div: new Float32Array(n),
  };
  applyFixed(sim);
  for (let s = 0; s < WARMUP_STEPS; s++) step(sim, 0.1);
  return sim;
}

function applyFixed(sim) {
  const { type, fix, n } = sim.room;
  for (let id = 0; id < n; id++) {
    const t = type[id];
    if (t === FLUID) continue;
    if (t === SOLID) {
      sim.u[id] = sim.v[id] = sim.w[id] = 0;
      continue;
    }
    sim.u[id] = fix.u[id];
    sim.v[id] = fix.v[id];
    sim.w[id] = fix.w[id];
    if (!Number.isNaN(fix.T[id])) sim.T[id] = fix.T[id];
  }
}

// Trilinear sample of a cell-centred field at world (x, y, z), clamped to the room
function sample(sim, f, x, y, z) {
  const { nx, ny, nz, ox, oz } = sim.room;
  let gx = (x - ox) / H - 0.5;
  let gy = y / H - 0.5;
  let gz = (z - oz) / H - 0.5;
  gx = gx < 0 ? 0 : gx > nx - 1.001 ? nx - 1.001 : gx;
  gy = gy < 0 ? 0 : gy > ny - 1.001 ? ny - 1.001 : gy;
  gz = gz < 0 ? 0 : gz > nz - 1.001 ? nz - 1.001 : gz;
  const i = gx | 0;
  const j = gy | 0;
  const k = gz | 0;
  const fx = gx - i;
  const fy = gy - j;
  const fz = gz - k;
  const a = i + nx * (j + ny * k);
  const sx = 1;
  const sy = nx;
  const sz = nx * ny;
  const c00 = f[a] + (f[a + sx] - f[a]) * fx;
  const c10 = f[a + sy] + (f[a + sy + sx] - f[a + sy]) * fx;
  const c01 = f[a + sz] + (f[a + sz + sx] - f[a + sz]) * fx;
  const c11 = f[a + sz + sy] + (f[a + sz + sy + sx] - f[a + sz + sy]) * fx;
  const c0 = c00 + (c10 - c00) * fy;
  const c1 = c01 + (c11 - c01) * fy;
  return c0 + (c1 - c0) * fz;
}

function step(sim, dt) {
  const { nx, ny, nz, n, ox, oz, type, vent } = sim.room;
  const { u, v, w, T, p, u2, v2, w2, T2, div } = sim;
  const sy = nx;
  const sz = nx * ny;

  // Buoyancy: warm air accelerates up, cool air sinks
  for (let id = 0; id < n; id++) if (type[id] === FLUID) v[id] += BUOYANCY * (T[id] - ROOM_TEMP) * dt;

  // Semi-Lagrangian advection of velocity and temperature
  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const id = i + nx * (j + ny * k);
        const x = ox + (i + 0.5) * H - u[id] * dt;
        const y = (j + 0.5) * H - v[id] * dt;
        const z = oz + (k + 0.5) * H - w[id] * dt;
        T2[id] = sample(sim, T, x, y, z);
        if (type[id] === FLUID) {
          u2[id] = sample(sim, u, x, y, z) * 0.998;
          v2[id] = sample(sim, v, x, y, z) * 0.998;
          w2[id] = sample(sim, w, x, y, z) * 0.998;
        } else {
          u2[id] = u[id];
          v2[id] = v[id];
          w2[id] = w[id];
        }
      }
    }
  }
  sim.u = u2;
  sim.u2 = u;
  sim.v = v2;
  sim.v2 = v;
  sim.w = w2;
  sim.w2 = w;
  sim.T = T2;
  sim.T2 = T;
  applyFixed(sim);

  const U_ = sim.u;
  const V_ = sim.v;
  const W_ = sim.w;

  // Divergence (walls carry no flow; returns let air out the top freely)
  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const id = i + nx * (j + ny * k);
        if (type[id] !== FLUID) continue;
        const ue = i < nx - 1 ? U_[id + 1] : 0;
        const uw = i > 0 ? U_[id - 1] : 0;
        const vn = j < ny - 1 ? V_[id + sy] : vent[i + nx * k] ? V_[id] : 0;
        const vs = j > 0 ? V_[id - sy] : 0;
        const wf = k < nz - 1 ? W_[id + sz] : 0;
        const wb = k > 0 ? W_[id - sz] : 0;
        div[id] = (ue - uw + vn - vs + wf - wb) / (2 * H);
      }
    }
  }

  // Pressure (SOR Gauss–Seidel, warm-started from the previous step). Non-fluid neighbours and
  // walls are zero-gradient; the open ceiling over a return is p = 0
  const h2 = H * H;
  for (let it = 0; it < PRESSURE_ITERS; it++) {
    for (let k = 0; k < nz; k++) {
      for (let j = 0; j < ny; j++) {
        for (let i = 0; i < nx; i++) {
          const id = i + nx * (j + ny * k);
          if (type[id] !== FLUID) continue;
          const pc = p[id];
          const pe = i < nx - 1 && type[id + 1] === FLUID ? p[id + 1] : pc;
          const pw = i > 0 && type[id - 1] === FLUID ? p[id - 1] : pc;
          const pn = j < ny - 1 ? (type[id + sy] === FLUID ? p[id + sy] : pc) : vent[i + nx * k] ? 0 : pc;
          const ps = j > 0 && type[id - sy] === FLUID ? p[id - sy] : pc;
          const pf = k < nz - 1 && type[id + sz] === FLUID ? p[id + sz] : pc;
          const pb = k > 0 && type[id - sz] === FLUID ? p[id - sz] : pc;
          const gs = (pe + pw + pn + ps + pf + pb - div[id] * h2) / 6;
          p[id] = pc + SOR * (gs - pc);
        }
      }
    }
  }

  // Subtract the pressure gradient so the flow is (nearly) divergence-free
  for (let k = 0; k < nz; k++) {
    for (let j = 0; j < ny; j++) {
      for (let i = 0; i < nx; i++) {
        const id = i + nx * (j + ny * k);
        if (type[id] !== FLUID) continue;
        const pc = p[id];
        const pe = i < nx - 1 && type[id + 1] === FLUID ? p[id + 1] : pc;
        const pw = i > 0 && type[id - 1] === FLUID ? p[id - 1] : pc;
        const pn = j < ny - 1 ? (type[id + sy] === FLUID ? p[id + sy] : pc) : vent[i + nx * k] ? 0 : pc;
        const ps = j > 0 && type[id - sy] === FLUID ? p[id - sy] : pc;
        const pf = k < nz - 1 && type[id + sz] === FLUID ? p[id + sz] : pc;
        const pb = k > 0 && type[id - sz] === FLUID ? p[id - sz] : pc;
        let a = U_[id] - (pe - pw) / (2 * H);
        let b = V_[id] - (pn - ps) / (2 * H);
        let c = W_[id] - (pf - pb) / (2 * H);
        a = a > MAX_SPEED ? MAX_SPEED : a < -MAX_SPEED ? -MAX_SPEED : a;
        b = b > MAX_SPEED ? MAX_SPEED : b < -MAX_SPEED ? -MAX_SPEED : b;
        c = c > MAX_SPEED ? MAX_SPEED : c < -MAX_SPEED ? -MAX_SPEED : c;
        // Solid walls and floor: air slides along them but never through
        if (i === 0 || i === nx - 1) a = 0;
        if (k === 0 || k === nz - 1) c = 0;
        if (j === 0 && b < 0) b = 0;
        U_[id] = a;
        V_[id] = b;
        W_[id] = c;
      }
    }
  }
}

// ---------- Tracers (shared by smoke and lines) ----------
// Tracers ride the room's air. When one reaches a return grille it is sucked into the HVAC duct
// above and follows the ducting: up into the duct, along it to the header, across to the outlet,
// up the exhaust stack and out of the exhaust fan as a dispersing plume; then it is recycled.

const MAX_AGE = 40; // s before a tracer still in the room is recycled
const DUCT_SPEED = 3.2; // m/s along the ductwork
const PLUME_RISE = 12; // m of the shared riser the air is followed up (to the roof's main exhaust)
const WALL_GAP = 0.05; // tracers keep this far inside the walls

function makeTracers(count) {
  return {
    count,
    pos: new Float32Array(count * 3),
    age: new Float32Array(count),
    life: new Float32Array(count),
    temp: new Float32Array(count),
    seed: Float32Array.from({ length: count }, (_, i) => (i * 0.618034) % 1),
    respawned: new Uint8Array(count),
    // Duct route state: inDuct flag, distance travelled, the route's waypoints (6 × xyz)
    inDuct: new Uint8Array(count),
    dist: new Float32Array(count),
    route: new Float32Array(count * 18),
  };
}

// New tracer just above a random floor tile, so everything starts as supply air
function spawn(sim, tr, i) {
  const { tiles, nx, ny, ox, oz } = sim.room;
  const id = tiles[(Math.random() * tiles.length) | 0];
  const ci = id % nx;
  const ck = Math.floor(id / (nx * ny));
  tr.pos[i * 3] = ox + (ci + Math.random()) * H;
  tr.pos[i * 3 + 1] = 0.05 + Math.random() * 0.25;
  tr.pos[i * 3 + 2] = oz + (ck + Math.random()) * H;
  tr.age[i] = 0;
  tr.life[i] = MAX_AGE * (0.6 + 0.4 * Math.random());
  tr.temp[i] = SUPPLY_TEMP;
  tr.inDuct[i] = 0;
  tr.respawned[i] = 1;
}

// Sucked into the nearest return duct: lay out its route through the ducting to the exhaust
function enterDuct(sim, tr, i, x, y, z) {
  const { ducts, headerZ, outletX, stackTop } = sim.hvac;
  let dx = ducts[0];
  for (const d of ducts) if (Math.abs(d - x) < Math.abs(dx - x)) dx = d;
  // A random lane inside the duct cross-section, so the flow fills it instead of one line
  const ox = (Math.random() - 0.5) * 0.6;
  const oy = (Math.random() - 0.5) * 0.3;
  const oz = (Math.random() - 0.5) * 0.6;
  const DY = sim.hvac.ductY;
  const pts = [
    [x, y, z],
    [dx + ox, DY + oy, z],
    [dx + ox, DY + oy, headerZ + oz],
    [outletX + ox, DY + oy, headerZ + oz],
    [outletX + ox, stackTop, headerZ + oz],
    [outletX + ox * 0.8, stackTop + PLUME_RISE, headerZ + oz * 0.8], // up the riser to the main exhaust
  ];
  tr.route.set(pts.flat(), i * 18);
  tr.inDuct[i] = 1;
  tr.dist[i] = 0;
}

// Position along a tracer's duct route; returns false once it has left the exhaust plume
function followDuct(tr, i, dt) {
  const r = tr.route;
  const b = i * 18;
  // Slower while rising into the duct, fast inside the ducting and quickest up the riser
  let d = tr.dist[i];
  let rem = d;
  for (let leg = 0; leg < 5; leg++) {
    const a = b + leg * 3;
    const len = Math.hypot(r[a + 3] - r[a], r[a + 4] - r[a + 1], r[a + 5] - r[a + 2]);
    if (rem <= len) {
      // Duct and exhaust speeds follow the fan speed (a little natural draft even when stopped)
      const fan = Math.max(0.15, tr.fanSpeed ?? 1);
      const speed = (leg === 0 ? 1.2 : leg === 4 ? DUCT_SPEED * 1.4 : DUCT_SPEED) * fan;
      tr.dist[i] = d + speed * dt;
      const w = len ? rem / len : 1;
      tr.pos[i * 3] = r[a] + (r[a + 3] - r[a]) * w;
      tr.pos[i * 3 + 1] = r[a + 1] + (r[a + 4] - r[a + 1]) * w;
      tr.pos[i * 3 + 2] = r[a + 2] + (r[a + 5] - r[a + 2]) * w;
      return true;
    }
    rem -= len;
  }
  return false;
}

// Move every tracer with the air (midpoint integration), hand the ones reaching a return grille
// over to the ducting, and recycle the ones that are done
function advectTracers(sim, tr, dt) {
  const { nx, ny, ox, oz, type, idx, vent, walls } = sim.room;
  tr.fanSpeed = sim.fanSpeed;
  for (let i = 0; i < tr.count; i++) {
    tr.respawned[i] = 0;
    tr.age[i] += dt;

    if (tr.inDuct[i]) {
      if (!followDuct(tr, i, dt)) spawn(sim, tr, i);
      else tr.temp[i] -= dt * 0.4; // cools a little on its way out
      continue;
    }

    let x = tr.pos[i * 3];
    let y = tr.pos[i * 3 + 1];
    let z = tr.pos[i * 3 + 2];
    const mx = x + sample(sim, sim.u, x, y, z) * dt * 0.5;
    const my = y + sample(sim, sim.v, x, y, z) * dt * 0.5;
    const mz = z + sample(sim, sim.w, x, y, z) * dt * 0.5;
    x += sample(sim, sim.u, mx, my, mz) * dt;
    y += sample(sim, sim.v, mx, my, mz) * dt;
    z += sample(sim, sim.w, mx, my, mz) * dt;
    if (y < 0.03) y = 0.03;
    // Walls: a tracer that reaches one stays in the room and slides along it
    x = x < walls.x0 + WALL_GAP ? walls.x0 + WALL_GAP : x > walls.x1 - WALL_GAP ? walls.x1 - WALL_GAP : x;
    z = z < walls.z0 + WALL_GAP ? walls.z0 + WALL_GAP : z > walls.z1 - WALL_GAP ? walls.z1 - WALL_GAP : z;
    const gi = Math.floor((x - ox) / H);
    const gj = Math.floor(y / H);
    const gk = Math.floor((z - oz) / H);
    if (tr.age[i] > tr.life[i] || (gj < ny && type[idx(gi, gj, gk)] === SOLID)) {
      spawn(sim, tr, i);
      continue;
    }
    if (y >= CEILING_Y - 0.15) {
      if (vent[gi + nx * gk]) {
        enterDuct(sim, tr, i, x, CEILING_Y - 0.15, z);
        followDuct(tr, i, 0);
        continue;
      }
      y = CEILING_Y - 0.15; // hugs the ceiling until it finds a return
    }
    tr.pos[i * 3] = x;
    tr.pos[i * 3 + 1] = y;
    tr.pos[i * 3 + 2] = z;
    tr.temp[i] = sample(sim, sim.T, x, y, z);
  }
}

// Start every tracer at the floor and run them for a while, so the room (and the ducts) are
// already full of flow when CFD opens rather than showing one wave rising from the tiles
function seededTracers(sim, count) {
  const tr = makeTracers(count);
  for (let i = 0; i < count; i++) {
    spawn(sim, tr, i);
    tr.life[i] *= Math.random(); // staggered recycling spreads the tracers through the cycle
  }
  for (let s = 0; s < 70; s++) advectTracers(sim, tr, 0.3);
  return tr;
}

const noRaycast = () => null;

// Temperature → linear RGB lookup (0.25 °C steps), so per-vertex colouring avoids calling
// tempColor tens of thousands of times a frame
const LUT_MIN = 10;
const LUT_STEP = 0.25;
const LUT = (() => {
  const c = new THREE.Color();
  const size = Math.ceil((100 - LUT_MIN) / LUT_STEP) + 1;
  const out = new Float32Array(size * 3);
  for (let i = 0; i < size; i++) {
    tempColor(LUT_MIN + i * LUT_STEP, c);
    out.set([c.r, c.g, c.b], i * 3);
  }
  return out;
})();
const LUT_LAST = LUT.length / 3 - 1;
function writeColor(arr, at, temp) {
  let i = Math.round((temp - LUT_MIN) / LUT_STEP);
  i = i < 0 ? 0 : i > LUT_LAST ? LUT_LAST : i;
  arr[at] = LUT[i * 3];
  arr[at + 1] = LUT[i * 3 + 1];
  arr[at + 2] = LUT[i * 3 + 2];
}

// ---------- Smoke mode ----------
// Wispy, temperature-coloured puffs: each sprite's outline and inner density come from animated
// fractal noise, so they read as ragged, churning smoke; they grow and thin out with age.

const SMOKE_COUNT = 12000; // denser smoke
const PUFF_SIZE = [0.25, 1.0]; // world-size sprite (m), young → old

const smokeVertex = /* glsl */ `
  attribute float size;
  attribute float alpha;
  attribute float puffSeed;
  attribute float age;
  uniform float uScale;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vSeed;
  varying float vAge;
  void main() {
    vColor = color;
    vAlpha = alpha;
    vSeed = puffSeed;
    vAge = age;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = size * uScale / -mv.z;
    gl_Position = projectionMatrix * mv;
  }
`;

const smokeFragment = /* glsl */ `
  uniform float uTime;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vSeed;
  varying float vAge;

  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
  }
  float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 4; i++) {
      v += a * noise(p);
      p = p * 2.03 + vec2(1.7, 9.2);
      a *= 0.5;
    }
    return v;
  }

  void main() {
    vec2 p = gl_PointCoord - 0.5;
    float ang = vSeed * 6.2832 + uTime * (vSeed - 0.5) * 0.6;
    p = mat2(cos(ang), -sin(ang), sin(ang), cos(ang)) * p;
    vec2 q = p * 3.0 + vSeed * 37.0;
    vec2 warp = vec2(fbm(q + uTime * 0.25), fbm(q + 5.2 - uTime * 0.2));
    float n = fbm(q + warp * 1.6 + vec2(0.0, -uTime * 0.3));
    float r = length(p) * 2.0;
    float body = 1.0 - smoothstep(0.25, 1.0, r + (n - 0.5) * (0.9 + vAge * 0.6));
    float density = smoothstep(0.25 + vAge * 0.2, 0.85, n);
    float a = body * density * vAlpha;
    if (a < 0.003) discard;
    gl_FragColor = vec4(vColor * (0.7 + 0.5 * n), a);
  }
`;

function Smoke({ sim }) {
  const tr = useMemo(() => seededTracers(sim, SMOKE_COUNT), [sim]);

  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(tr.pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(new Float32Array(tr.count * 3), 3));
    g.setAttribute("size", new THREE.BufferAttribute(new Float32Array(tr.count), 1));
    g.setAttribute("alpha", new THREE.BufferAttribute(new Float32Array(tr.count), 1));
    g.setAttribute("age", new THREE.BufferAttribute(new Float32Array(tr.count), 1));
    g.setAttribute("puffSeed", new THREE.BufferAttribute(tr.seed, 1));
    return g;
  }, [tr]);
  useEffect(() => () => geometry.dispose(), [geometry]);

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uScale: { value: 800 }, uTime: { value: 0 } },
        vertexShader: smokeVertex,
        fragmentShader: smokeFragment,
        vertexColors: true,
        transparent: true,
        depthWrite: false,
        toneMapped: false,
      }),
    []
  );
  useEffect(() => () => material.dispose(), [material]);

  useFrame(({ size, camera }) => {
    const dt = sim.lastDt;
    if (!dt) return;
    advectTracers(sim, tr, dt);
    material.uniforms.uTime.value = sim.time;
    material.uniforms.uScale.value = size.height / (2 * Math.tan(THREE.MathUtils.degToRad((camera.fov ?? 45) / 2)));

    const col = geometry.attributes.color.array;
    const siz = geometry.attributes.size.array;
    const alp = geometry.attributes.alpha.array;
    const ages = geometry.attributes.age.array;
    for (let i = 0; i < tr.count; i++) {
      writeColor(col, i * 3, tr.temp[i]);
      const a = Math.min(1, tr.age[i] / 14); // grows and frays as it mixes
      siz[i] = PUFF_SIZE[0] + (PUFF_SIZE[1] - PUFF_SIZE[0]) * Math.sqrt(a);
      // Near a wall the puff shrinks, so the sprite never pokes through it
      if (!tr.inDuct[i]) {
        const { walls } = sim.room;
        const px = tr.pos[i * 3];
        const pz = tr.pos[i * 3 + 2];
        const wall = Math.min(px - walls.x0, walls.x1 - px, pz - walls.z0, walls.z1 - pz);
        siz[i] = Math.min(siz[i], 0.1 + wall * 1.6);
      }
      // Squeezed small inside the ducting; billows out again in the exhaust plume
      if (tr.inDuct[i]) siz[i] = 0.28;
      ages[i] = a;
      const fadeIn = Math.min(1, tr.age[i] / 0.8);
      const fadeOut = Math.min(1, (tr.life[i] - tr.age[i]) / 4);
      alp[i] = tr.inDuct[i] ? 0.4 : 0.32 * fadeIn * fadeOut * (1 - 0.45 * a);
    }
    for (const name of ["position", "color", "size", "alpha", "age"]) geometry.attributes[name].needsUpdate = true;
  });

  return <points geometry={geometry} material={material} raycast={noRaycast} frustumCulled={false} />;
}

// ---------- Lines mode ----------
// Streak trails: each tracer leaves a fading line of its recent positions, coloured by the air
// temperature it passed through.

const LINE_COUNT = 3500;
const TRAIL = 12; // points per trail
const TRAIL_DT = 0.12; // s between trail points

const lineVertex = /* glsl */ `
  attribute float alpha;
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    vColor = color;
    vAlpha = alpha;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const lineFragment = /* glsl */ `
  varying vec3 vColor;
  varying float vAlpha;
  void main() {
    gl_FragColor = vec4(vColor * 1.1, vAlpha);
  }
`;

function Lines({ sim }) {
  const tr = useMemo(() => seededTracers(sim, LINE_COUNT), [sim]);
  // Trail history: position + temperature per point, newest first
  const hist = useMemo(() => {
    const pos = new Float32Array(tr.count * TRAIL * 3);
    const temp = new Float32Array(tr.count * TRAIL);
    for (let i = 0; i < tr.count; i++) {
      for (let s = 0; s < TRAIL; s++) {
        pos.set(tr.pos.subarray(i * 3, i * 3 + 3), (i * TRAIL + s) * 3);
        temp[i * TRAIL + s] = tr.temp[i];
      }
    }
    return { pos, temp, clock: 0 };
  }, [tr]);

  const segs = tr.count * (TRAIL - 1);
  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(segs * 2 * 3), 3));
    g.setAttribute("color", new THREE.BufferAttribute(new Float32Array(segs * 2 * 3), 3));
    g.setAttribute("alpha", new THREE.BufferAttribute(new Float32Array(segs * 2), 1));
    return g;
  }, [segs]);
  useEffect(() => () => geometry.dispose(), [geometry]);

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: lineVertex,
        fragmentShader: lineFragment,
        vertexColors: true,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
    []
  );
  useEffect(() => () => material.dispose(), [material]);

  useFrame(() => {
    const dt = sim.lastDt;
    if (!dt) return;
    advectTracers(sim, tr, dt);
    hist.clock += dt;
    const shift = hist.clock >= TRAIL_DT;
    if (shift) hist.clock = 0;

    const { pos, temp } = hist;
    for (let i = 0; i < tr.count; i++) {
      const b = i * TRAIL;
      if (tr.respawned[i]) {
        // A recycled tracer starts a fresh trail
        for (let s = 0; s < TRAIL; s++) {
          pos.set(tr.pos.subarray(i * 3, i * 3 + 3), (b + s) * 3);
          temp[b + s] = tr.temp[i];
        }
        continue;
      }
      if (shift) {
        pos.copyWithin((b + 1) * 3, b * 3, (b + TRAIL - 1) * 3);
        temp.copyWithin(b + 1, b, b + TRAIL - 1);
      }
      pos.set(tr.pos.subarray(i * 3, i * 3 + 3), b * 3); // head follows the tracer
      temp[b] = tr.temp[i];
    }

    const P = geometry.attributes.position.array;
    const C = geometry.attributes.color.array;
    const A = geometry.attributes.alpha.array;
    let v = 0;
    for (let i = 0; i < tr.count; i++) {
      const b = i * TRAIL;
      const fade = tr.inDuct[i] ? 1 : Math.min(1, tr.age[i] / 0.6) * Math.min(1, (tr.life[i] - tr.age[i]) / 3);
      for (let s = 0; s < TRAIL - 1; s++) {
        for (let e = s; e <= s + 1; e++) {
          P[v * 3] = pos[(b + e) * 3];
          P[v * 3 + 1] = pos[(b + e) * 3 + 1];
          P[v * 3 + 2] = pos[(b + e) * 3 + 2];
          writeColor(C, v * 3, temp[b + e]);
          A[v] = (1 - e / (TRAIL - 1)) * 0.85 * fade; // bright head, fading tail
          v++;
        }
      }
    }
    for (const name of ["position", "color", "alpha"]) geometry.attributes[name].needsUpdate = true;
  });

  return <lineSegments geometry={geometry} material={material} raycast={noRaycast} frustumCulled={false} />;
}

// ---------- Entry point ----------

// mode: "lines" (streak trails) or "smoke" (coloured smoke), both carried by one room simulation
export default function Airflow({ racks, coldAislesX, coldAisle, hotAislesX, hotAisle, aisleLength, floorHalfX, mode = "lines", fanSpeed = 1 }) {
  const sim = useMemo(() => {
    // Same return ducts and fan units as the HVAC geometry, so the suction and the tracers'
    // route through the ducting line up with what's drawn
    const hvac = { ...hvacLayout([...hotAislesX, -(floorHalfX - 0.45), floorHalfX - 0.45], aisleLength), ductY: DUCT_Y };
    const s = createSim(buildRoom({ racks, coldAislesX, coldAisle, hotAislesX, hotAisle, aisleLength, floorHalfX, hvac }));
    s.hvac = hvac;
    return s;
  }, [racks, coldAislesX, coldAisle, hotAislesX, hotAisle, aisleLength, floorHalfX]
  );

  // Step the room once per frame, before the tracers move (lower priority runs first)
  // The tracers still move every frame; the field changes slowly enough to update every other
  useFrame((_, delta) => {
    // Exhaust fan speed (toolbar slider): scales every return fan's suction
    if (sim.fanSpeed !== fanSpeed) {
      sim.fanSpeed = fanSpeed;
      for (const [id, base] of sim.room.hvacFans) sim.room.fix.v[id] = base * fanSpeed;
    }
    const dt = Math.min(delta * TIME_SCALE, MAX_DT);
    sim.frame = (sim.frame ?? 0) + 1;
    sim.pending = (sim.pending ?? 0) + dt;
    if (sim.frame % STEP_EVERY === 0) {
      step(sim, Math.min(sim.pending, MAX_DT * STEP_EVERY));
      sim.pending = 0;
    }
    sim.lastDt = dt;
    sim.time = (sim.time ?? 0) + dt;
  }, -1);

  return mode === "smoke" ? <Smoke sim={sim} /> : <Lines sim={sim} />;
}
