import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Edges } from "@react-three/drei";
import * as THREE from "three";
import { rackHealth } from "./health";
import { latestTemp } from "./temperature";
import {
  BUNDLE_HALF_WIDTH,
  BUNDLE_Y,
  Cable,
  PATCH_RADIUS,
  POWER_COLORS,
  POWER_HALF_WIDTH,
  POWER_RADIUS,
  POWER_Y,
  SERVER_CABLE_COLORS,
  TRAY_OFFSET,
  TRAY_RISE,
} from "./Cabling";
import {
  DRAWER_OUT,
  PANEL,
  RACK,
  SERVER_REAR_Z,
  SERVER_WIDTH,
  STATUS_COLORS,
  U,
  rearPortX,
  serverCenterY,
} from "./rackGeometry";
import Server from "./Server";
import { RACK_BRAND, assetTagTexture, brandTexture, perforationTexture, rackNameTexture } from "./textures";
import { rackProfile, tempColor, thermalTexture } from "./thermal";

export { RACK, STATUS_COLORS };

const DOOR_OPEN_ANGLE = -1.9; // ~110°, swings outward
// Thermal view: black outline on every panel, so racks stay readable over the heat colours
const outline = () => <Edges color="#000000" toneMapped={false} />;

// Selection: glowing edge outlines on the rack cabinet and its door (like the black borders in
// thermal view, but lit). Orange normally; green in thermal view, where it must stand apart from
// heat colours.
// Channels a little above 1 push it just past the bloom threshold, for a soft glow.
const WIRE_CELL = Infinity; // edges only: one cell per face, no grid lines in between
const CABINET_FACES = ["+x", "-x", "+y", "-y", "-z"]; // all but the front (+z, the door side)
const DOOR_FACES = ["+z", "-z"];
const WIRE_COLORS = { normal: new THREE.Color(1.5, 0.5, 0.08), thermal: new THREE.Color(0.15, 1.4, 0.4) };
const POWER_INLET = [-RACK.width / 2 + 0.09, RACK.height, 0.18]; // top-mounted power inlet box
const GRILL_FRAME = 0.035; // rear door frame width
const GRILL_PITCH = 0.012; // perforation hole spacing (m)

// Where a server's rear ports sit (rack-local z); a pulled-out server takes its ports with it
const rearPortZ = (server, selectedServerId) =>
  SERVER_REAR_Z - 0.002 + (server.id === selectedServerId ? DRAWER_OUT : 0);

const hardwareMaterial = new THREE.MeshPhysicalMaterial({ color: "#2a2d32", metalness: 0.6, roughness: 0.4 });
const noRaycast = () => null;

function setCursor(value) {
  document.body.style.cursor = value;
}

function Decal({ texture, size, ...props }) {
  return (
    <mesh {...props} raycast={noRaycast}>
      <planeGeometry args={size} />
      <meshPhysicalMaterial map={texture} roughness={0.6} metalness={0} clearcoat={0.4} />
    </mesh>
  );
}

// 4 uplinks per server: out of rear ports 2–5, up the rear of the rack (behind the grill), out
// the top, through the row tray, then sagging across to the center bundle over the cold aisle
function ServerCables({ servers, rackU, aisleOffset, selectedServerId }) {
  const cables = useMemo(() => {
    const { depth, height } = RACK;
    const rearZ = -depth / 2 + PANEL + 0.012;
    const trayY = height + TRAY_RISE + 0.03;
    const landZ = aisleOffset - BUNDLE_HALF_WIDTH - 0.01;
    return servers.flatMap((server, si) => {
      const y = serverCenterY(server, rackU);
      const pz = rearPortZ(server, selectedServerId);
      return SERVER_CABLE_COLORS.map((color, ci) => {
        const x = (ci - 1.5) * 0.055 + ((si % 3) - 1) * 0.012;
        const z = rearZ + (si % 2) * 0.008;
        const px = rearPortX(ci + 2);
        return {
          key: `${server.id}-${ci}`,
          color,
          points: [
            [px, y, pz],
            [px, y, pz - 0.012],
            [x, Math.min(y + 0.08, height - 0.12), z],
            [x, height - 0.06, z],
            [x, height + 0.1, z + 0.03],
            // Straight up to the row tray (now at the central network height), into it, then
            // slung across to the centre bundle at the same level
            [x * 0.9, trayY - 0.2, TRAY_OFFSET - 0.06],
            [x * 0.85, trayY, TRAY_OFFSET + 0.08],
            [x * 0.7, trayY - 0.12, (TRAY_OFFSET + landZ) / 2],
            [x * 0.6, BUNDLE_Y + BUNDLE_HALF_WIDTH / 4, landZ],
          ],
        };
      });
    });
  }, [servers, rackU, aisleOffset, selectedServerId]);

  return cables.map((c) => <Cable key={c.key} points={c.points} color={c.color} />);
}

// Rear patch leads daisy-chaining neighbouring servers (rear port 0 → next server's port 1),
// routed through the side cable channel behind the grill. A pulled-out server drags its leads with it.
function PatchCables({ servers, rackU, selectedServerId }) {
  const cables = useMemo(() => {
    const sorted = [...servers].sort((a, b) => a.uPosition - b.uPosition);
    const sideX = -SERVER_WIDTH / 2 - 0.01; // same side as the rear port block
    return sorted.slice(1).map((b, i) => {
      const a = sorted[i];
      const [ya, yb] = [serverCenterY(a, rackU), serverCenterY(b, rackU)];
      const [za, zb] = [rearPortZ(a, selectedServerId), rearPortZ(b, selectedServerId)];
      const [xa, xb] = [rearPortX(0), rearPortX(1)];
      const loopZ = Math.min(za, zb) - 0.022;
      return {
        key: `${a.id}-${b.id}`,
        color: i % 2 ? "#202226" : "#2f7bff",
        points: [
          [xa, ya, za],
          [xa, ya, za - 0.012],
          [sideX, ya, loopZ],
          [sideX, yb, loopZ],
          [xb, yb, zb - 0.012],
          [xb, yb, zb],
        ],
      };
    });
  }, [servers, rackU, selectedServerId]);

  return cables.map((c) => <Cable key={c.key} points={c.points} color={c.color} radius={PATCH_RADIUS} segments={32} />);
}

// Live / neutral / earth from the top inlet up to the central power line
function PowerDrop({ aisleOffset }) {
  const wires = useMemo(() => {
    const [ix, iy, iz] = POWER_INLET;
    const landZ = aisleOffset - POWER_HALF_WIDTH - 0.01;
    return POWER_COLORS.map((color, k) => {
      const x = ix + (k - 1) * 0.024;
      return {
        color,
        points: [
          [x, iy + 0.04, iz],
          [x, iy + 0.35, iz + 0.05],
          [x * 0.6, (iy + POWER_Y) / 2 + 0.05, (iz + landZ) / 2],
          [(k - 1) * 0.03, POWER_Y, landZ],
        ],
      };
    });
  }, [aisleOffset]);

  return wires.map((w, i) => <Cable key={i} points={w.points} color={w.color} radius={POWER_RADIUS * 0.7} />);
}

function GlassDoor({ name, working, open, thermal, onToggle, onClose }) {
  const { width, height, depth } = RACK;
  const pivot = useRef();
  const [hovered, setHovered] = useState(false);

  const frame = 0.035;
  const thickness = 0.02;

  // Shared by all four frame bars so the glow animates as one
  const frameMaterial = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: "#1a1c20",
        metalness: 0.7,
        roughness: 0.35,
        clearcoat: 0.3,
        emissive: "#ff5200", // deep orange: stays orange (not yellow) when bloomed
        emissiveIntensity: 0,
        toneMapped: false,
      }),
    []
  );
  useEffect(() => () => frameMaterial.dispose(), [frameMaterial]);

  useFrame((_, delta) => {
    pivot.current.rotation.y = THREE.MathUtils.damp(pivot.current.rotation.y, open ? DOOR_OPEN_ANGLE : 0, 6, delta);
  });

  const statusColor = working ? "#39ff7a" : "#ff3030";

  return (
    // Hinge on the left front edge; door geometry extends along +x from it.
    // Clicking anywhere on the door (frame, glass or handle) toggles it; a double-click always
    // ends closed, whatever its two clicks toggled.
    <group
      ref={pivot}
      position={[-width / 2, height / 2, depth / 2 + thickness / 2]}
      onClick={(e) => {
        e.stopPropagation();
        onToggle();
      }}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
      onPointerOver={(e) => {
        e.stopPropagation();
        setHovered(true);
        setCursor("pointer");
      }}
      onPointerOut={() => {
        setHovered(false);
        setCursor("auto");
      }}
    >
      <group position={[width / 2, 0, 0]}>
        {[
          [0, height / 2 - frame / 2, width, frame],
          [0, -height / 2 + frame / 2, width, frame],
          [-width / 2 + frame / 2, 0, frame, height],
          [width / 2 - frame / 2, 0, frame, height],
        ].map(([x, y, w, h], i) => (
          <mesh key={i} position={[x, y, 0]} material={frameMaterial}>
            <boxGeometry args={[w, h, thickness]} />
          </mesh>
        ))}

        {/* Glass */}
        <mesh>
          <boxGeometry args={[width - frame * 2, height - frame * 2, 0.006]} />
          <meshPhysicalMaterial
            color="#a8d8ff"
            transparent
            opacity={0.16}
            roughness={0.04}
            metalness={0}
            clearcoat={1}
            ior={1.5}
            depthWrite={false}
          />
        </mesh>

        {/* Rack status LED, top-right of the rim */}
        <mesh position={[width / 2 - frame / 2, height / 2 - frame / 2, thickness / 2 + 0.002]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.006, 0.006, 0.004, 16]} />
          <meshStandardMaterial color={statusColor} emissive={statusColor} emissiveIntensity={4} toneMapped={false} />
        </mesh>

        {/* Stickers: name on the glass, brand plate on the bottom rail */}
        <Decal texture={rackNameTexture(name)} size={[0.13, 0.05]} position={[-width / 2 + frame + 0.08, height / 2 - frame - 0.045, 0.0035]} />
        <Decal texture={brandTexture(RACK_BRAND)} size={[0.12, 0.03]} position={[0, -height / 2 + frame / 2, thickness / 2 + 0.001]} />

        {/* Selection wireframe on the door, swinging with it */}
        <SelectionWireframe active={open} thermal={thermal} size={[width, height, thickness]} faces={DOOR_FACES} position={[0, 0, 0]} />

        {/* Handle */}
        <mesh position={[width / 2 - frame - 0.03, 0, thickness / 2 + 0.02]}>
          <boxGeometry args={[0.025, 0.3, 0.03]} />
          <meshPhysicalMaterial color={hovered ? "#4da3ff" : "#c9ccd1"} metalness={0.9} roughness={0.22} clearcoat={0.5} />
        </mesh>
      </group>
    </group>
  );
}

// Rear door: steel frame around a perforated plate, so the cabling behind the servers shows
// through the holes. Thermal view keeps the heat gradient on the plate.
function RearGrill({ heat }) {
  const { width, height, depth } = RACK;
  const z = -depth / 2 + PANEL / 2;
  const plate = [width - GRILL_FRAME * 2, height - GRILL_FRAME * 2];

  const holes = useMemo(() => {
    const t = perforationTexture();
    t.repeat.set(plate[0] / GRILL_PITCH, plate[1] / GRILL_PITCH);
    return t;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Thermal: side bars carry the gradient, top / bottom bars the solid colour at their level
  const frameMaterial = (color) =>
    heat ? (
      <>
        <meshBasicMaterial map={color ? null : heat.map} color={color ?? "#ffffff"} toneMapped={false} />
        {outline()}
      </>
    ) : (
      <meshPhysicalMaterial color="#16181c" metalness={0.55} roughness={0.48} clearcoat={0.3} clearcoatRoughness={0.55} />
    );

  return (
    <group position={[0, height / 2, z]}>
      {[
        [0, height / 2 - GRILL_FRAME / 2, width, GRILL_FRAME, heat?.top],
        [0, -height / 2 + GRILL_FRAME / 2, width, GRILL_FRAME, heat?.bottom],
        [-width / 2 + GRILL_FRAME / 2, 0, GRILL_FRAME, height],
        [width / 2 - GRILL_FRAME / 2, 0, GRILL_FRAME, height],
      ].map(([x, y, w, h, color], i) => (
        <mesh key={i} position={[x, y, 0]}>
          <boxGeometry args={[w, h, PANEL]} />
          {frameMaterial(color)}
        </mesh>
      ))}

      {/* Perforated plate: holes are see-through via the alpha map */}
      <mesh raycast={noRaycast}>
        <planeGeometry args={plate} />
        {heat ? (
          <meshBasicMaterial map={heat.map} alphaMap={holes} transparent depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
        ) : (
          <meshPhysicalMaterial
            color="#22252a"
            metalness={0.6}
            roughness={0.45}
            alphaMap={holes}
            transparent
            depthWrite={false}
            side={THREE.DoubleSide}
          />
        )}
      </mesh>

      {/* Handle, on the outside face */}
      <mesh position={[width / 2 - GRILL_FRAME - 0.03, 0, -PANEL / 2 - 0.015]} material={hardwareMaterial}>
        <boxGeometry args={[0.022, 0.26, 0.025]} />
      </mesh>
    </group>
  );
}

// Grid lines over the faces of a box centred at the origin (sizes in m), as one line list.
// `faces` picks which: "+x", "-x", "+y", "-y", "+z", "-z".
const ALL_FACES = ["+x", "-x", "+y", "-y", "+z", "-z"];
function wireGrid(w, h, d, cell, faces = ALL_FACES) {
  const pts = [];
  const steps = (len) => {
    const n = Math.max(1, Math.round(len / cell));
    return Array.from({ length: n + 1 }, (_, i) => -len / 2 + (len * i) / n);
  };
  const [xs, ys, zs] = [steps(w), steps(h), steps(d)];
  const line = (a, b) => pts.push(...a, ...b);
  const has = (axis, s) => faces.includes(`${s > 0 ? "+" : "-"}${axis}`);
  for (const z of [-d / 2, d / 2].filter((v) => has("z", v))) {
    xs.forEach((x) => line([x, -h / 2, z], [x, h / 2, z]));
    ys.forEach((y) => line([-w / 2, y, z], [w / 2, y, z]));
  }
  for (const x of [-w / 2, w / 2].filter((v) => has("x", v))) {
    zs.forEach((z) => line([x, -h / 2, z], [x, h / 2, z]));
    ys.forEach((y) => line([x, y, -d / 2], [x, y, d / 2]));
  }
  for (const y of [-h / 2, h / 2].filter((v) => has("y", v))) {
    xs.forEach((x) => line([x, y, -d / 2], [x, y, d / 2]));
    zs.forEach((z) => line([-w / 2, y, z], [w / 2, y, z]));
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
  return g;
}

// Glowing wireframe shell on a selected rack's faces (the cabinet minus its open front, or the
// door); fades in and out with the selection. `size` is padded slightly so it never z-fights.
function SelectionWireframe({ active, thermal, size, faces, position }) {
  const pad = 0.012;
  const [w, h, d] = size;
  const key = faces.join();
  const geometry = useMemo(
    () => wireGrid(w + pad * 2, h + pad * 2, d + pad * 2, WIRE_CELL, faces),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [w, h, d, key]
  );
  useEffect(() => () => geometry.dispose(), [geometry]);
  const material = useMemo(
    () => new THREE.LineBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, toneMapped: false }),
    []
  );
  useEffect(() => () => material.dispose(), [material]);
  const ref = useRef();

  useFrame((_, delta) => {
    material.color.copy(thermal ? WIRE_COLORS.thermal : WIRE_COLORS.normal);
    material.opacity = THREE.MathUtils.damp(material.opacity, active ? 0.75 : 0, 6, delta);
    ref.current.visible = material.opacity > 0.01;
  });

  return <lineSegments ref={ref} geometry={geometry} material={material} position={position} raycast={noRaycast} />;
}

// Top-of-rack hardware: power inlet, brush cable entry, leveling feet
function RackHardware() {
  const { width, depth, height } = RACK;
  return (
    <group>
      <mesh position={[POWER_INLET[0], height + 0.02, POWER_INLET[2]]} material={hardwareMaterial}>
        <boxGeometry args={[0.1, 0.04, 0.08]} />
      </mesh>
      <mesh position={[0, height + 0.015, -depth / 2 + 0.07]} material={hardwareMaterial}>
        <boxGeometry args={[0.32, 0.03, 0.09]} />
      </mesh>
      {[-1, 1].flatMap((sx) =>
        [-1, 1].map((sz) => (
          <mesh
            key={`${sx}${sz}`}
            position={[sx * (width / 2 - 0.05), -0.015, sz * (depth / 2 - 0.06)]}
            material={hardwareMaterial}
          >
            <cylinderGeometry args={[0.025, 0.03, 0.03, 12]} />
          </mesh>
        ))
      )}
    </group>
  );
}

// Local space: door faces +z, rack sits on y = 0
export default function ServerRack({
  rack,
  open, // controlled by the parent so only one rack is open at a time
  selectedServerId,
  onOpen,
  onClose,
  onSelectServer,
  aisleOffset, // distance from the rack's center to the cold aisle centerline
  thermal = false,
  topView = false, // in the top view, clicking the rack (its top) opens it
  ...props
}) {
  const { width, depth, height } = RACK;
  const rackU = rack.totalU ?? 42;
  const health = rackHealth(rack);

  // Thermal view: panels show a vertical blue → yellow → orange → red gradient built from the
  // servers' temperatures in pod-data.json, so hot levels show where they are
  const heat = useMemo(() => {
    if (!thermal) return null;
    const profile = rackProfile(
      rack.servers.map((s) => ({ y: serverCenterY(s, rackU), half: (s.heightU * U) / 2, temp: latestTemp(s.temperature) }))
    );
    return {
      map: thermalTexture(profile, height),
      bottom: tempColor(profile(0)),
      top: tempColor(profile(height)),
    };
  }, [thermal, rack.servers, rackU, height]);

  useEffect(() => () => heat?.map.dispose(), [heat]);

  // Normal view: the original powder-coated steel. Thermal view: unlit heat colours, with the
  // gradient on the side/back panels and the solid colour at that level on top/bottom.
  // In thermal view each panel also gets a black outline, like the servers, so racks stay readable;
  // an open (selected) rack's outline glows orange instead
  const panelMaterial = (color) =>
    heat ? (
      <>
        <meshBasicMaterial map={color ? null : heat.map} color={color ?? "#ffffff"} toneMapped={false} />
        {outline()}
      </>
    ) : (
      <meshPhysicalMaterial color="#16181c" metalness={0.55} roughness={0.48} clearcoat={0.3} clearcoatRoughness={0.55} />
    );

  const toggleDoor = () => (open ? onClose(rack.id) : onOpen(rack.id));

  return (
    // Normally only the door opens / closes the rack (see GlassDoor). In the top view the door is
    // edge-on, so clicking anywhere on the rack (i.e. its top) opens it, closing any other open rack.
    <group
      {...props}
      onClick={
        topView
          ? (e) => {
              e.stopPropagation();
              onOpen(rack.id);
            }
          : undefined
      }
      onPointerOver={
        topView
          ? (e) => {
              e.stopPropagation();
              setCursor("pointer");
            }
          : undefined
      }
      onPointerOut={topView ? () => setCursor("auto") : undefined}
    >
      {/* Sides, each with an asset tag near the top front */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * (width / 2 - PANEL / 2), height / 2, 0]}>
            <boxGeometry args={[PANEL, height, depth]} />
            {panelMaterial()}
          </mesh>
          {!thermal && (
            <Decal
              texture={assetTagTexture(rack.id)}
              size={[0.1, 0.045]}
              position={[s * (width / 2 + 0.0008), height - 0.2, depth / 2 - 0.12]}
              rotation={[0, (s * Math.PI) / 2, 0]}
            />
          )}
        </group>
      ))}
      {/* Top & bottom: solid color of the temperature at that level */}
      {[
        [PANEL / 2, heat?.bottom],
        [height - PANEL / 2, heat?.top],
      ].map(([y, color]) => (
        <mesh key={y} position={[0, y, 0]}>
          <boxGeometry args={[width, PANEL, depth]} />
          {panelMaterial(color)}
        </mesh>
      ))}
      {/* Back: perforated grill door, cabling visible behind it */}
      <RearGrill heat={heat} />

      <RackHardware />

      {/* Cabinet wireframe: back, sides, top and bottom; the front is open (the door has its own) */}
      <SelectionWireframe
        active={open}
        thermal={thermal}
        size={[width, height, depth]}
        faces={CABINET_FACES}
        position={[0, height / 2, 0]}
      />

      {rack.servers.map((server) => (
        <Server
          key={server.id}
          server={server}
          rackU={rackU}
          out={selectedServerId === server.id}
          interactive={open}
          thermal={thermal}
          onSelect={() => onSelectServer(rack.id, server.id)}
        />
      ))}

      <PatchCables servers={rack.servers} rackU={rackU} selectedServerId={selectedServerId} />
      <ServerCables servers={rack.servers} rackU={rackU} aisleOffset={aisleOffset} selectedServerId={selectedServerId} />
      <PowerDrop aisleOffset={aisleOffset} />

      <GlassDoor name={rack.name} working={health.level !== "alert"} open={open} thermal={thermal} onToggle={toggleDoor} onClose={() => onClose(rack.id)} />
    </group>
  );
}
