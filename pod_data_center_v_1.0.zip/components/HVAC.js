import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { grilleTextures } from "./textures";

// Hot-air return system at the ceiling: a return duct over every hot aisle (and along the walls
// behind the outermost rows), with intake grilles on its underside and inline return-fan units.
// All the ducts join a header duct across one end of the aisles, which feeds a single stack with
// an in-line booster fan; the stack joins the building's shared exhaust riser, which carries every
// floor's hot air up to the main HVAC exhaust on the roof. The CFD simulation removes air through the same
// ceiling openings, so the smoke / lines visibly rise into these intakes.

export const DUCT_Y = 4.1; // centre-line height, at the ceiling return (Airflow's CEILING_Y)
const DUCT_W = 0.9;
const DUCT_H = 0.45;
const UNIT_SPACING = 6; // inline return-fan units along each duct
const FAN_R = 0.3;
const STACK_HEIGHT = 2.4;
const UNIT_TOP = 0.9; // in-line booster fan unit at the top of the floor's stack
export const RISER_SHOWN = 12; // m of the building's shared exhaust riser drawn above the unit

// Shared layout so the CFD tracers can follow the same duct route as the geometry
export function hvacLayout(returnsX, aisleLength) {
  const xs = [...returnsX].sort((a, b) => a - b);
  const half = aisleLength / 2;
  const headerZ = half - 0.6; // header across the +z end, inside the room
  const units = []; // inline return-fan units along each duct (z)
  for (let uz = -half + UNIT_SPACING / 2; uz < headerZ - 1; uz += UNIT_SPACING) units.push(uz);
  return {
    ducts: xs,
    from: -half,
    headerZ,
    units,
    outletX: xs[xs.length - 1] + 1.6, // single outlet, through the wall past the last duct
    stackTop: DUCT_Y + STACK_HEIGHT + UNIT_TOP,
  };
}

const steel = new THREE.MeshPhysicalMaterial({ color: "#7d848d", metalness: 0.75, roughness: 0.38, clearcoat: 0.2 });
const unitBody = new THREE.MeshPhysicalMaterial({ color: "#3b4148", metalness: 0.6, roughness: 0.45, clearcoat: 0.3 });
const dark = new THREE.MeshStandardMaterial({ color: "#0c0e11", metalness: 0.3, roughness: 0.7 });
const blade = new THREE.MeshStandardMaterial({ color: "#9aa2ab", metalness: 0.8, roughness: 0.3, side: THREE.DoubleSide });
const led = new THREE.MeshStandardMaterial({ color: "#062", emissive: "#39ff7a", emissiveIntensity: 3, toneMapped: false });
const noRaycast = () => null;

// Live fan speed (× nominal) shared by every fan, set from the toolbar slider
const fanState = { speed: 1, current: 1 };

// Spinning fan seen from below: housing ring, hub and blades; spins up / down smoothly
function Fan({ position, radius = FAN_R, speed = 9, rotation = [0, 0, 0] }) {
  const rotor = useRef();
  useFrame((_, delta) => {
    rotor.current.rotation.y += delta * speed * fanState.current;
  });
  return (
    <group position={position} rotation={rotation}>
      <mesh material={dark} raycast={noRaycast}>
        <cylinderGeometry args={[radius * 1.08, radius * 1.08, 0.06, 32, 1, true]} />
      </mesh>
      <mesh position={[0, 0.02, 0]} material={dark} raycast={noRaycast}>
        <cylinderGeometry args={[radius, radius, 0.01, 32]} />
      </mesh>
      <group ref={rotor} position={[0, -0.01, 0]}>
        <mesh material={unitBody} raycast={noRaycast}>
          <cylinderGeometry args={[radius * 0.22, radius * 0.22, 0.05, 16]} />
        </mesh>
        {Array.from({ length: 5 }, (_, i) => (
          <mesh
            key={i}
            rotation={[0.35, (i / 5) * Math.PI * 2, 0]}
            position={[Math.cos((i / 5) * Math.PI * 2) * radius * 0.55, 0, -Math.sin((i / 5) * Math.PI * 2) * radius * 0.55]}
            material={blade}
            raycast={noRaycast}
          >
            <boxGeometry args={[radius * 0.75, 0.006, radius * 0.32]} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

// Long return duct along z with intake grilles underneath and inline fan units
function ReturnDuct({ x, from, to, units, grille }) {
  const length = to - from;
  const z = (from + to) / 2;

  return (
    <group position={[x, DUCT_Y, 0]}>
      <mesh position={[0, 0, z]} material={steel} raycast={noRaycast}>
        <boxGeometry args={[DUCT_W, DUCT_H, length]} />
      </mesh>
      {/* Intake grille along the underside */}
      <mesh position={[0, -DUCT_H / 2 - 0.002, z]} rotation={[Math.PI / 2, 0, 0]} raycast={noRaycast}>
        <planeGeometry args={[DUCT_W * 0.8, length - 0.2]} />
        <meshPhysicalMaterial map={grille.map} bumpMap={grille.bump} metalness={0.6} roughness={0.5} side={THREE.DoubleSide} />
      </mesh>
      {/* Seams / flanges every 1.2 m */}
      {Array.from({ length: Math.floor(length / 1.2) }, (_, i) => (
        <mesh key={i} position={[0, 0, from + (i + 1) * 1.2]} material={unitBody} raycast={noRaycast}>
          <boxGeometry args={[DUCT_W + 0.04, DUCT_H + 0.04, 0.03]} />
        </mesh>
      ))}
      {/* Inline return-fan units hanging below the duct */}
      {units.map((uz) => (
        <group key={uz} position={[0, -DUCT_H / 2 - 0.2, uz]}>
          <mesh material={unitBody} raycast={noRaycast}>
            <boxGeometry args={[DUCT_W + 0.3, 0.4, 1.3]} />
          </mesh>
          <Fan position={[0, -0.22, -0.3]} />
          <Fan position={[0, -0.22, 0.3]} speed={10} />
          <mesh position={[DUCT_W / 2 + 0.151, 0.1, 0.5]} rotation={[0, Math.PI / 2, 0]} material={led} raycast={noRaycast}>
            <circleGeometry args={[0.015, 12]} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

// xray: while CFD is on, ducts and units turn see-through so the air inside them shows
export default function HVAC({ returnsX, aisleLength, xray = false, fanSpeed = 1 }) {
  fanState.speed = fanSpeed;
  useFrame((_, delta) => {
    fanState.current = THREE.MathUtils.damp(fanState.current, fanState.speed, 1.5, delta);
  });
  useEffect(() => {
    for (const m of [steel, unitBody]) {
      m.transparent = xray;
      m.opacity = xray ? 0.18 : 1;
      m.depthWrite = !xray;
      m.needsUpdate = true;
    }
  }, [xray]);

  const grille = useMemo(() => {
    const t = grilleTextures(10);
    for (const m of [t.map, t.bump]) m.repeat.set(1, aisleLength / 0.6);
    return t;
  }, [aisleLength]);
  useEffect(() => () => [grille.map, grille.bump].forEach((t) => t.dispose()), [grille]);

  const { ducts: xs, from, headerZ, outletX, units } = hvacLayout(returnsX, aisleLength);
  const xMin = xs[0];

  return (
    <group>
      {xs.map((x) => (
        <group key={x}>
          <ReturnDuct x={x} from={from} to={headerZ} units={units} grille={grille} />
          {/* Elbow into the header */}
          <mesh position={[x, DUCT_Y, headerZ]} material={unitBody} raycast={noRaycast}>
            <boxGeometry args={[DUCT_W + 0.08, DUCT_H + 0.08, DUCT_W + 0.08]} />
          </mesh>
        </group>
      ))}

      {/* Header duct collecting every return line, running on to the outlet */}
      <mesh position={[(xMin + outletX) / 2, DUCT_Y, headerZ]} material={steel} raycast={noRaycast}>
        <boxGeometry args={[outletX - xMin + DUCT_W, DUCT_H * 1.4, DUCT_W * 1.2]} />
      </mesh>

      {/* Single outlet: stack rising from the header end through a booster fan unit into the
          building's shared riser, which carries the air up to the main exhaust on the roof */}
      <group position={[outletX, DUCT_Y, headerZ]}>
        <mesh position={[0, STACK_HEIGHT / 2, 0]} material={steel} raycast={noRaycast}>
          <boxGeometry args={[1.2, STACK_HEIGHT, 1.2]} />
        </mesh>
        <mesh position={[0, STACK_HEIGHT + UNIT_TOP / 2, 0]} material={unitBody} raycast={noRaycast}>
          <boxGeometry args={[2.0, UNIT_TOP, 2.0]} />
        </mesh>
        {/* Louvres on the unit's sides */}
        {[-1, 1].map((s) =>
          Array.from({ length: 6 }, (_, i) => (
            <mesh key={`${s}${i}`} position={[s * 1.005, STACK_HEIGHT + 0.12 + i * 0.12, 0]} rotation={[0.5, 0, 0]} material={dark} raycast={noRaycast}>
              <boxGeometry args={[0.01, 0.06, 1.7]} />
            </mesh>
          ))
        )}
        {/* Booster fan inside the unit, pushing the air up the riser */}
        <Fan position={[0, STACK_HEIGHT + UNIT_TOP / 2, 0]} radius={0.75} speed={6} rotation={[Math.PI, 0, 0]} />
        {/* Shared riser continuing up to the floors above and the main exhaust on the roof */}
        <mesh position={[0, STACK_HEIGHT + UNIT_TOP + RISER_SHOWN / 2, 0]} material={steel} raycast={noRaycast}>
          <boxGeometry args={[1.2, RISER_SHOWN, 1.2]} />
        </mesh>
        {Array.from({ length: Math.floor(RISER_SHOWN / 1.5) }, (_, i) => (
          <mesh key={i} position={[0, STACK_HEIGHT + UNIT_TOP + (i + 1) * 1.5, 0]} material={unitBody} raycast={noRaycast}>
            <boxGeometry args={[1.3, 0.04, 1.3]} />
          </mesh>
        ))}
        <mesh position={[0.9, STACK_HEIGHT + 0.6, 1.005]} material={led} raycast={noRaycast}>
          <circleGeometry args={[0.03, 12]} />
        </mesh>
      </group>
    </group>
  );
}
