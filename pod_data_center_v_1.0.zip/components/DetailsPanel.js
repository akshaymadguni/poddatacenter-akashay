import { STATUS_COLORS } from "./rackGeometry";
import { isActive, rackHealth } from "./health";
import { latestTemp, tempHistory } from "./temperature";
import { THERMAL_STOPS, tempColor } from "./thermal";
import MetricsChart from "./MetricTrend";
import styles from "@/styles/DataCenter.module.css";

// A rack's CPU / memory utilisation: the reading-by-reading average over its active servers
// (inactive servers read 0% and would just drag the average down)
function rackAverage(rack, key) {
  const series = rack.servers.filter(isActive).map((s) => tempHistory(s[key])).filter((h) => h.length);
  if (!series.length) return [];
  const n = Math.min(...series.map((h) => h.length));
  return Array.from({ length: n }, (_, i) => series.reduce((sum, h) => sum + h[h.length - n + i], 0) / series.length);
}

function Status({ value, color = STATUS_COLORS[value] ?? "#888888" }) {
  return (
    // Dark text on a light tint of the status colour, so neon greens stay readable on white
    <span className={styles.status} style={{ borderColor: color, background: `${color}26` }}>
      <span className={styles.dot} style={{ background: color, color }} />
      {value}
    </span>
  );
}

function Rows({ rows }) {
  return (
    <dl className={styles.rows}>
      {rows.map(([label, value]) => (
        <div key={label} className={styles.row}>
          <dt>{label}</dt>
          <dd>{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function ServerSection({ server }) {
  const top = server.uPosition + server.heightU - 1;
  return (
    <section className={styles.section}>
      <p className={styles.kicker}>Server</p>
      <h2 className={styles.title}>{server.name}</h2>
      <Status value={server.status} />
      <Rows
        rows={[
          ["Hostname", server.hostname ?? "—"],
          ["IP", server.ip],
          ["CPU", server.cpu],
          ["Memory", server.memory],
          ["U position", server.heightU > 1 ? `U${server.uPosition}–U${top}` : `U${server.uPosition}`],
          ["Height", `${server.heightU}U`],
        ]}
      />
      <MetricsChart
        label="Server metrics"
        temperature={server.temperature}
        cpu={server.cpuUtilization}
        memory={server.memoryUtilization}
      />
    </section>
  );
}

// Tiny card per server in the rack: name, hostname, IP, current temperature (with its thermal
// colour as a swatch) and an active/inactive dot. Clicking one opens the rack and pulls it out.
function ServerCards({ rack, selectedServerId, onPickServer }) {
  const servers = [...rack.servers].sort((a, b) => b.uPosition - a.uPosition); // top of rack first
  return (
    <div className={styles.cardsBlock}>
      <p className={styles.blockTitle}>Servers in {rack.name}</p>
      <ul className={styles.cards}>
        {servers.map((s) => {
          const temp = latestTemp(s.temperature);
          const hot = temp >= THERMAL_STOPS.at(-2)[0];
          return (
            <li key={s.id}>
              <button
                className={`${styles.card} ${s.id === selectedServerId ? styles.cardSelected : ""}`}
                onClick={() => onPickServer(rack.id, s.id)}
                title={`Open ${rack.name} and pull out ${s.name}`}
              >
                <span className={styles.cardTop}>
                  <span
                    className={styles.dot}
                    style={{ background: STATUS_COLORS[s.status] ?? "#888", color: STATUS_COLORS[s.status] ?? "#888" }}
                    aria-label={isActive(s) ? "active" : "inactive"}
                  />
                  <span className={styles.cardName}>{s.name}</span>
                  <span className={styles.cardU}>U{s.uPosition}</span>
                </span>
                <span className={styles.cardMeta}>{s.hostname ?? s.id}</span>
                <span className={styles.cardMeta}>{s.ip}</span>
                <span className={`${styles.cardTemp} ${hot ? styles.cardHot : ""}`}>
                  <span className={styles.swatch} style={{ background: `#${tempColor(temp).getHexString()}` }} />
                  {temp.toFixed(1)} °C
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function RackSection({ rack, nested, selectedServerId, onPickServer }) {
  const totalU = rack.totalU ?? 42;
  const usedU = rack.servers.reduce((sum, s) => sum + s.heightU, 0);
  const health = rackHealth(rack);
  return (
    <section className={`${styles.section} ${nested ? styles.nested : ""}`}>
      <p className={styles.kicker}>{nested ? "In rack" : "Rack"}</p>
      <h2 className={styles.title}>{rack.name}</h2>
      <Status value={health.label} color={health.color} />
      <Rows
        rows={[
          ["Location", `Row ${rack.row}, slot ${rack.slot + 1}`],
          ["Active servers", `${health.active} / ${health.total}`],
          ["Capacity", `${usedU}U / ${totalU}U used`],
          ["Power", `${rack.powerKw} / ${rack.maxPowerKw} kW`],
        ]}
      />
      {/* Server cards only for a rack selection; with a server selected the panel stays focused on it */}
      {!nested && <ServerCards rack={rack} selectedServerId={selectedServerId} onPickServer={onPickServer} />}
      {/* CPU / memory are averaged over the rack's active servers */}
      <MetricsChart
        label="Rack metrics (CPU / memory: avg of active servers)"
        temperature={rack.temperature}
        cpu={rackAverage(rack, "cpuUtilization")}
        memory={rackAverage(rack, "memoryUtilization")}
      />
    </section>
  );
}

export default function DetailsPanel({ rack, server, onClose, onPickServer }) {
  if (!rack) return null;
  return (
    <aside className={styles.panel}>
      <button className={styles.close} onClick={onClose} aria-label="Close details">
        ×
      </button>
      {server && <ServerSection server={server} />}
      <RackSection rack={rack} nested={Boolean(server)} selectedServerId={server?.id} onPickServer={onPickServer} />
    </aside>
  );
}
