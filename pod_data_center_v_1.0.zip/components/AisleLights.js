import * as THREE from "three";
import { RACK } from "./rackGeometry";

// Rectangular vapor-tight light fixtures hung over the cold aisle in two rows, either side of the
// central wiring. Emissive (they glow, with bloom) rather than real light sources. They hang
// 0.4 m above the rack tops, below the cables sagging from the racks to the overhead lines.

const LENGTH = 1.2;
const WIDTH = 0.12;
const HEIGHT = 0.07;
const MOUNT_Y = RACK.height + 0.4;
const ROW_OFFSET = 0.55; // either side of the aisle centreline
const SPACING = 2.4;
const ROD_LENGTH = 1.5; // suspension rods above each fixture

const housing = new THREE.MeshPhysicalMaterial({ color: "#c9ccd1", metalness: 0.3, roughness: 0.45, clearcoat: 0.4 });
const endCap = new THREE.MeshPhysicalMaterial({ color: "#7d838c", metalness: 0.4, roughness: 0.5 });
const diffuser = new THREE.MeshStandardMaterial({
  color: "#f4f8ff",
  emissive: "#f4f8ff",
  emissiveIntensity: 1.6, // over the bloom threshold, so the diffuser glows
  toneMapped: false,
});
const rod = new THREE.MeshStandardMaterial({ color: "#8d939b", metalness: 0.7, roughness: 0.4 });
const noRaycast = () => null;

function Fixture({ position }) {
  return (
    <group position={position}>
      <mesh material={housing} raycast={noRaycast}>
        <boxGeometry args={[WIDTH, HEIGHT, LENGTH]} />
      </mesh>
      {/* Frosted diffuser along the underside */}
      <mesh position={[0, -HEIGHT / 2 - 0.006, 0]} material={diffuser} raycast={noRaycast}>
        <boxGeometry args={[WIDTH * 0.8, 0.012, LENGTH * 0.94]} />
      </mesh>
      {/* Sealed end caps */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[0, 0, (s * LENGTH) / 2]} material={endCap} raycast={noRaycast}>
          <boxGeometry args={[WIDTH + 0.012, HEIGHT + 0.012, 0.03]} />
        </mesh>
      ))}
      {/* Suspension rods, disappearing into the dark above */}
      {[-1, 1].map((s) => (
        <mesh key={`rod${s}`} position={[0, HEIGHT / 2 + ROD_LENGTH / 2, s * LENGTH * 0.35]} material={rod} raycast={noRaycast}>
          <cylinderGeometry args={[0.004, 0.004, ROD_LENGTH, 6]} />
        </mesh>
      ))}
    </group>
  );
}

export default function AisleLights({ length }) {
  const count = Math.max(1, Math.floor((length - LENGTH) / SPACING) + 1);
  const zs = Array.from({ length: count }, (_, i) => (i - (count - 1) / 2) * SPACING);
  return zs.flatMap((z) => [-1, 1].map((s) => <Fixture key={`${s}${z}`} position={[s * ROW_OFFSET, MOUNT_Y, z]} />));
}
