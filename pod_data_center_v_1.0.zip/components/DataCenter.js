import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, OrbitControls, OrthographicCamera, PerspectiveCamera } from "@react-three/drei";
import { EffectComposer, Bloom, ToneMapping } from "@react-three/postprocessing";
import { ToneMappingMode } from "postprocessing";
import * as THREE from "three";
import ServerRack, { RACK } from "./ServerRack";
import { AisleBundle, RackLinks, Tray, TRAY_OFFSET, TRAY_RISE } from "./Cabling";
import { grilleTextures } from "./textures";
import DetailsPanel from "./DetailsPanel";
import AisleLights from "./AisleLights";
import Airflow from "./Airflow";
import HVAC from "./HVAC";
import Building, { FLOOR_COUNT, useBuilding } from "./Building";
import { rackHealth } from "./health";
import { HudOverlay, HudProjector } from "./RackHuds";
import usePodData from "./usePodData";
import { LEGEND_GRADIENT, THERMAL_STOPS } from "./thermal";
import styles from "@/styles/DataCenter.module.css";

const COLD_AISLE = 2.4; // gap between the two rows (2x the original 1.2 m)
const RACK_GAP = 1.2 * 0.8 * 0.5; // gap between neighbouring racks in a row: 0.48 m
const AISLE_STRIPE = 0.08; // width of the black stripes marking the cold aisle edges
const AISLE_TINT = "#a3a8b0"; // darkens the cold aisle tiles (white = untinted); lower = darker
const HOT_AISLE_TINT = "#4a4644"; // solid hot aisle plates, warm dark grey
const RACK_PITCH = RACK.width + RACK_GAP;
const TILE = 0.6; // raised-floor tile size
const AISLE_TILE = TILE * 2; // cold-aisle tiles are double size; aisle width and length are whole multiples
const AISLE_EXTENSION = AISLE_TILE; // the aisles run one tile past the racks at each end

// Three cold aisles, each with two rows of racks facing each other across it. Neighbouring
// aisles' rows stand back to back with a hot aisle between their rear grills:
//   C ► cold ◄ D | hot | A ► cold ◄ B | hot | E ► cold ◄ F
// The rest of the scene reads the layout from ROWS, COLD_AISLES_X and HOT_AISLES_X.
const HOT_AISLE = 1.46; // gap between back-to-back rows; makes the aisle pitch a whole 6 m
const ROW_X = COLD_AISLE / 2 + RACK.depth / 2; // rack-center distance from its cold aisle centerline
const AISLE_PITCH = COLD_AISLE + RACK.depth * 2 + HOT_AISLE; // cold aisle centre to centre
// [cold aisle centre x, row on its -x side, row on its +x side]
const AISLES = [
  [-AISLE_PITCH, "C", "D"],
  [0, "A", "B"],
  [AISLE_PITCH, "E", "F"],
];
const COLD_AISLES_X = AISLES.map(([x]) => x);
const HOT_AISLES_X = COLD_AISLES_X.slice(1).map((x) => x - AISLE_PITCH / 2);
// Rack-center x per row and door direction (+1 = doors face +x)
const ROWS = Object.fromEntries(
  AISLES.flatMap(([x, minus, plus]) => [
    [minus, { x: x - ROW_X, facing: 1 }],
    [plus, { x: x + ROW_X, facing: -1 }],
  ])
);
const rowOf = (row) => ROWS[row] ?? ROWS.A;
const ROW_ORDER = AISLES.flatMap(([, minus, plus]) => [minus, plus]); // left to right
const LAYOUT_HALF_X = AISLE_PITCH + ROW_X + RACK.depth / 2; // back edge of the outermost racks
// Floor covers just the aisle area: out to the outermost racks' backs (rounded up to whole tiles,
// so the grid stays aligned with the cold aisles) and as long as the aisles
const FLOOR_SCALE = 1.1; // each floor's width and length (not height) relative to the racks' footprint
const FLOOR_HALF_X = Math.ceil(LAYOUT_HALF_X / 0.6) * 0.6 * FLOOR_SCALE;
// Ceiling return ducts: one over each hot aisle, plus one along each wall behind the outer rows
const RETURNS_X = [...HOT_AISLES_X, -(FLOOR_HALF_X - 0.45), FLOOR_HALF_X - 0.45];

// Area light per facing rack pair, over the cold aisle between them, coloured by the pair's health:
// red if either rack is in alert, else yellow when bad racks dominate, else blue
const AREA_LIGHT = { intensity: 2.5, distance: 4, y: RACK.height + 0.3 };
const AREA_COLORS = { ok: "#4d8dff", warn: "#ffd23f", alert: "#ff3030" };
function areaColor(pair) {
  const levels = pair.map((r) => rackHealth(r).level);
  if (levels.includes("alert")) return AREA_COLORS.alert;
  const bad = levels.filter((l) => l === "bad").length;
  return bad / levels.length >= 0.5 ? AREA_COLORS.warn : AREA_COLORS.ok;
}

const CAMERA_POSITION = [18, 13, 22]; // far enough back to frame all three aisles of 8-rack rows
const CAMERA_DISTANCE = Math.hypot(...CAMERA_POSITION);
const ORBIT_TARGET = [0, 1, 0];
const TOP_POSITION = [0, 20, 0];
const TOP_TARGET = [0, 0, 0];
const TOP_UP = [0, 0, -1]; // screen-up is -z when looking straight down
const DEFAULT_FOV = 45;
const FOCUS_MARGIN = 1.12; // breathing room around a focused rack
const FOCUS_MAX_DISTANCE = COLD_AISLE - 0.3; // stay inside the aisle, short of the opposite row
// Focused view is a raised three-quarter view, not dead-on, so a pulled-out server reads in 3D:
// swung toward the door's handle side (the open door is out of the way there) and looking down
const FOCUS_YAW = THREE.MathUtils.degToRad(32);
const FOCUS_PITCH = THREE.MathUtils.degToRad(20);
const FOCUS_LEAD = 0.15; // aim this far in front of the door, toward where servers slide out

// Camera distance and fov that fit a whole rack face. If the ideal distance at the default fov
// would put the camera inside the opposite row, it stays in the aisle and widens the fov instead.
function fitRack(aspect) {
  const halfH = (RACK.height / 2) * FOCUS_MARGIN;
  const halfW = (RACK.width / 2) * FOCUS_MARGIN;
  const tanHalf = Math.tan(THREE.MathUtils.degToRad(DEFAULT_FOV / 2));
  const ideal = Math.max(halfH / tanHalf, halfW / (tanHalf * aspect));
  const distance = Math.min(ideal, FOCUS_MAX_DISTANCE);
  const fovFor = (half) => THREE.MathUtils.radToDeg(2 * Math.atan(half / distance));
  const fov = Math.max(DEFAULT_FOV, fovFor(halfH), fovFor(halfW / aspect));
  return { distance, fov };
}

// Both cameras stay mounted, each with its own controls, so the perspective view
// keeps its last position, rotation and target while the top view is active.
function Cameras({ top, extentX, extentZ, focus }) {
  const [persp, setPersp] = useState(null);
  const [ortho, setOrtho] = useState(null);
  const perspControls = useRef();
  const orthoControls = useRef();
  const flight = useRef(null);
  const { width, height } = useThree((s) => s.size);

  // Start a camera flight to the requested rack face
  useEffect(() => {
    if (!focus) return;
    const { distance, fov } = fitRack(width / height);
    const normal = new THREE.Vector3(...focus.normal);
    const side = new THREE.Vector3(...focus.side);
    const target = new THREE.Vector3(...focus.front).addScaledVector(normal, FOCUS_LEAD);
    // Viewing direction: rotate the door normal toward the handle side, then tilt it up
    const dir = normal
      .clone()
      .multiplyScalar(Math.cos(FOCUS_YAW))
      .addScaledVector(side, Math.sin(FOCUS_YAW))
      .multiplyScalar(Math.cos(FOCUS_PITCH));
    dir.y = Math.sin(FOCUS_PITCH);
    // A little further back than face-on, but the across-aisle part still stops short of the opposite row
    const across = Math.cos(FOCUS_YAW) * Math.cos(FOCUS_PITCH);
    const d = Math.min(distance * 1.1, (FOCUS_MAX_DISTANCE - FOCUS_LEAD) / across);
    const position = target.clone().addScaledVector(dir, d);
    flight.current = { target, position, fov };
    // `focus` changes identity per click; size is read but shouldn't retrigger a flight
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focus]);

  // Any user drag/zoom cancels a flight in progress
  useEffect(() => {
    const controls = perspControls.current;
    if (!controls) return;
    const cancel = () => (flight.current = null);
    controls.addEventListener("start", cancel);
    return () => controls.removeEventListener("start", cancel);
  }, [persp]);

  useFrame((_, delta) => {
    const f = flight.current;
    const controls = perspControls.current;
    if (!f || !persp || !controls) return;
    const k = 1 - Math.exp(-delta * 4);
    persp.position.lerp(f.position, k);
    controls.target.lerp(f.target, k);
    persp.fov += (f.fov - persp.fov) * k;
    persp.updateProjectionMatrix();
    controls.update();
    if (persp.position.distanceTo(f.position) < 0.005 && controls.target.distanceTo(f.target) < 0.005) {
      flight.current = null;
    }
  });

  // Fit every rack in the top view (also refits when the details panel resizes the canvas)
  useEffect(() => {
    if (!top || !ortho) return;
    ortho.zoom = Math.min(width / extentX, height / extentZ) * 0.9;
    ortho.updateProjectionMatrix();
  }, [top, ortho, width, height, extentX, extentZ]);

  // Re-center whenever the top view is entered
  useEffect(() => {
    if (!top || !ortho || !orthoControls.current) return;
    orthoControls.current.target.set(...TOP_TARGET);
    ortho.position.set(...TOP_POSITION);
    orthoControls.current.update();
  }, [top, ortho]);

  return (
    <>
      <PerspectiveCamera ref={setPersp} makeDefault={!top} position={CAMERA_POSITION} fov={DEFAULT_FOV} />
      <OrthographicCamera ref={setOrtho} makeDefault={top} position={TOP_POSITION} up={TOP_UP} near={0.1} far={50} />
      {persp && (
        <OrbitControls
          ref={perspControls}
          camera={persp}
          enabled={!top}
          target={ORBIT_TARGET}
          maxPolarAngle={Math.PI / 2.05}
          minDistance={2}
          maxDistance={CAMERA_DISTANCE * 1.2}
        />
      )}
      {ortho && (
        <OrbitControls
          ref={orthoControls}
          camera={ortho}
          enabled={top}
          enableRotate={false}
          screenSpacePanning
          target={TOP_TARGET}
        />
      )}
    </>
  );
}

function FloorSelect({ floor, onFloor }) {
  return (
    <select
      className={styles.rackSelect}
      value={floor}
      onChange={(e) => onFloor(Number(e.target.value))}
      aria-label="Floor"
      title="Building overview or a floor's server hall"
    >
      <option value={0}>Building</option>
      {Array.from({ length: FLOOR_COUNT }, (_, i) => (
        <option key={i + 1} value={i + 1}>
          Floor {String(i + 1).padStart(2, "0")}
        </option>
      ))}
    </select>
  );
}

function ViewToolbar({ floor, onFloor, fanSpeed, onFanSpeed, top, thermal, cfd, cfdMode, onCfdMode, racks, selectedRackId, onToggleTop, onToggleThermal, onToggleCfd, onFocusRack }) {
  return (
    <>
      {/* Shared temperature scale: thermal colours surfaces, CFD colours the air */}
      {floor > 0 && (thermal || cfd) && (
        <div className={styles.legend}>
          <span>{THERMAL_STOPS[0][0]} °C</span>
          <span className={styles.legendBar} style={{ background: LEGEND_GRADIENT }} />
          <span>{THERMAL_STOPS.at(-1)[0]} °C</span>
        </div>
      )}
      <div className={styles.viewToolbar}>
        <FloorSelect floor={floor} onFloor={onFloor} />
        {floor > 0 && (
          <>
        <span className={styles.divider} aria-hidden="true" />
        <button className={`${styles.toolButton} ${top ? styles.active : ""}`} onClick={onToggleTop} aria-pressed={top}>
          Top view
        </button>
        <button
          className={`${styles.toolButton} ${thermal ? styles.active : ""}`}
          onClick={onToggleThermal}
          aria-pressed={thermal}
        >
          Thermal
        </button>
        <button
          className={`${styles.toolButton} ${cfd ? styles.active : ""}`}
          onClick={onToggleCfd}
          aria-pressed={cfd}
          title="Airflow (CFD): streamlines coloured by air temperature"
        >
          CFD
        </button>
        {/* CFD display style, shown while CFD is on */}
        {cfd && (
          <span className={styles.segmented} role="group" aria-label="CFD style">
            {[
              ["lines", "Lines"],
              ["smoke", "Smoke"],
            ].map(([value, label]) => (
              <button
                key={value}
                className={`${styles.segment} ${cfdMode === value ? styles.segmentOn : ""}`}
                onClick={() => onCfdMode(value)}
                aria-pressed={cfdMode === value}
              >
                {label}
              </button>
            ))}
          </span>
        )}
        {/* HVAC exhaust fan speed: drives the return-fan suction and duct airflow in the CFD */}
        {cfd && (
          <label className={styles.fanControl} title="HVAC exhaust fan speed">
            <span>Fans</span>
            <input
              type="range"
              min={0}
              max={200}
              step={10}
              value={Math.round(fanSpeed * 100)}
              onChange={(e) => onFanSpeed(Number(e.target.value) / 100)}
              aria-label="Exhaust fan speed"
            />
            <span className={styles.fanValue}>{Math.round(fanSpeed * 100)}%</span>
          </label>
        )}
        {racks.length > 0 && (
          <>
            <span className={styles.divider} aria-hidden="true" />
            {/* 48 racks: a dropdown grouped by row (left to right across the hall) instead of buttons */}
            <select
              className={styles.rackSelect}
              value={selectedRackId ?? ""}
              onChange={(e) => {
                const rack = racks.find((r) => r.id === e.target.value);
                if (rack) onFocusRack(rack);
              }}
              aria-label="Go to rack"
            >
              <option value="" disabled>
                Go to rack…
              </option>
              {ROW_ORDER.map((row) => {
                const inRow = racks.filter((r) => r.row === row).sort((a, b) => a.slot - b.slot);
                return (
                  inRow.length > 0 && (
                    <optgroup key={row} label={`Row ${row}`}>
                      {inRow.map((rack) => (
                        <option key={rack.id} value={rack.id}>
                          {rack.name}
                        </option>
                      ))}
                    </optgroup>
                  )
                );
              })}
            </select>
          </>
        )}
          </>
        )}
      </div>
    </>
  );
}

function useGrille(holes, repeatX, repeatY) {
  const textures = useMemo(() => {
    const t = grilleTextures(holes);
    t.map.repeat.set(repeatX, repeatY);
    t.bump.repeat.set(repeatX, repeatY);
    return t;
  }, [holes, repeatX, repeatY]);
  useEffect(() => () => [textures.map, textures.bump].forEach((t) => t.dispose()), [textures]);
  return textures;
}

// Raised floor of steel grille tiles with square cooling holes; the cold aisle tiles are
// more open (higher airflow) than the rest
function Floor({ aisleLength }) {
  const floor = useGrille(12, (FLOOR_HALF_X * 2) / TILE, aisleLength / TILE);
  const aisle = useGrille(18, COLD_AISLE / AISLE_TILE, aisleLength / AISLE_TILE);
  const steel = { metalness: 0.55, roughness: 0.5, clearcoat: 0.15, bumpScale: 1.5 };

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[FLOOR_HALF_X * 2, aisleLength]} />
        <meshPhysicalMaterial map={floor.map} bumpMap={floor.bump} {...steel} />
      </mesh>

      {/* Hot aisles: solid (unperforated) tiles, no airflow up through the floor, edged in red */}
      {HOT_AISLES_X.map((hx) => (
        <group key={`hot${hx}`} position={[hx, 0, 0]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]}>
            <planeGeometry args={[HOT_AISLE, aisleLength]} />
            <meshPhysicalMaterial color={HOT_AISLE_TINT} {...steel} />
          </mesh>
          {[-1, 1].map((s) => (
            <mesh key={s} rotation={[-Math.PI / 2, 0, 0]} position={[(s * (HOT_AISLE - AISLE_STRIPE)) / 2, 0.002, 0]}>
              <planeGeometry args={[AISLE_STRIPE, aisleLength]} />
              <meshStandardMaterial color="#8a1c14" roughness={0.6} />
            </mesh>
          ))}
        </group>
      ))}

      {COLD_AISLES_X.map((ax) => (
        <group key={ax} position={[ax, 0, 0]}>
          {/* Cold aisle tiles, aligned to the floor grid */}
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]}>
            <planeGeometry args={[COLD_AISLE, aisleLength]} />
            {/* Tinted grey (multiplies the texture) so the cold aisles read a bit darker than the floor */}
            <meshPhysicalMaterial map={aisle.map} bumpMap={aisle.bump} color={AISLE_TINT} {...steel} />
          </mesh>

          {/* Black stripes along both edges of the cold aisle, marking it off from the rest of the floor */}
          {[-1, 1].map((s) => (
            <mesh key={s} rotation={[-Math.PI / 2, 0, 0]} position={[(s * COLD_AISLE) / 2, 0.002, 0]}>
              <planeGeometry args={[AISLE_STRIPE, aisleLength]} />
              <meshStandardMaterial color="#050505" roughness={0.6} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

// Room boundary: the 12 edges of the hall's box (walls, floor, ceiling) as a faint cyan wireframe
const ROOM_HEIGHT = 4.6; // ceiling, just above the return ducts
function RoomBounds({ halfX, halfZ }) {
  const geometry = useMemo(() => {
    const [x, z, y] = [halfX, halfZ, ROOM_HEIGHT];
    const c = [
      [-x, 0, -z], [x, 0, -z], [x, 0, z], [-x, 0, z],
      [-x, y, -z], [x, y, -z], [x, y, z], [-x, y, z],
    ];
    const edges = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(edges.flatMap(([a, b]) => [...c[a], ...c[b]]), 3));
    return g;
  }, [halfX, halfZ]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return (
    <lineSegments geometry={geometry} raycast={() => null}>
      <lineBasicMaterial color={new THREE.Color(0, 1.1, 1.3)} transparent opacity={0.01} toneMapped={false} />
    </lineSegments>
  );
}

// Each row's rack centres sit at its x, doors facing its cold aisle; slots run along z
function rackTransform(rack, rowCount) {
  const { x, facing } = rowOf(rack.row);
  const z = (rack.slot - (rowCount - 1) / 2) * RACK_PITCH;
  return { position: [x, 0, z], rotation: [0, (facing * Math.PI) / 2, 0] };
}

// Overhead tray above each row, with patch cables linking neighbouring racks
function RowCabling({ racks, rowCount }) {
  return Object.keys(ROWS).map((row) => {
    const inRow = racks.filter((r) => r.row === row);
    if (!inRow.length) return null;
    // Over the rear half of the rack: TRAY_OFFSET is rack-local z, which points the way the doors face
    const x = rowOf(row).x + rowOf(row).facing * TRAY_OFFSET;
    const half = (inRow.length * RACK_PITCH) / 2 + 0.6;
    const zs = inRow.map((r) => rackTransform(r, rowCount(row)).position[2]);
    return (
      <group key={row}>
        <Tray x={x} y={RACK.height + TRAY_RISE} from={-half} to={half} width={0.3} />
        <RackLinks x={x} rackTop={RACK.height} zs={zs} />
      </group>
    );
  });
}

export default function DataCenter() {
  const [floor, setFloor] = useState(0); // 0 = building overview (the start screen), 1…10 = that floor's hall
  const [fanSpeed, setFanSpeed] = useState(1); // HVAC exhaust fans, 0–2 (× nominal)
  const { data, error, loading, seeding, updatedAt, refresh, seed } = usePodData(floor || null);
  const building = useBuilding(floor === 0);
  const [selection, setSelection] = useState({ rackId: null, serverId: null });
  const [top, setTop] = useState(false);
  const [thermal, setThermal] = useState(false);
  const [cfd, setCfd] = useState(false);
  const [cfdMode, setCfdMode] = useState("lines");
  const [focus, setFocus] = useState(null);
  const [openRackId, setOpenRackId] = useState(null);
  const hudElements = useRef({});

  // Changing floor starts fresh: nothing selected or open, perspective view
  const goToFloor = (f) => {
    setFloor(f);
    setSelection({ rackId: null, serverId: null });
    setOpenRackId(null);
    setFocus(null);
    setTop(false);
  };

  // Rack placement for the building view's miniature racks (every floor has the same layout)
  const buildingLayout = useMemo(() => {
    const floorRacks = building.data?.floors?.[0]?.racks ?? [];
    const count = (row) => floorRacks.filter((r) => r.row === row).length;
    const rows = Math.max(...Object.keys(ROWS).map(count), 1);
    const len = (Math.ceil((rows * RACK_PITCH) / AISLE_TILE) * AISLE_TILE + AISLE_EXTENSION * 2) * FLOOR_SCALE;
    return {
      halfX: FLOOR_HALF_X,
      halfZ: len / 2,
      place: (r) => rackTransform(r, count(r.row)).position,
      facing: (r) => rowOf(r.row).facing, // doors face +x (1) or −x (−1)
    };
  }, [building.data]);

  const racks = data?.pod?.racks ?? [];
  const rowCount = (row) => racks.filter((r) => r.row === row).length;
  const maxRow = Math.max(...Object.keys(ROWS).map(rowCount), 1);
  // Whole large tiles so the strip stays aligned to the floor grid, running AISLE_EXTENSION past
  // the racks at each end like a road
  const aisleLength = (Math.ceil((maxRow * RACK_PITCH) / AISLE_TILE) * AISLE_TILE + AISLE_EXTENSION * 2) * FLOOR_SCALE;

  // World placement of every rack for the airflow view (memoised: the streamlines rebuild only
  // when the pod data changes)
  const flowRacks = useMemo(
    () =>
      racks.map((rack) => {
        const { position } = rackTransform(rack, rowCount(rack.row));
        const { facing } = rowOf(rack.row);
        return { rack, x: position[0], z: position[2], facing, coldX: position[0] + facing * ROW_X };
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [racks]
  );

  // Pair up the racks facing each other across each cold aisle, slot by slot
  const areaLights = AISLES.flatMap(([ax, minus, plus]) =>
    Array.from({ length: maxRow }, (_, slot) => {
      const pair = racks.filter((r) => (r.row === minus || r.row === plus) && r.slot === slot);
      if (!pair.length) return [];
      const z = rackTransform(pair[0], rowCount(pair[0].row)).position[2];
      return [{ key: `${ax}:${slot}`, position: [ax, AREA_LIGHT.y, z], color: areaColor(pair) }];
    }).flat()
  );

  // Resolve against the latest data so the panel reflects file edits
  const selectedRack = racks.find((r) => r.id === selection.rackId) ?? null;
  const selectedServer = selectedRack?.servers.find((s) => s.id === selection.serverId) ?? null;

  const selectRack = (rackId) =>
    setSelection((s) => (s.rackId === rackId ? s : { rackId, serverId: null }));
  const selectServer = (rackId, serverId) =>
    setSelection((s) => (s.serverId === serverId ? { rackId, serverId: null } : { rackId, serverId }));
  // Only one rack open at a time: opening another closes the previous one,
  // and its pulled-out server slides back in because the selection moves with it
  const openRack = (rackId) => {
    setOpenRackId(rackId);
    selectRack(rackId);
  };
  // From a server card in the panel: open that rack and pull the server out
  // (clicking the already-selected card pushes it back in)
  const pickServer = (rackId, serverId) => {
    setOpenRackId(rackId);
    setSelection((s) => (s.serverId === serverId ? { rackId, serverId: null } : { rackId, serverId }));
  };
  const closeRack = (rackId) => {
    setOpenRackId((id) => (id === rackId ? null : id));
    setSelection((s) => (s.rackId === rackId ? { rackId, serverId: null } : s));
  };

  // From the toolbar: open the rack's door (closing any other open rack) and fly the perspective
  // camera to an angled view of it, leaving the top view if needed
  const focusRack = (rack) => {
    const { position } = rackTransform(rack, rowCount(rack.row));
    const { facing } = rowOf(rack.row); // doors face the rack's cold aisle
    openRack(rack.id);
    setTop(false);
    setFocus({
      front: [position[0] + (facing * RACK.depth) / 2, RACK.height / 2, position[2]],
      normal: [facing, 0, 0],
      side: [0, 0, -facing], // rack-local +x (the door's handle side) after the row's rotation
    });
  };

  // Status tag per rack, anchored just above the top front edge (the door side, facing the aisle)
  const huds = racks.map((rack) => {
    const { position } = rackTransform(rack, rowCount(rack.row));
    const { facing } = rowOf(rack.row);
    return {
      id: rack.id,
      name: rack.name,
      health: rackHealth(rack),
      anchor: [position[0] + (facing * RACK.depth) / 2, RACK.height + 0.16, position[2]],
      // World bounding box of the rack (rotated 90°: depth along x, width along z), used to
      // hide tags that a rack stands in front of
      box: [
        [position[0] - RACK.depth / 2, 0, position[2] - RACK.width / 2],
        [position[0] + RACK.depth / 2, RACK.height, position[2] + RACK.width / 2],
      ],
    };
  });

  return (
    <div className={styles.root}>
      <header className={styles.topbar}>
        <h1 className={styles.brand}>
          DC Tower · {floor ? `Floor ${String(floor).padStart(2, "0")}` : "Building"}
        </h1>
        <div className={styles.sync}>
          {floor === 0 ? (
            building.error ? (
              <span className={styles.error}>Load failed: {building.error}</span>
            ) : (
              <span>{FLOOR_COUNT} floors · pick one to go inside</span>
            )
          ) : error ? (
            <span className={styles.error}>Load failed: {error}</span>
          ) : (
            updatedAt && <span>Synced {updatedAt.toLocaleTimeString()}</span>
          )}
          {floor > 0 && (
            <>
              <button className={styles.button} onClick={refresh} disabled={loading || seeding}>
                {loading ? "Refreshing…" : "Refresh"}
              </button>
              {/* Seeds the selected floor only */}
              <button className={styles.button} onClick={seed} disabled={loading || seeding} title={`Seed floor ${floor}`}>
                {seeding ? "Seeding…" : "Seed"}
              </button>
            </>
          )}
        </div>
      </header>

      <div className={styles.split}>
        <div className={styles.viewport}>
          {floor === 0 ? (
            <Building data={building.data} layout={buildingLayout} onSelectFloor={goToFloor} />
          ) : (
          <>
          <Canvas>
            <color attach="background" args={["#04070c"]} />

            <Cameras
              top={top}
              extentX={2 * FLOOR_HALF_X + 1.2}
              extentZ={maxRow * RACK_PITCH + 1.2}
              focus={focus}
            />

            {/* Lighting: city environment for reflections on the metals, soft ambient fill, and a
                point light over the cold aisle, halfway between the rack tops and the network line.
                The environment only lights the scene; the background stays plain white. */}
            {/* The preset's HDR is downloaded from a CDN; its own Suspense keeps the scene from waiting on it */}
            <Suspense fallback={null}>
              {/* <Environment preset="city" /> */}
            </Suspense>
            <ambientLight intensity={0.5} />
            {/* One dim point light per facing rack pair, tinted by the pair's health */}
            {areaLights.map((l) => (
              <pointLight key={l.key} position={l.position} color={l.color} intensity={AREA_LIGHT.intensity} distance={AREA_LIGHT.distance} />
            ))}
            {/* Dimmer fill over each hot aisle, so the rear grills and cabling stay visible */}
            {HOT_AISLES_X.map((hx) => (
              <pointLight key={`hot${hx}`} position={[hx, RACK.height + 0.8, 0]} intensity={4} />
            ))}

            <Floor aisleLength={aisleLength} />
            <RoomBounds halfX={FLOOR_HALF_X} halfZ={aisleLength / 2} />

            {racks.map((rack) => (
              <ServerRack
                key={rack.id}
                rack={rack}
                {...rackTransform(rack, rowCount(rack.row))}
                aisleOffset={ROW_X}
                thermal={thermal}
                topView={top}
                open={openRackId === rack.id}
                selectedServerId={selection.rackId === rack.id ? selection.serverId : null}
                onOpen={openRack}
                onClose={closeRack}
                onSelectServer={selectServer}
              />
            ))}

            {cfd && (
              <Airflow
                racks={flowRacks}
                coldAislesX={COLD_AISLES_X}
                coldAisle={COLD_AISLE}
                hotAislesX={HOT_AISLES_X}
                hotAisle={HOT_AISLE}
                floorHalfX={FLOOR_HALF_X}
                aisleLength={aisleLength}
                mode={cfdMode}
                fanSpeed={fanSpeed}
              />
            )}

            {/* Hot-air returns: ducts over the hot aisles joined to a single exhaust */}
            <HVAC returnsX={RETURNS_X} aisleLength={aisleLength} xray={cfd} fanSpeed={fanSpeed} />

            <HudProjector huds={huds} elements={hudElements} visible={!top} />
            <RowCabling racks={racks} rowCount={rowCount} />
            {/* Each cold aisle has its own overhead network + power lines and light fixtures */}
            {COLD_AISLES_X.map((ax) => (
              <group key={ax} position={[ax, 0, 0]}>
                <AisleBundle length={aisleLength} />
                <AisleLights length={aisleLength} />
              </group>
            ))}

            <EffectComposer>
              <Bloom mipmapBlur luminanceThreshold={1} intensity={1.2} />
              {/* <ToneMapping mode={ToneMappingMode.ACES_FILMIC} /> */}
            </EffectComposer>
          </Canvas>

          {/* Rack status tags (hidden in the top view), positioned by HudProjector */}
          <HudOverlay huds={huds} elements={hudElements} />
          </>
          )}

          <ViewToolbar
            floor={floor}
            onFloor={goToFloor}
            fanSpeed={fanSpeed}
            onFanSpeed={setFanSpeed}
            top={top}
            thermal={thermal}
            cfd={cfd}
            cfdMode={cfdMode}
            onCfdMode={setCfdMode}
            racks={racks}
            selectedRackId={selection.rackId}
            onToggleTop={() => setTop((t) => !t)}
            onToggleThermal={() => setThermal((t) => !t)}
            onToggleCfd={() => setCfd((c) => !c)}
            onFocusRack={focusRack}
          />
        </div>

        {/* Only mounted when something is selected, so the canvas takes the full width otherwise */}
        <DetailsPanel
          rack={floor ? selectedRack : null}
          server={selectedServer}
          onClose={() => setSelection({ rackId: null, serverId: null })}
          onPickServer={pickServer}
        />
      </div>
    </div>
  );
}
