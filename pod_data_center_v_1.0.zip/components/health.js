// Rack health from its servers' active/inactive status:
//   alert   – more than 2 inactive, or under 1/3 of servers active (orange triangle)
//   perfect – every server active
//   good    – at least 2/3 active
//   bad     – anything in between
export const HEALTH = {
  perfect: { label: "Perfect", color: "#39ff7a" },
  good: { label: "Good", color: "#9be15d" },
  bad: { label: "Bad", color: "#ffb020" },
  alert: { label: "Alert", color: "#ff8a00" },
};

export const isActive = (server) => server.status === "active";

export function rackHealth(rack) {
  const total = rack.servers.length;
  const active = rack.servers.filter(isActive).length;
  const inactive = total - active;
  const ratio = total ? active / total : 0;

  let level;
  if (inactive > 2 || ratio < 1 / 3) level = "alert";
  else if (inactive === 0) level = "perfect";
  else if (ratio >= 2 / 3) level = "good";
  else level = "bad";

  return { level, ...HEALTH[level], active, inactive, total };
}
