import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, PerspectiveCamera } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import { RACK } from "./rackGeometry";
import { tempColor } from "./thermal";
import { HEALTH } from "./health";
import styles from "@/styles/DataCenter.module.css";

// Exterior of the data-centre building at night: a glass lobby with a lit canopy at street level
// and ten data floors above it, clad in dark metal panels with vertical white light strips (one
// side in bronze), topped by a parapet and rooftop plant. Hovering a floor peels its facade away
// to show the hall inside: its racks as miniature blocks in their real positions, coloured by
// a status light in the rack's health colour, on a lit hall floor, with an outline and a label. Click it (or pick it in the toolbar)
// to go inside to that floor's server hall.

export const FLOOR_COUNT = 10;
const STOREY = 4.6; // floor-to-ceiling, matching the hall's room height
const SLAB = 0.35;
const LEVEL = STOREY + SLAB;
const LOBBY = 5.2; // street-level lobby below the data floors
const CLAD = 0.45; // facade standing proud of the hall on each side
const STRIP_PITCH = 2.2; // spacing of the facade's vertical light-strip columns
const POLL_MS = 5000;

const EDGE = {
  ok: new THREE.Color(0, 1.0, 1.25), // cyan
  warn: new THREE.Color(1.4, 0.9, 0.05), // amber
  alert: new THREE.Color(1.6, 0.15, 0.1), // red
  hover: new THREE.Color(0.3, 1.8, 0.6), // green, like a selected rack
};
const floorState = (f) => (f.alerts >= 8 ? "alert" : f.alerts >= 3 ? "warn" : "ok");

const concrete = new THREE.MeshStandardMaterial({ color: "#1b2027", roughness: 0.85, metalness: 0.1 });
const panel = new THREE.MeshStandardMaterial({ color: "#5d6671", roughness: 0.4, metalness: 0.45 });
const bronze = new THREE.MeshStandardMaterial({ color: "#6b5340", roughness: 0.45, metalness: 0.45 });
const seam = new THREE.MeshStandardMaterial({ color: "#16191d", roughness: 0.7, metalness: 0.4 });
const strip = new THREE.MeshBasicMaterial({ color: new THREE.Color(2.2, 2.3, 2.5), toneMapped: false });
const warmGlass = new THREE.MeshStandardMaterial({
  color: "#2b2117",
  emissive: "#ffb066",
  emissiveIntensity: 0.55,
  transparent: true,
  opacity: 0.85,
  roughness: 0.2,
});
const glass = new THREE.MeshPhysicalMaterial({
  color: "#cfe3f5", // clear glazing: the opened floor reads as a normal hall, not a heat map
  transparent: true,
  opacity: 0.06,
  roughness: 0.05,
  depthWrite: false,
  side: THREE.DoubleSide,
});
const pickMaterial = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false, colorWrite: false });
const foliage = new THREE.MeshStandardMaterial({ color: "#163b22", roughness: 0.9 });
const bark = new THREE.MeshStandardMaterial({ color: "#2b2118", roughness: 0.9 });
const lampGlow = new THREE.MeshBasicMaterial({ color: new THREE.Color(2.5, 2.2, 1.6), toneMapped: false });
const noRaycast = () => null;

// Revealed hall interior: powder-coated cabinets, a tiled floor, and status lights (bloom-bright)
const cabinet = new THREE.MeshStandardMaterial({ color: "#23272d", metalness: 0.55, roughness: 0.45 });
const hallFloor = new THREE.MeshStandardMaterial({ color: "#3a414b", metalness: 0.3, roughness: 0.7 });
const LED_COLORS = Object.fromEntries(
  Object.entries(HEALTH).map(([k, v]) => [k, new THREE.Color(v.color).multiplyScalar(2.2)])
);

// Polls the building summary while the building view is open
export function useBuilding(enabled = true) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const load = useCallback(async () => {
    if (!enabled) return;
    try {
      const res = await fetch("/api/building", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
      setError(null);
    } catch (err) {
      setError(err.message);
    }
  }, [enabled]);
  useEffect(() => {
    if (!enabled) return undefined;
    load();
    const id = setInterval(load, POLL_MS);
    return () => clearInterval(id);
  }, [load, enabled]);
  return { data, error, refresh: load };
}

// Text label drawn on a canvas, shown on a revealed floor
function labelTexture(lines, color) {
  const c = document.createElement("canvas");
  c.width = 1024;
  c.height = 256;
  const g = c.getContext("2d");
  g.fillStyle = "rgba(4, 10, 18, 0.85)";
  g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = color;
  g.lineWidth = 6;
  g.strokeRect(3, 3, c.width - 6, c.height - 6);
  g.fillStyle = color;
  g.font = "bold 96px 'Orbitron', Arial, sans-serif";
  g.textBaseline = "top";
  g.fillText(lines[0], 36, 26);
  g.fillStyle = "#b9d3e6";
  g.font = "48px 'JetBrains Mono', monospace";
  g.fillText(lines[1], 40, 160);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function boxEdges(w, h, d) {
  const [x, y, z] = [w / 2, h / 2, d / 2];
  const c = [[-x, -y, -z], [x, -y, -z], [x, -y, z], [-x, -y, z], [-x, y, -z], [x, y, -z], [x, y, z], [-x, y, z]];
  const e = [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]];
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(e.flatMap(([a, b]) => [...c[a], ...c[b]]), 3));
  return g;
}

// Deterministic random, so the light-strip pattern is the same every visit
function rng(seed) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

// Light-strip layout: per face, columns along the facade, each lit over a run of floors (like
// the reference building's staggered vertical LEDs). Returns, per floor, the strip positions.
function stripLayout(halfX, halfZ) {
  const r = rng(20261016);
  const faces = [
    { axis: "x", fixed: halfZ + CLAD, normal: 1, span: halfX }, // front (+z)
    { axis: "x", fixed: -(halfZ + CLAD), normal: -1, span: halfX }, // back
    { axis: "z", fixed: halfX + CLAD, normal: 1, span: halfZ }, // right (+x)
    { axis: "z", fixed: -(halfX + CLAD), normal: -1, span: halfZ }, // left
  ];
  const perFloor = Array.from({ length: FLOOR_COUNT }, () => []);
  for (const f of faces) {
    for (let a = -f.span + STRIP_PITCH / 2; a < f.span; a += STRIP_PITCH) {
      if (r() < 0.35) continue; // some columns stay dark
      const len = 2 + Math.floor(r() * 8);
      const start = Math.floor(r() * (FLOOR_COUNT - len + 1));
      for (let fl = start; fl < start + len; fl++) perFloor[fl].push({ ...f, at: a });
    }
  }
  return perFloor;
}

function Storey({ info, layout, strips, revealed, onHover, onSelect }) {
  const { halfX, halfZ, place, facing } = layout;
  const w = halfX * 2;
  const d = halfZ * 2;
  const state = floorState(info);

  // Racks as they look in the normal (non-thermal) hall: dark cabinets, each with a status light
  // on its door in the rack's health colour (instanced)
  const racks = useRef();
  const leds = useRef();
  useEffect(() => {
    const m = racks.current;
    const l = leds.current;
    if (!m || !l) return;
    const o = new THREE.Object3D();
    info.racks.forEach((r, i) => {
      const [x, , z] = place(r);
      o.position.set(x, SLAB + RACK.height / 2, z);
      o.updateMatrix();
      m.setMatrixAt(i, o.matrix);
      // Light on the door face (the side facing the cold aisle), near the top
      o.position.set(x + facing(r) * (RACK.depth / 2 + 0.03), SLAB + RACK.height - 0.25, z);
      o.updateMatrix();
      l.setMatrixAt(i, o.matrix);
      l.setColorAt(i, LED_COLORS[r.level] ?? LED_COLORS.good);
    });
    m.instanceMatrix.needsUpdate = true;
    l.instanceMatrix.needsUpdate = true;
    if (l.instanceColor) l.instanceColor.needsUpdate = true;
  }, [info, place, facing]);

  const edges = useMemo(() => boxEdges(w, STOREY, d), [w, d]);
  useEffect(() => () => edges.dispose(), [edges]);

  const nn = String(info.floor).padStart(2, "0");
  const labelColor = state === "alert" ? "#ff4d4d" : state === "warn" ? "#ffc23a" : "#00e5ff";
  const label = useMemo(
    () => labelTexture([`FLOOR ${nn}`, `${info.racks.length} racks · ${info.alerts} alert · ${info.avgTemp?.toFixed(1) ?? "–"} °C avg`], labelColor),
    [nn, info.racks.length, info.alerts, info.avgTemp, labelColor]
  );
  useEffect(() => () => label.dispose(), [label]);

  const W = w + CLAD * 2;
  const D = d + CLAD * 2;

  return (
    <group position={[0, LOBBY + (info.floor - 1) * LEVEL, 0]}>
      {/* Floor slab, showing as a thin band between storeys */}
      <mesh position={[0, SLAB / 2, 0]} material={seam} raycast={noRaycast}>
        <boxGeometry args={[W + 0.06, SLAB, D + 0.06]} />
      </mesh>

      {/* Facade: dark panels (bronze on the +x side) with the light strips; peeled away on hover */}
      <group visible={!revealed}>
        <mesh position={[0, SLAB + STOREY / 2, 0]} material={panel} raycast={noRaycast}>
          <boxGeometry args={[W, STOREY, D]} />
        </mesh>
        <mesh position={[W / 2 + 0.005, SLAB + STOREY / 2, 0]} material={bronze} raycast={noRaycast}>
          <boxGeometry args={[0.02, STOREY, D]} />
        </mesh>
        {strips.map((s, i) => (
          <mesh
            key={i}
            position={
              s.axis === "x"
                ? [s.at, SLAB + STOREY / 2, s.fixed + s.normal * 0.03]
                : [s.fixed + s.normal * 0.03, SLAB + STOREY / 2, s.at]
            }
            material={strip}
            raycast={noRaycast}
          >
            <boxGeometry args={s.axis === "x" ? [0.12, STOREY + SLAB, 0.04] : [0.04, STOREY + SLAB, 0.12]} />
          </mesh>
        ))}
      </group>

      {/* Inside, shown when revealed: racks, glass envelope, glowing outline and label */}
      <group visible={revealed}>
        <mesh position={[0, SLAB + 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]} material={hallFloor} raycast={noRaycast}>
          <planeGeometry args={[w, d]} />
        </mesh>
        <instancedMesh ref={racks} args={[null, cabinet, info.racks.length]} raycast={noRaycast}>
          <boxGeometry args={[RACK.depth, RACK.height, RACK.width]} />
        </instancedMesh>
        <instancedMesh ref={leds} args={[null, null, info.racks.length]} raycast={noRaycast}>
          <boxGeometry args={[0.06, 0.12, 0.3]} />
          <meshBasicMaterial toneMapped={false} />
        </instancedMesh>
        {/* Hall lighting while the floor is open */}
        {revealed && <pointLight position={[0, SLAB + STOREY - 0.6, 0]} intensity={90} distance={40} color="#dfe8ff" />}
        <mesh position={[0, SLAB + STOREY / 2, 0]} material={glass} raycast={noRaycast}>
          <boxGeometry args={[w, STOREY, d]} />
        </mesh>
        <lineSegments geometry={edges} position={[0, SLAB + STOREY / 2, 0]} raycast={noRaycast}>
          <lineBasicMaterial color={EDGE.hover} toneMapped={false} />
        </lineSegments>
        <lineSegments geometry={edges} position={[0, SLAB + STOREY / 2, 0]} scale={[W / w, 1, D / d]} raycast={noRaycast}>
          <lineBasicMaterial color={EDGE[state]} transparent opacity={0.01} toneMapped={false} />
        </lineSegments>
        <mesh position={[-halfX + 3.2, SLAB + STOREY - 1, D / 2 + 0.05]} raycast={noRaycast}>
          <planeGeometry args={[6, 1.5]} />
          <meshBasicMaterial map={label} transparent toneMapped={false} />
        </mesh>
      </group>

      {/* Invisible pick volume for hover / click */}
      <mesh
        position={[0, SLAB + STOREY / 2, 0]}
        material={pickMaterial}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHover(info.floor);
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          onHover(null);
          document.body.style.cursor = "auto";
        }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(info.floor);
        }}
      >
        <boxGeometry args={[W, STOREY + SLAB, D]} />
      </mesh>
    </group>
  );
}

// Street level: glass lobby with a warm interior, columns and a lit canopy wrapping the front
function Lobby({ halfX, halfZ }) {
  const W = (halfX + CLAD) * 2;
  const D = (halfZ + CLAD) * 2;
  const columns = [];
  for (let x = -W / 2 + 1; x <= W / 2 - 1; x += 3.2) columns.push(x);
  return (
    <group>
      <mesh position={[0, LOBBY / 2, 0]} material={warmGlass} raycast={noRaycast}>
        <boxGeometry args={[W - 1.6, LOBBY, D - 1.6]} />
      </mesh>
      {columns.map((x) => (
        <mesh key={x} position={[x, LOBBY / 2, D / 2 - 0.5]} material={seam} raycast={noRaycast}>
          <boxGeometry args={[0.35, LOBBY, 0.35]} />
        </mesh>
      ))}
      {/* Canopy slab overhanging the front and right side, with a light line under its edge */}
      <mesh position={[0.9, LOBBY - 0.6, 1.2]} material={concrete} raycast={noRaycast}>
        <boxGeometry args={[W + 1.8, 0.45, D + 2.4]} />
      </mesh>
      <mesh position={[0.9, LOBBY - 0.86, D / 2 + 2.38]} material={strip} raycast={noRaycast}>
        <boxGeometry args={[W + 1.8, 0.05, 0.08]} />
      </mesh>
      <mesh position={[W / 2 + 1.78, LOBBY - 0.86, 1.2]} material={strip} raycast={noRaycast}>
        <boxGeometry args={[0.08, 0.05, D + 2.4]} />
      </mesh>
    </group>
  );
}

function Tree({ position, scale = 1 }) {
  return (
    <group position={position} scale={scale}>
      <mesh position={[0, 1, 0]} material={bark} raycast={noRaycast}>
        <cylinderGeometry args={[0.12, 0.16, 2, 6]} />
      </mesh>
      <mesh position={[0, 2.8, 0]} material={foliage} raycast={noRaycast}>
        <icosahedronGeometry args={[1.4, 1]} />
      </mesh>
    </group>
  );
}

function Lamp({ position }) {
  return (
    <group position={position}>
      <mesh position={[0, 2.5, 0]} material={seam} raycast={noRaycast}>
        <cylinderGeometry args={[0.06, 0.08, 5, 6]} />
      </mesh>
      <mesh position={[0, 5.05, 0]} material={lampGlow} raycast={noRaycast}>
        <sphereGeometry args={[0.18, 10, 8]} />
      </mesh>
    </group>
  );
}

// Plaza, street with lane markings, trees and street lamps around the building
function Street({ halfX, halfZ }) {
  const front = halfZ + CLAD + 6;
  const side = halfX + CLAD + 6;
  const trees = [];
  for (let x = -halfX; x <= halfX + 4; x += 5) trees.push([x, 0, front - 2]);
  for (let z = -halfZ; z <= halfZ; z += 5) trees.push([side - 2, 0, z]);
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} raycast={noRaycast}>
        <planeGeometry args={[400, 400]} />
        <meshStandardMaterial color="#0b0f15" roughness={1} />
      </mesh>
      {/* Plaza around the building */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[2, 0.02, 2]} raycast={noRaycast}>
        <planeGeometry args={[side * 2 + 4, front * 2 + 4]} />
        <meshStandardMaterial color="#2a2f36" roughness={0.9} />
      </mesh>
      {/* Streets along the front and the side, with dashed centre lines */}
      {[
        [0, front + 7, 140, 9, false],
        [side + 7, 0, 9, 140, true],
      ].map(([x, z, w, d, along]) => (
        <group key={`${x}${z}`}>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[x, 0.03, z]} raycast={noRaycast}>
            <planeGeometry args={[w, d]} />
            <meshStandardMaterial color="#14181e" roughness={0.95} />
          </mesh>
          {Array.from({ length: 30 }, (_, i) => -70 + i * 4.8).map((t) => (
            <mesh
              key={t}
              rotation={[-Math.PI / 2, 0, 0]}
              position={along ? [x, 0.04, t] : [t, 0.04, z]}
              raycast={noRaycast}
            >
              <planeGeometry args={along ? [0.15, 2.2] : [2.2, 0.15]} />
              <meshBasicMaterial color="#8a8f96" />
            </mesh>
          ))}
        </group>
      ))}
      {trees.map((p, i) => (
        <Tree key={i} position={p} scale={0.8 + ((i * 37) % 10) / 25} />
      ))}
      {[-halfX, 0, halfX].map((x) => (
        <Lamp key={x} position={[x + 2.5, 0, front + 1.6]} />
      ))}
      {[-halfZ, 0, halfZ].map((z) => (
        <Lamp key={z} position={[side + 1.6, 0, z + 2.5]} />
      ))}
    </group>
  );
}

function Roof({ halfX, halfZ }) {
  const W = (halfX + CLAD) * 2;
  const D = (halfZ + CLAD) * 2;
  const y = LOBBY + FLOOR_COUNT * LEVEL;
  return (
    <group position={[0, y, 0]}>
      <mesh position={[0, SLAB / 2, 0]} material={seam} raycast={noRaycast}>
        <boxGeometry args={[W + 0.06, SLAB, D + 0.06]} />
      </mesh>
      {/* Parapet */}
      {[
        [0, D / 2, W, 0.3],
        [0, -D / 2, W, 0.3],
        [W / 2, 0, 0.3, D],
        [-W / 2, 0, 0.3, D],
      ].map(([x, z, w, d], i) => (
        <mesh key={i} position={[x, SLAB + 0.6, z]} material={panel} raycast={noRaycast}>
          <boxGeometry args={[w, 1.2, d]} />
        </mesh>
      ))}
      {/* Other rooftop plant */}
      {[-0.55, -0.1].map((f) => (
        <mesh key={f} position={[f * halfX, SLAB + 0.8, -halfZ * 0.3]} material={concrete} raycast={noRaycast}>
          <boxGeometry args={[3, 1.6, 2.4]} />
        </mesh>
      ))}
    </group>
  );
}

// ---------- Shared exhaust: riser + main rooftop HVAC ----------
// Every floor's HVAC header feeds a short stub into one vertical exhaust riser running up the
// outside of the bronze (+x) side; at the top it feeds the main rooftop exhaust unit. The riser is
// translucent so the hot exhaust can be seen flowing up it.

const RISER_W = 1.3;
const DUCT_LEVEL = SLAB + 4.1; // the floors' return-duct height above each slab
const MAIN_UNIT = { w: 4.2, h: 2.4 };
const riserGlass = new THREE.MeshPhysicalMaterial({
  color: "#9fb4c8",
  transparent: true,
  opacity: 0.22,
  roughness: 0.2,
  metalness: 0.3,
  depthWrite: false,
});

// Riser position shared by the geometry and the smoke
export function riserAt(halfX, halfZ) {
  return { x: halfX + CLAD + RISER_W / 2 + 0.15, z: halfZ - 0.6, top: LOBBY + FLOOR_COUNT * LEVEL + 1.2 };
}
const floorDuctY = (floor) => LOBBY + (floor - 1) * LEVEL + DUCT_LEVEL;

function MainExhaust({ halfX, halfZ }) {
  const { x, z, top } = riserAt(halfX, halfZ);
  const rotor = useRef();
  useFrame((_, delta) => {
    rotor.current.rotation.y += delta * 5;
  });
  const roofY = LOBBY + FLOOR_COUNT * LEVEL + SLAB;
  return (
    <group>
      {/* Riser up the facade */}
      <mesh position={[x, (LOBBY + top) / 2, z]} material={riserGlass} raycast={noRaycast}>
        <boxGeometry args={[RISER_W, top - LOBBY, RISER_W]} />
      </mesh>
      {/* Per-floor connection stubs (and a flange on the riser) */}
      {Array.from({ length: FLOOR_COUNT }, (_, i) => (
        <group key={i} position={[0, floorDuctY(i + 1), z]}>
          <mesh position={[(halfX + CLAD + x) / 2, 0, 0]} material={seam} raycast={noRaycast}>
            <boxGeometry args={[x - halfX - CLAD, 0.55, 0.9]} />
          </mesh>
          <mesh position={[x, 0, 0]} material={seam} raycast={noRaycast}>
            <boxGeometry args={[RISER_W + 0.12, 0.1, RISER_W + 0.12]} />
          </mesh>
        </group>
      ))}
      {/* Riser elbow over the parapet into the main unit */}
      <mesh position={[x - 1.4, top + 0.4, z]} material={seam} raycast={noRaycast}>
        <boxGeometry args={[2.8 + RISER_W, RISER_W, RISER_W]} />
      </mesh>
      {/* Main rooftop exhaust unit with its big fan, louvres and status light */}
      <group position={[x - 3.6, roofY, z]}>
        <mesh position={[0, MAIN_UNIT.h / 2, 0]} material={concrete} raycast={noRaycast}>
          <boxGeometry args={[MAIN_UNIT.w, MAIN_UNIT.h, MAIN_UNIT.w]} />
        </mesh>
        {[-1, 1].map((sd) =>
          Array.from({ length: 8 }, (_, i) => (
            <mesh key={`${sd}${i}`} position={[0, 0.3 + i * 0.25, sd * (MAIN_UNIT.w / 2 + 0.01)]} rotation={[0, 0, 0]} material={seam} raycast={noRaycast}>
              <boxGeometry args={[MAIN_UNIT.w * 0.85, 0.08, 0.02]} />
            </mesh>
          ))
        )}
        <mesh position={[0, MAIN_UNIT.h + 0.05, 0]} material={seam} raycast={noRaycast}>
          <cylinderGeometry args={[1.6, 1.6, 0.12, 32, 1, true]} />
        </mesh>
        <group ref={rotor} position={[0, MAIN_UNIT.h + 0.05, 0]}>
          {Array.from({ length: 6 }, (_, i) => (
            <mesh key={i} rotation={[0.35, (i / 6) * Math.PI * 2, 0]} position={[Math.cos((i / 6) * Math.PI * 2) * 0.8, 0, -Math.sin((i / 6) * Math.PI * 2) * 0.8]} material={panel} raycast={noRaycast}>
              <boxGeometry args={[1.2, 0.02, 0.5]} />
            </mesh>
          ))}
        </group>
        <mesh position={[MAIN_UNIT.w / 2 + 0.01, MAIN_UNIT.h - 0.4, 0]} rotation={[0, Math.PI / 2, 0]} raycast={noRaycast}>
          <circleGeometry args={[0.08, 12]} />
          <meshBasicMaterial color={new THREE.Color(0.3, 2.5, 0.8)} toneMapped={false} />
        </mesh>
      </group>
    </group>
  );
}

// Hot exhaust smoke: from each floor's stub into the riser, up it, through the main unit and out
// of the fan as a rising, spreading plume. Each floor's smoke starts at its exhaust temperature.
const EXHAUST_COUNT = 1800;

const exhaustVertex = /* glsl */ `
  attribute float size;
  attribute float alpha;
  attribute float puffSeed;
  uniform float uScale;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vSeed;
  void main() {
    vColor = color;
    vAlpha = alpha;
    vSeed = puffSeed;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_PointSize = size * uScale / -mv.z;
    gl_Position = projectionMatrix * mv;
  }
`;

// Soft, noisy-edged puff
const exhaustFragment = /* glsl */ `
  uniform float uTime;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vSeed;
  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  float noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
  }
  void main() {
    vec2 p = gl_PointCoord - 0.5;
    float n = noise(p * 4.0 + vSeed * 31.0 + uTime * 0.4) * 0.6 + noise(p * 9.0 - uTime * 0.3) * 0.4;
    float r = length(p) * 2.0;
    float a = (1.0 - smoothstep(0.3, 1.0, r + (n - 0.5) * 0.8)) * smoothstep(0.2, 0.7, n) * vAlpha;
    if (a < 0.003) discard;
    gl_FragColor = vec4(vColor * (0.75 + 0.5 * n), a);
  }
`;

function ExhaustSmoke({ floors, halfX, halfZ }) {
  const { x: rx, z: rz, top } = riserAt(halfX, halfZ);
  const unitX = rx - 3.6;
  const fanY = LOBBY + FLOOR_COUNT * LEVEL + SLAB + MAIN_UNIT.h;
  const temps = useMemo(() => floors.map((f) => (f.avgTemp ?? 40) + 8), [floors]); // exhaust runs hotter than the server average

  const puffs = useMemo(
    () =>
      Array.from({ length: EXHAUST_COUNT }, (_, i) => ({
        floor: 1 + (i % FLOOR_COUNT),
        t: Math.random(), // phase along the route
        speed: 0.07 + Math.random() * 0.03, // route fraction per second
        jx: (Math.random() - 0.5) * 0.8,
        jz: (Math.random() - 0.5) * 0.8,
        seed: Math.random(),
      })),
    []
  );

  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(EXHAUST_COUNT * 3), 3));
    g.setAttribute("color", new THREE.BufferAttribute(new Float32Array(EXHAUST_COUNT * 3), 3));
    g.setAttribute("size", new THREE.BufferAttribute(new Float32Array(EXHAUST_COUNT), 1));
    g.setAttribute("alpha", new THREE.BufferAttribute(new Float32Array(EXHAUST_COUNT), 1));
    g.setAttribute("puffSeed", new THREE.BufferAttribute(Float32Array.from(puffs, (p) => p.seed), 1));
    return g;
  }, [puffs]);
  useEffect(() => () => geometry.dispose(), [geometry]);

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uScale: { value: 800 }, uTime: { value: 0 } },
        vertexShader: exhaustVertex,
        fragmentShader: exhaustFragment,
        vertexColors: true,
        transparent: true,
        depthWrite: false,
        toneMapped: false,
      }),
    []
  );
  useEffect(() => () => material.dispose(), [material]);

  const col = new THREE.Color();
  useFrame(({ size, camera, clock }, delta) => {
    material.uniforms.uTime.value = clock.elapsedTime;
    material.uniforms.uScale.value = size.height / (2 * Math.tan(THREE.MathUtils.degToRad((camera.fov ?? 45) / 2)));
    const P = geometry.attributes.position.array;
    const C = geometry.attributes.color.array;
    const S = geometry.attributes.size.array;
    const A = geometry.attributes.alpha.array;
    for (let i = 0; i < EXHAUST_COUNT; i++) {
      const p = puffs[i];
      p.t += p.speed * delta;
      if (p.t >= 1) {
        p.t -= 1;
        p.floor = 1 + Math.floor(Math.random() * FLOOR_COUNT);
      }
      const y0 = floorDuctY(p.floor);
      // Route fractions: stub (0–0.08), riser (0.08–0.6), elbow + unit (0.6–0.68), plume (0.68–1)
      const t = p.t;
      let x;
      let y;
      let z;
      let sz;
      let cool = 0;
      if (t < 0.08) {
        const w = t / 0.08;
        x = halfX + CLAD + (rx - halfX - CLAD) * w;
        y = y0;
        z = rz + p.jz * 0.6;
        sz = 0.5;
      } else if (t < 0.6) {
        const w = (t - 0.08) / 0.52;
        x = rx + p.jx * 0.9;
        y = y0 + (top - y0) * w;
        z = rz + p.jz * 0.9;
        sz = 0.6;
      } else if (t < 0.68) {
        const w = (t - 0.6) / 0.08;
        x = rx + (unitX - rx) * w;
        y = top + 0.4 + (fanY - top - 0.4) * w;
        z = rz + p.jz * 0.9;
        sz = 0.8;
      } else {
        // Buoyant plume: rises fast, slows and spreads, drifting with the breeze
        const w = (t - 0.68) / 0.32;
        x = unitX + p.jx * (1 + w * 9) + w * 6;
        y = fanY + 22 * Math.sqrt(w);
        z = rz + p.jz * (1 + w * 9);
        sz = 1.2 + w * 7;
        cool = w;
      }
      P[i * 3] = x;
      P[i * 3 + 1] = y;
      P[i * 3 + 2] = z;
      tempColor(temps[p.floor - 1] - cool * 18, col);
      C[i * 3] = col.r;
      C[i * 3 + 1] = col.g;
      C[i * 3 + 2] = col.b;
      S[i] = sz;
      A[i] = t < 0.68 ? 0.45 : 0.32 * (1 - (t - 0.68) / 0.32);
    }
    for (const n of ["position", "color", "size", "alpha"]) geometry.attributes[n].needsUpdate = true;
  });

  return <points geometry={geometry} material={material} raycast={noRaycast} frustumCulled={false} />;
}

// Hovered floor, or the current one, is shown cut open
export default function Building({ data, layout, currentFloor, onSelectFloor }) {
  const [hovered, setHovered] = useState(null);
  const floors = data?.floors ?? [];
  const { halfX, halfZ } = layout;
  const height = LOBBY + FLOOR_COUNT * LEVEL;
  const strips = useMemo(() => stripLayout(halfX, halfZ), [halfX, halfZ]);

  const stats = floors.find((f) => f.floor === hovered);

  return (
    <>
    <Canvas>
      <color attach="background" args={["#0a1222"]} />
      <fog attach="fog" args={["#0a1222", 160, 420]} />
      {/* Low three-quarter view framing the whole building and the rooftop exhaust plume */}
      <PerspectiveCamera makeDefault position={[height * 1.3, height * 0.42, height * 1.75]} fov={45} far={800} />
      <OrbitControls target={[0, height * 0.62, 0]} maxPolarAngle={Math.PI / 2.02} minDistance={10} maxDistance={300} />
      <hemisphereLight args={["#6f86bd", "#0b0f15", 1.1]} />
      <directionalLight position={[-40, 70, 60]} intensity={1.4} color="#b4c2ff" />
      <directionalLight position={[60, 30, 80]} intensity={0.6} color="#ffd2a6" />
      <pointLight position={[0, 4, halfZ + 6]} intensity={60} distance={30} color="#ffbf80" />

      <Street halfX={halfX} halfZ={halfZ} />
      <Lobby halfX={halfX} halfZ={halfZ} />
      {floors.map((f) => (
        <Storey
          key={f.floor}
          info={f}
          layout={layout}
          strips={strips[f.floor - 1] ?? []}
          revealed={hovered === f.floor || currentFloor === f.floor}
          onHover={setHovered}
          onSelect={onSelectFloor}
        />
      ))}
      <Roof halfX={halfX} halfZ={halfZ} />
      {/* All floors' exhaust joins one riser to the main rooftop HVAC exhaust */}
      <MainExhaust halfX={halfX} halfZ={halfZ} />
      {floors.length > 0 && <ExhaustSmoke floors={floors} halfX={halfX} halfZ={halfZ} />}

      <EffectComposer>
        <Bloom mipmapBlur luminanceThreshold={1} intensity={1.0} />
      </EffectComposer>
    </Canvas>
    {stats && <FloorStats info={stats} />}
    </>
  );
}

// Stats card for the hovered floor, top right of the view
function FloorStats({ info }) {
  const counts = Object.fromEntries(Object.keys(HEALTH).map((k) => [k, info.racks.filter((r) => r.level === k).length]));
  const hottest = info.racks.reduce((m, r) => (r.temp > (m?.temp ?? -Infinity) ? r : m), null);
  const rows = [
    ["Racks", info.racks.length],
    ["Servers active", `${info.serversActive} / ${info.serversTotal}`],
    ["Avg server temp", info.avgTemp != null ? `${info.avgTemp.toFixed(1)} °C` : "–"],
    ["Hottest rack", hottest ? `${hottest.id} · ${hottest.temp.toFixed(1)} °C` : "–"],
    ["Power draw", `${info.powerKw.toFixed(1)} kW`],
  ];
  return (
    <aside className={styles.floorStats} aria-live="polite">
      <p className={styles.kicker}>Floor</p>
      <h2 className={styles.title}>{info.name}</h2>
      <dl className={styles.rows}>
        {rows.map(([k, v]) => (
          <div key={k} className={styles.row}>
            <dt>{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
      <ul className={styles.healthBar}>
        {Object.entries(HEALTH).map(([k, h]) => (
          <li key={k} style={{ color: h.color }}>
            <span className={styles.dot} style={{ background: h.color, color: h.color }} />
            {h.label} <b>{counts[k]}</b>
          </li>
        ))}
      </ul>
      <p className={styles.floorHint}>Click to go inside</p>
    </aside>
  );
}
