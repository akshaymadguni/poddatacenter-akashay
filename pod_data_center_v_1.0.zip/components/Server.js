import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Edges } from "@react-three/drei";
import * as THREE from "three";
import { isActive } from "./health";
import {
  DRAWER_OUT,
  HOT_TEMP,
  LED_X,
  SERVER_DEPTH,
  SERVER_WIDTH,
  SERVER_Z,
  U,
  hashString,
  serverCenterY,
} from "./rackGeometry";
import { faceplateTexture, rearplateTexture } from "./textures";
import { latestTemp } from "./temperature";
import { tempColor } from "./thermal";

const chassisMaterial = new THREE.MeshPhysicalMaterial({
  color: "#2c3036",
  metalness: 0.7,
  roughness: 0.32,
  clearcoat: 0.2,
  clearcoatRoughness: 0.4,
});

const LED_ON = 3.5; // above the bloom threshold so lit LEDs glow
const LED_OFF = 0.04;

const hash01 = (n) => {
  const x = Math.sin(n) * 43758.5453;
  return x - Math.floor(x);
};

// Irregular on/off flicker, like disk/network activity
const activity = (t, seed) => hash01(Math.floor(t * 9 + seed * 17) * 7.31 + seed) > 0.45;

// Green = activity flicker while active. Red = solid when inactive, blinking when active but hot.
function ledLevels(server, t, seed) {
  if (!isActive(server)) return [0, LED_ON];
  const green = activity(t, seed) ? LED_ON : LED_OFF;
  const red = latestTemp(server.temperature) >= HOT_TEMP && Math.floor(t * 2 + seed) % 2 ? LED_ON : LED_OFF;
  return [green, red];
}

function setCursor(value) {
  document.body.style.cursor = value;
}

export default function Server({ server, rackU, out, interactive, thermal, onSelect }) {
  const ref = useRef();
  const [hovered, setHovered] = useState(false);

  const h = server.heightU * U - 0.004;
  const y = serverCenterY(server, rackU);
  const seed = useMemo(() => hashString(server.id) * 100, [server.id]);
  const face = faceplateTexture(server, thermal);
  const rear = rearplateTexture(server);

  const leds = useMemo(
    () =>
      ["#39ff7a", "#ff3030"].map(
        (c) =>
          new THREE.MeshStandardMaterial({
            color: new THREE.Color(c).multiplyScalar(0.15),
            emissive: c,
            emissiveIntensity: 0,
            toneMapped: false,
          })
      ),
    []
  );
  useEffect(() => () => leds.forEach((m) => m.dispose()), [leds]);

  useFrame((state, delta) => {
    ref.current.position.z = THREE.MathUtils.damp(ref.current.position.z, out ? DRAWER_OUT : 0, 8, delta);
    const [green, red] = ledLevels(server, state.clock.elapsedTime, seed);
    leds[0].emissiveIntensity = green;
    leds[1].emissiveIntensity = red;
  });

  const highlight = interactive && (hovered || out);

  return (
    <group ref={ref}>
      <group
        position={[0, y, SERVER_Z]}
        onClick={(e) => {
          if (!interactive) return;
          e.stopPropagation();
          onSelect();
        }}
        // Don't let a double-click on a server reach anything behind it
        onDoubleClick={(e) => {
          if (interactive) e.stopPropagation();
        }}
        onPointerOver={(e) => {
          if (!interactive) return;
          e.stopPropagation();
          setHovered(true);
          setCursor("pointer");
        }}
        onPointerOut={() => {
          setHovered(false);
          setCursor("auto");
        }}
      >
        {/* Keyed so switching view remounts the meshes: reusing the normal-view chassis mesh
            would drop its `material` prop and leave three's default white material */}
        {thermal ? (
          <group key="thermal">
            <mesh>
              <boxGeometry args={[SERVER_WIDTH, h, SERVER_DEPTH]} />
              {/* toneMapped off: show the exact legend colour, not the filmic-compressed one */}
              <meshBasicMaterial color={tempColor(latestTemp(server.temperature))} toneMapped={false} />
              {/* Black outline so neighbouring servers of similar heat stay distinguishable */}
              <Edges color="#000000" />
            </mesh>
            {/* Faceplate details (vents, bays, ports, LED bezels) shaded over the heat colour */}
            <mesh position={[0, 0, SERVER_DEPTH / 2 + 0.0008]}>
              <planeGeometry args={[SERVER_WIDTH, h]} />
              <meshBasicMaterial map={face} transparent depthWrite={false} toneMapped={false} color={highlight ? "#cfe0ff" : "#ffffff"} />
            </mesh>
          </group>
        ) : (
          <group key="normal">
            <mesh material={chassisMaterial}>
              <boxGeometry args={[SERVER_WIDTH, h, SERVER_DEPTH]} />
            </mesh>
            <mesh position={[0, 0, SERVER_DEPTH / 2 + 0.0008]}>
              <planeGeometry args={[SERVER_WIDTH, h]} />
              <meshPhysicalMaterial
                map={face}
                color={highlight ? "#cfe0ff" : "#ffffff"}
                metalness={0.5}
                roughness={0.45}
              />
            </mesh>
            {/* Rear panel, seen through the rear grill: PSUs and the ports the cables plug into */}
            <mesh position={[0, 0, -SERVER_DEPTH / 2 - 0.0008]} rotation={[0, Math.PI, 0]}>
              <planeGeometry args={[SERVER_WIDTH, h]} />
              <meshPhysicalMaterial map={rear} metalness={0.5} roughness={0.45} />
            </mesh>
          </group>
        )}

        {LED_X.map((x, i) => (
          <mesh key={i} position={[x, 0, SERVER_DEPTH / 2 + 0.0018]} rotation={[Math.PI / 2, 0, 0]} material={leds[i]}>
            <cylinderGeometry args={[0.0028, 0.0028, 0.002, 12]} />
          </mesh>
        ))}
      </group>
    </group>
  );
}
