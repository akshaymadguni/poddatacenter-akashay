import { useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import styles from "@/styles/DataCenter.module.css";

// Rack status tags are plain DOM elements in an overlay next to the canvas, positioned every
// frame by <HudProjector> inside the scene. (drei's <Html> mounts a separate React root per tag;
// under React StrictMode in dev, that root could be unmounted after it was re-created, which
// intermittently wiped a tag, typically the first rack's.)

// Tags render at half their CSS size: REF_DISTANCE and the scale limits are all halved together
const REF_DISTANCE = 4; // camera distance at which a tag renders at its CSS size
const MIN_SCALE = 0.25;
const MAX_SCALE = 0.8;

function HealthIcon({ alert, color }) {
  return (
    <svg width="12" height="12" viewBox="0 0 16 16" aria-hidden="true">
      {alert ? (
        <>
          <path d="M8 1.5 15 14.5H1z" fill={color} />
          <path d="M8 6v4M8 11.6v.9" stroke="#111" strokeWidth="1.8" strokeLinecap="round" />
        </>
      ) : (
        <>
          <circle cx="8" cy="8" r="7" fill="#39ff7a" />
          <path d="m4.6 8.2 2.3 2.3 4.6-4.8" stroke="#111" strokeWidth="1.8" fill="none" strokeLinecap="round" />
        </>
      )}
    </svg>
  );
}

// DOM side: one tag per rack, hidden until the projector has placed it
export function HudOverlay({ huds, elements }) {
  return (
    <div className={styles.hudLayer} aria-hidden="true">
      {huds.map(({ id, name, health }) => (
        <div
          key={id}
          ref={(el) => {
            if (el) elements.current[id] = el;
            else delete elements.current[id];
          }}
          className={styles.hud}
          style={{ borderColor: health.color, display: "none" }}
        >
          <HealthIcon alert={health.level === "alert"} color={health.color} />
          <span>{name}</span>
          <span className={styles.hudLabel} style={{ background: health.color }}>
            {health.label}
          </span>
          <span className={styles.hudCount}>
            {health.active}/{health.total}
          </span>
        </div>
      ))}
    </div>
  );
}

const v = new THREE.Vector3();
const hit = new THREE.Vector3();
const ray = new THREE.Ray();
// Tag sizes (CSS px) don't change, so each is measured once rather than forcing a layout per frame
const sizes = new WeakMap();
function tagSize(el) {
  let s = sizes.get(el);
  if (!s && el.offsetWidth) sizes.set(el, (s = [el.offsetWidth, el.offsetHeight]));
  return s ?? [120, 22];
}

// Scene side: projects each tag's world anchor to screen space and moves its DOM element.
// A tag is hidden when a rack stands between it and the camera, and where tags overlap on
// screen only the nearest one stays visible.
export function HudProjector({ huds, elements, visible }) {
  const boxes = useMemo(
    () => huds.map((h) => new THREE.Box3(new THREE.Vector3(...h.box[0]), new THREE.Vector3(...h.box[1]))),
    [huds]
  );

  useFrame(({ camera, size }) => {
    const shown = [];
    huds.forEach(({ id, anchor }) => {
      const el = elements.current[id];
      if (!el) return;
      v.set(...anchor);
      const distance = v.distanceTo(camera.position);
      v.project(camera);
      let onScreen = visible && v.z < 1 && Math.abs(v.x) < 1.2 && Math.abs(v.y) < 1.2;

      // Occluded if the sight line from the camera hits any rack before reaching the anchor
      if (onScreen) {
        ray.origin.copy(camera.position);
        ray.direction.set(...anchor).sub(camera.position).normalize();
        onScreen = !boxes.some((b) => ray.intersectBox(b, hit) && hit.distanceTo(camera.position) < distance - 0.05);
      }
      if (!onScreen) {
        el.style.display = "none";
        return;
      }
      const x = ((v.x + 1) / 2) * size.width;
      const y = ((1 - v.y) / 2) * size.height;
      const scale = THREE.MathUtils.clamp(REF_DISTANCE / distance, MIN_SCALE, MAX_SCALE);
      shown.push({ el, x, y, scale, distance });
    });

    // Nearest first; a tag whose screen box overlaps an already-placed nearer tag is hidden
    shown.sort((a, b) => a.distance - b.distance);
    const placed = [];
    for (const t of shown) {
      const [w0, h0] = tagSize(t.el);
      const w = w0 * t.scale;
      const h = h0 * t.scale;
      const rect = [t.x - w / 2, t.y - h / 2, t.x + w / 2, t.y + h / 2];
      const covered = placed.some((r) => rect[0] < r[2] && rect[2] > r[0] && rect[1] < r[3] && rect[3] > r[1]);
      t.el.style.display = covered ? "none" : "flex";
      if (covered) continue;
      placed.push(rect);
      t.el.style.transform = `translate(${t.x}px, ${t.y}px) translate(-50%, -50%) scale(${t.scale})`;
    }
  });
  return null;
}
