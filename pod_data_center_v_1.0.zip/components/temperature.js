// `temperature` in pod-data.json is a history of readings in °C, oldest first, newest last.
// A plain number is still accepted (treated as a one-reading history).

export const tempHistory = (t) => (Array.isArray(t) ? t : t == null ? [] : [t]);

// The current reading: drives thermal colours, the hot-LED blink and the panel value
export const latestTemp = (t) => {
  const h = tempHistory(t);
  return h[h.length - 1];
};
