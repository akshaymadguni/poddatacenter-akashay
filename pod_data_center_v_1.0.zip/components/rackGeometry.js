// Shared rack/server dimensions (meters) so geometry, faceplate textures and cables line up

export const RACK = { width: 0.9, depth: 1.07, height: 2.0 }; // 1.5x the standard 0.6 m width
export const U = 0.04445; // 1 rack unit
export const PANEL = 0.02; // side/top/back panel thickness
export const DRAWER_OUT = 0.4; // how far a selected server slides out

export const STATUS_COLORS = {
  active: "#39ff7a",
  inactive: "#ff3b3b",
};

export const HOT_TEMP = 75; // °C: an active server at or above this blinks its red fault LED

export const SERVER_WIDTH = RACK.width - PANEL * 2 - 0.08; // 0.78 m, 1.5x the original 0.52 m
// Faceplate / rear panel artwork was laid out for the original 0.52 m server; its fixed x
// positions are multiplied by this so the details spread across the wider face
export const FACE_SCALE = SERVER_WIDTH / 0.52;
export const SERVER_DEPTH = RACK.depth - 0.15;
export const SERVER_Z = -0.02; // chassis center, rack-local z
export const SERVER_FRONT_Z = SERVER_Z + SERVER_DEPTH / 2;
export const SERVER_REAR_Z = SERVER_Z - SERVER_DEPTH / 2;

// Faceplate layout, x measured from the faceplate center
export const LED_X = [-SERVER_WIDTH / 2 + 0.032, -SERVER_WIDTH / 2 + 0.048];
export const PORT_COUNT = 4;
export const PORT_SIZE = [0.013, 0.011];
export const portX = (i) => SERVER_WIDTH / 2 - 0.04 - i * 0.02;

// Rear panel RJ45 ports (rack-local x): 0–1 take the server-to-server patch leads, 2–5 the uplinks
export const REAR_PORT_COUNT = 6;
export const rearPortX = (i) => -SERVER_WIDTH / 2 + 0.05 + i * 0.02;

export function serverCenterY(server, rackU) {
  const base = (RACK.height - rackU * U) / 2; // rails are centered in the rack
  return base + (server.uPosition - 1) * U + (server.heightU * U) / 2;
}

// Stable 0..1 pseudo-random value from a string, for per-server variation
export function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return ((h >>> 0) % 10000) / 10000;
}
