import { useEffect, useMemo, useRef, useState } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
} from "chart.js";
import { Line } from "react-chartjs-2";
import styles from "@/styles/DataCenter.module.css";
import { tempHistory } from "./temperature";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Legend, Tooltip);

// Temperature, CPU and memory histories on one Chart.js line chart, one coloured line each.
// Temperature (°C) reads off the left axis, CPU / memory utilisation (%) off the right (0–100).
// The header doubles as the legend: swatch, name and latest value per series.

// Dark HUD styling to match the panel
const GRID = "rgba(0, 229, 255, 0.08)";
const AXIS = "rgba(0, 229, 255, 0.25)";
const TICK = "#6f8aa0";

// Fixed series: colour, unit and which y axis each reads off (neon tones that read on dark)
const SERIES = [
  { key: "temperature", name: "Temperature", color: "#ff4d5e", unit: "°C", axis: "yTemp" },
  { key: "cpu", name: "CPU", color: "#3da5ff", unit: "%", axis: "yPct" },
  { key: "memory", name: "Memory", color: "#3dffa0", unit: "%", axis: "yPct" },
];

const fmt = (v, unit) => (v == null ? "—" : `${v.toFixed(1)}${unit === "%" ? "" : " "}${unit}`);

export default function MetricsChart({ label, temperature, cpu, memory }) {
  const box = useRef(null);
  const [fontFamily, setFontFamily] = useState();

  // Chart.js draws on a canvas, so hand it the page's resolved UI font (next/font renames it)
  useEffect(() => {
    if (box.current) setFontFamily(getComputedStyle(box.current).fontFamily);
  }, []);

  const histories = { temperature: tempHistory(temperature), cpu: tempHistory(cpu), memory: tempHistory(memory) };
  const series = SERIES.filter((s) => histories[s.key].length);
  const n = Math.max(0, ...series.map((s) => histories[s.key].length));
  // Right-align shorter histories so every series' latest reading sits at "Now"
  const aligned = (h) => [...Array(n - h.length).fill(null), ...h];
  const key = series.map((s) => histories[s.key].join(",")).join("|");

  const data = useMemo(
    () => ({
      labels: Array.from({ length: n }, (_, i) => (i === n - 1 ? "Now" : `−${n - 1 - i}`)),
      datasets: series.map((s) => ({
        label: s.name,
        unit: s.unit,
        data: aligned(histories[s.key]),
        yAxisID: s.axis,
        borderColor: s.color,
        backgroundColor: s.color,
        borderWidth: 2,
        tension: 0.3,
        spanGaps: true,
        // Only the latest reading carries a marker; others appear on hover
        pointRadius: (ctx) => (ctx.dataIndex === n - 1 ? 3.5 : 0),
        pointBorderColor: "#04070c",
        pointBorderWidth: 1.5,
        pointHoverRadius: 5,
        pointHitRadius: 10,
      })),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [key, n]
  );

  const hasTemp = series.some((s) => s.axis === "yTemp");
  const hasPct = series.some((s) => s.axis === "yPct");

  const options = useMemo(() => {
    const font = { family: fontFamily, size: 11 };
    const axis = (title, position, extra) => ({
      position,
      title: { display: true, text: title, color: TICK, font },
      border: { color: AXIS },
      ticks: { color: TICK, font, maxTicksLimit: 5, callback: (v) => String(Number(Number(v).toFixed(1))) },
      ...extra,
    });
    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 300 },
      interaction: { mode: "index", intersect: false }, // tooltip follows the cursor along x
      layout: { padding: { top: 6 } },
      plugins: {
        legend: { display: false }, // the header row is the legend
        tooltip: {
          backgroundColor: "rgba(4, 10, 18, 0.95)",
          borderColor: "rgba(0, 229, 255, 0.4)",
          borderWidth: 1,
          cornerRadius: 0,
          titleColor: TICK,
          bodyColor: "#d7e9f5",
          titleFont: font,
          bodyFont: { ...font, size: 12, weight: "600" },
          boxWidth: 8,
          boxHeight: 8,
          usePointStyle: true,
          padding: 8,
          callbacks: {
            title: (items) => {
              const i = items[0].dataIndex;
              return i === n - 1 ? `Reading ${i + 1} of ${n} (latest)` : `Reading ${i + 1} of ${n}`;
            },
            label: (item) => `${item.dataset.label}: ${fmt(item.parsed.y, item.dataset.unit)}`,
          },
        },
      },
      scales: {
        x: {
          title: { display: true, text: "Readings ago", color: TICK, font },
          grid: { color: GRID },
          border: { color: AXIS },
          // All labels, so "Now" (the latest reading) is never skipped
          ticks: { color: TICK, font, maxRotation: 0, autoSkip: false },
        },
        yTemp: axis("Temp (°C)", "left", { display: hasTemp, grace: "15%", grid: { color: GRID } }),
        // Percent axis on the right; its grid is hidden so the two sets of lines don't clash
        yPct: axis("Utilisation (%)", "right", { display: hasPct, min: 0, max: 100, grid: { drawOnChartArea: false } }),
      },
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fontFamily, n, hasTemp, hasPct]);

  if (!n) return null;

  const latest = (s) => histories[s.key].at(-1);
  const summary = series.map((s) => `${s.name} ${fmt(latest(s), s.unit)}`).join(", ");

  return (
    <div className={styles.trend} ref={box}>
      <span className={styles.trendLabel}>{label}</span>
      <ul className={styles.metricLegend}>
        {series.map((s) => (
          <li key={s.key}>
            <span className={styles.legendLine} style={{ background: s.color, color: s.color }} />
            <span className={styles.legendName}>{s.name}</span>
            <span className={styles.legendValue}>{fmt(latest(s), s.unit)}</span>
          </li>
        ))}
      </ul>

      <div className={styles.trendChart} role="img" aria-label={`${label}, ${n} readings; latest: ${summary}`}>
        <Line data={data} options={options} />
      </div>
    </div>
  );
}
