import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import styles from "@/styles/DataCenter.module.css";

// Rack status tags are plain DOM elements in an overlay next to the canvas, positioned every
// frame by <HudProjector> inside the scene. (drei's <Html> mounts a separate React root per tag;
// under React StrictMode in dev, that root could be unmounted after it was re-created, which
// intermittently wiped a tag, typically the first rack's.)

// Tags render at half their CSS size: REF_DISTANCE and the scale limits are all halved together
const REF_DISTANCE = 4; // camera distance at which a tag renders at its CSS size
const MIN_SCALE = 0.25;
const MAX_SCALE = 0.8;

function HealthIcon({ alert, color }) {
  return (
    <svg width="12" height="12" viewBox="0 0 16 16" aria-hidden="true">
      {alert ? (
        <>
          <path d="M8 1.5 15 14.5H1z" fill={color} />
          <path d="M8 6v4M8 11.6v.9" stroke="#111" strokeWidth="1.8" strokeLinecap="round" />
        </>
      ) : (
        <>
          <circle cx="8" cy="8" r="7" fill="#39ff7a" />
          <path d="m4.6 8.2 2.3 2.3 4.6-4.8" stroke="#111" strokeWidth="1.8" fill="none" strokeLinecap="round" />
        </>
      )}
    </svg>
  );
}

// DOM side: one tag per rack, hidden until the projector has placed it
export function HudOverlay({ huds, elements }) {
  return (
    <div className={styles.hudLayer} aria-hidden="true">
      {huds.map(({ id, name, health }) => (
        <div
          key={id}
          ref={(el) => {
            if (el) elements.current[id] = el;
            else delete elements.current[id];
          }}
          className={styles.hud}
          style={{ borderColor: health.color, display: "none" }}
        >
          <HealthIcon alert={health.level === "alert"} color={health.color} />
          <span>{name}</span>
          <span className={styles.hudLabel} style={{ background: health.color }}>
            {health.label}
          </span>
          <span className={styles.hudCount}>
            {health.active}/{health.total}
          </span>
        </div>
      ))}
    </div>
  );
}

const v = new THREE.Vector3();

// Scene side: projects each tag's world anchor to screen space and moves its DOM element
export function HudProjector({ huds, elements, visible }) {
  useFrame(({ camera, size }) => {
    for (const { id, anchor } of huds) {
      const el = elements.current[id];
      if (!el) continue;
      v.set(...anchor);
      const distance = v.distanceTo(camera.position);
      v.project(camera);
      const onScreen = visible && v.z < 1 && Math.abs(v.x) < 1.2 && Math.abs(v.y) < 1.2;
      el.style.display = onScreen ? "flex" : "none";
      if (!onScreen) continue;
      const x = ((v.x + 1) / 2) * size.width;
      const y = ((1 - v.y) / 2) * size.height;
      const scale = THREE.MathUtils.clamp(REF_DISTANCE / distance, MIN_SCALE, MAX_SCALE);
      el.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%) scale(${scale})`;
      el.style.zIndex = String(Math.round(1000 - distance * 10)); // nearer tags on top
    }
  });
  return null;
}
