import { useCallback, useEffect, useRef, useState } from "react";

const POLL_MS = 3000;

// Loads pod data (public/pod-data.json via the API) and polls it so edits show up without a reload
export default function usePodData(url = "/api/pod-data") {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [updatedAt, setUpdatedAt] = useState(null);
  const lastText = useRef("");

  // Background polls stay silent; only manual refreshes show a loading state
  const load = useCallback(async (manual = false) => {
    if (manual) setLoading(true);
    try {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      // Only re-render the scene when the file actually changed
      if (text !== lastText.current) {
        setData(JSON.parse(text));
        lastText.current = text;
      }
      setError(null);
      setUpdatedAt(new Date());
    } catch (err) {
      setError(err.message); // keep showing the last good data
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    load();
    const id = setInterval(() => load(), POLL_MS);
    return () => clearInterval(id);
  }, [load]);

  const refresh = useCallback(() => load(true), [load]);

  const seed = useCallback(async () => {
    setSeeding(true);
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      if (!res.ok) throw new Error(`Seed failed: HTTP ${res.status}`);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSeeding(false);
    }
  }, [load]);

  return { data, error, loading, seeding, updatedAt, refresh, seed };
}
