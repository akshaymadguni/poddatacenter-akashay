import { useEffect, useMemo, useRef, useState } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  Filler,
  LinearScale,
  LineElement,
  PointElement,
  Tooltip,
} from "chart.js";
import { Line } from "react-chartjs-2";
import styles from "@/styles/DataCenter.module.css";
import { tempHistory } from "./temperature";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Filler, Tooltip);

// A metric history as a stat tile: current value, an area chart of the readings (Chart.js), and
// min / max / change. Used for temperature (°C) and CPU / memory utilisation (%). One series per
// chart, so no legend box: the label above names it. Higher is worse for every metric shown, so a
// rise reads as a warning and a fall as good.

const LINE = "#2563eb";
const GRID = "#e5e7eb";
const TICK = "#6b7280";

// Area fill: grey at 50% opacity under the line, fading to fully transparent at the x-axis.
// Scriptable, because the gradient has to span the chart area, which is known only at draw time.
function greyFade({ chart }) {
  const { ctx, chartArea } = chart;
  if (!chartArea) return "rgba(107, 114, 128, 0.25)"; // first layout pass
  const g = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
  g.addColorStop(0, "rgba(107, 114, 128, 0.5)");
  g.addColorStop(1, "rgba(107, 114, 128, 0)");
  return g;
}

export default function MetricTrend({ label, values, unit, axisTitle, range }) {
  const readings = tempHistory(values); // accepts an array or a single number
  const box = useRef(null);
  const [fontFamily, setFontFamily] = useState();

  // Chart.js draws on a canvas, so hand it the page's resolved UI font (next/font renames it)
  useEffect(() => {
    if (box.current) setFontFamily(getComputedStyle(box.current).fontFamily);
  }, []);

  const n = readings.length;
  const sep = unit === "%" ? "" : " "; // 45.2% but 52.4 °C
  const fmt = (v) => `${v.toFixed(1)}${sep}${unit}`;
  const labels = readings.map((_, i) => (i === n - 1 ? "Now" : `−${n - 1 - i}`));

  const data = useMemo(
    () => ({
      labels,
      datasets: [
        {
          label,
          data: readings,
          borderColor: LINE,
          borderWidth: 2,
          backgroundColor: greyFade,
          fill: "start", // fill down to the bottom of the axis, wherever the scale starts
          tension: 0.3,
          // Only the latest reading carries a marker; others appear on hover
          pointRadius: readings.map((_, i) => (i === n - 1 ? 4 : 0)),
          pointBackgroundColor: LINE,
          pointBorderColor: "#ffffff",
          pointBorderWidth: 2,
          pointHoverRadius: 5,
          pointHitRadius: 12,
        },
      ],
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [readings.join(","), label]
  );

  const options = useMemo(() => {
    const font = { family: fontFamily, size: 11 };
    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 300 },
      interaction: { mode: "index", intersect: false }, // tooltip follows the cursor along x
      layout: { padding: { top: 6, right: 6 } },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#ffffff",
          borderColor: "#d9dde3",
          borderWidth: 1,
          titleColor: TICK,
          bodyColor: "#1f2937",
          titleFont: font,
          bodyFont: { ...font, size: 12, weight: "600" },
          displayColors: false,
          padding: 8,
          callbacks: {
            title: (items) => {
              const i = items[0].dataIndex;
              return i === n - 1 ? `Reading ${i + 1} of ${n} (latest)` : `Reading ${i + 1} of ${n}`;
            },
            label: (item) => fmt(item.parsed.y),
          },
        },
      },
      scales: {
        x: {
          title: { display: true, text: "Readings ago", color: TICK, font },
          grid: { color: GRID },
          border: { color: "#d1d5db" },
          // All labels, so "Now" (the latest reading) is never skipped
          ticks: { color: TICK, font, maxRotation: 0, autoSkip: false },
        },
        y: {
          title: { display: true, text: axisTitle, color: TICK, font },
          // Fixed range for percentages (0–100), otherwise padded around the data
          ...(range ? { min: range[0], max: range[1] } : { grace: "15%" }),
          grid: { color: GRID },
          border: { color: "#d1d5db" },
          // Whole numbers where possible, one decimal on narrow ranges (avoids "31, 31, 30, 30")
          ticks: { color: TICK, font, maxTicksLimit: 5, callback: (v) => String(Number(Number(v).toFixed(1))) },
        },
      },
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fontFamily, n, axisTitle, unit, range?.[0], range?.[1]]);

  if (!n) return null;

  const latest = readings[n - 1];
  const min = Math.min(...readings);
  const max = Math.max(...readings);
  const delta = latest - readings[0];

  return (
    <div className={styles.trend} ref={box}>
      <div className={styles.trendHead}>
        <span className={styles.trendLabel}>{label}</span>
        <span className={styles.trendValue}>{fmt(latest)}</span>
      </div>

      <div
        className={styles.trendChart}
        role="img"
        aria-label={`${label} history, ${n} readings from ${fmt(readings[0])} to ${fmt(latest)}; min ${fmt(min)}, max ${fmt(max)}`}
      >
        <Line data={data} options={options} />
      </div>

      <div className={styles.trendFoot}>
        <span>
          Min {min.toFixed(1)} · Max {max.toFixed(1)}
        </span>
        {n > 1 && (
          <span className={delta > 0.05 ? styles.trendUp : delta < -0.05 ? styles.trendDown : undefined}>
            {delta > 0.05 ? "▲" : delta < -0.05 ? "▼" : "■"} {delta > 0 ? "+" : ""}
            {delta.toFixed(1)}
            {sep}
            {unit} over {n} readings
          </span>
        )}
      </div>
    </div>
  );
}

// Presets for the three metrics shown in the panel
const PERCENT = [0, 100];

export const TemperatureTrend = ({ label = "Temperature", values }) => (
  <MetricTrend label={label} values={values} unit="°C" axisTitle="Temperature (°C)" />
);

export const CpuTrend = ({ label = "CPU utilisation", values }) => (
  <MetricTrend label={label} values={values} unit="%" axisTitle="CPU (%)" range={PERCENT} />
);

export const MemoryTrend = ({ label = "Memory utilisation", values }) => (
  <MetricTrend label={label} values={values} unit="%" axisTitle="Memory (%)" range={PERCENT} />
);
