import * as THREE from "three";
import { LED_X, PORT_COUNT, PORT_SIZE, SERVER_WIDTH, U, hashString, portX } from "./rackGeometry";

// All decals are drawn on canvases at runtime: no image downloads, no real vendor branding.
export const RACK_BRAND = "RACK·42";
export const SERVER_BRAND = "HYPER·N";

const cache = new Map();
function cached(key, make) {
  if (!cache.has(key)) cache.set(key, make());
  return cache.get(key);
}

function canvasTexture(width, height, draw, { srgb = true } = {}) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  draw(canvas.getContext("2d"), width, height);
  const texture = new THREE.CanvasTexture(canvas);
  if (srgb) texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function barcode(g, str, x, y, w, h) {
  let seed = hashString(str) * 1e4;
  let cx = x;
  g.fillStyle = "#111";
  while (cx < x + w) {
    seed = (seed * 9301 + 49297) % 233280;
    const bar = 1 + Math.floor((seed / 233280) * 3);
    g.fillRect(cx, y, bar, h);
    cx += bar + 1 + Math.floor(((seed * 7) % 233280) / 233280 * 3);
  }
}

// Raised-floor grille tile: metal frame with a grid of square cooling holes.
// Returns a color map and a matching bump map; caller sets repeat.
export function grilleTextures(holes) {
  const size = 512;
  const border = 26;
  const pitch = (size - border * 2) / holes;
  const hole = pitch * 0.64;

  const drawTile = (g, frame, seam, holeFill, bevel) => {
    g.fillStyle = seam;
    g.fillRect(0, 0, size, size);
    g.fillStyle = frame;
    g.fillRect(4, 4, size - 8, size - 8);
    if (bevel) {
      g.fillStyle = "rgba(255,255,255,0.10)";
      g.fillRect(4, 4, size - 8, 4);
      g.fillRect(4, 4, 4, size - 8);
      g.fillStyle = "rgba(0,0,0,0.18)";
      g.fillRect(4, size - 8, size - 8, 4);
      g.fillRect(size - 8, 4, 4, size - 8);
    }
    g.fillStyle = holeFill;
    for (let i = 0; i < holes; i++) {
      for (let j = 0; j < holes; j++) {
        const x = border + i * pitch + (pitch - hole) / 2;
        const y = border + j * pitch + (pitch - hole) / 2;
        g.fillRect(x, y, hole, hole);
      }
    }
  };

  const map = canvasTexture(size, size, (g) => drawTile(g, "#8e959e", "#3b4047", "#0d0f12", true));
  const bump = canvasTexture(size, size, (g) => drawTile(g, "#ffffff", "#606060", "#000000", false), { srgb: false });
  for (const t of [map, bump]) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return { map, bump };
}

const PX_PER_M = 1600;

// Server front: ears, status LED bezels, brand, vents or drive bays, name sticker, RJ45 ports
export function faceplateTexture(server) {
  const key = `face|${server.name}|${server.hostname}|${server.heightU}`;
  return cached(key, () => {
    const W = Math.round(SERVER_WIDTH * PX_PER_M);
    const H = Math.max(48, Math.round((server.heightU * U - 0.004) * PX_PER_M));
    const X = (m) => (m + SERVER_WIDTH / 2) * PX_PER_M;
    const S = (m) => m * PX_PER_M;

    return canvasTexture(W, H, (g) => {
      const bg = g.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, "#3a3e45");
      bg.addColorStop(1, "#26292e");
      g.fillStyle = bg;
      g.fillRect(0, 0, W, H);

      // Rack ears with screws
      g.fillStyle = "#1c1e22";
      g.fillRect(0, 0, S(0.018), H);
      g.fillRect(W - S(0.018), 0, S(0.018), H);
      g.fillStyle = "#8a9099";
      for (const x of [S(0.009), W - S(0.009)]) {
        g.beginPath();
        g.arc(x, H / 2, S(0.003), 0, Math.PI * 2);
        g.fill();
      }

      // LED bezels (the lit LEDs are 3D meshes on top)
      g.fillStyle = "#0b0c0e";
      for (const x of LED_X) {
        g.beginPath();
        g.arc(X(x), H / 2, S(0.0042), 0, Math.PI * 2);
        g.fill();
      }

      // Brand
      g.fillStyle = "#c9ced6";
      g.font = `bold ${Math.min(H * 0.32, 22)}px Arial, sans-serif`;
      g.textBaseline = "middle";
      g.fillText(SERVER_BRAND, X(LED_X[1] + 0.014), H / 2);

      // Vents (1U) or drive bays (2U+)
      const vx0 = X(-0.115);
      const vx1 = X(0.07);
      if (server.heightU >= 2) {
        const rows = server.heightU >= 4 ? 4 : 2;
        const cols = 6;
        const bw = (vx1 - vx0) / cols;
        const bh = (H - 12) / rows;
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            const x = vx0 + c * bw;
            const y = 6 + r * bh;
            g.fillStyle = "#1a1c20";
            g.fillRect(x + 2, y + 2, bw - 4, bh - 4);
            g.fillStyle = "#4a4f57";
            g.fillRect(x + 4, y + bh / 2 - 1, bw - 8, 2); // tray handle
            g.fillStyle = "#3fae5a";
            g.fillRect(x + bw - 9, y + 5, 3, 3); // bay LED
          }
        }
      } else {
        g.fillStyle = "#111316";
        const step = 9;
        for (let x = vx0; x < vx1; x += step) {
          for (let y = 8; y < H - 8; y += step) g.fillRect(x, y, 5, 5);
        }
      }

      // Name sticker with barcode
      const lx = X(0.078);
      const lw = S(0.07);
      const lh = Math.min(H - 10, S(0.03));
      const ly = (H - lh) / 2;
      g.fillStyle = "#f4f4f0";
      g.fillRect(lx, ly, lw, lh);
      g.fillStyle = "#111";
      g.font = `bold ${Math.min(lh * 0.42, 18)}px Arial, sans-serif`;
      g.textBaseline = "top";
      g.fillText(server.name, lx + 5, ly + 3);
      if (lh > 34) barcode(g, server.name, lx + 5, ly + lh * 0.55, lw - 10, lh * 0.32);

      // RJ45 ports
      for (let i = 0; i < PORT_COUNT; i++) {
        const px = X(portX(i)) - S(PORT_SIZE[0]) / 2;
        const py = H / 2 - S(PORT_SIZE[1]) / 2;
        g.fillStyle = "#6b7079";
        g.fillRect(px - 2, py - 2, S(PORT_SIZE[0]) + 4, S(PORT_SIZE[1]) + 4);
        g.fillStyle = "#050506";
        g.fillRect(px, py, S(PORT_SIZE[0]), S(PORT_SIZE[1]));
        g.fillStyle = i % 2 ? "#e0a020" : "#3fae5a"; // link LEDs
        g.fillRect(px, py - 6, 4, 3);
      }
    });
  });
}

// Door sticker with the rack name
export function rackNameTexture(name) {
  return cached(`name|${name}`, () =>
    canvasTexture(256, 100, (g, w, h) => {
      g.fillStyle = "#f4f4f0";
      g.fillRect(0, 0, w, h);
      g.strokeStyle = "#111";
      g.lineWidth = 4;
      g.strokeRect(6, 6, w - 12, h - 12);
      g.fillStyle = "#111";
      g.font = "bold 50px Arial, sans-serif";
      g.textBaseline = "middle";
      g.fillText(name, 18, h / 2 - 8);
      g.font = "16px Arial, sans-serif";
      g.fillText("POD A · COLD AISLE", 18, h - 22);
      g.fillStyle = "#ff7a1a";
      g.fillRect(w - 34, 14, 16, h - 28);
    })
  );
}

// Brushed-metal brand plate
export function brandTexture(text) {
  return cached(`brand|${text}`, () =>
    canvasTexture(256, 64, (g, w, h) => {
      const bg = g.createLinearGradient(0, 0, w, 0);
      bg.addColorStop(0, "#9aa0a8");
      bg.addColorStop(0.5, "#d5d9de");
      bg.addColorStop(1, "#9aa0a8");
      g.fillStyle = bg;
      g.fillRect(0, 0, w, h);
      g.fillStyle = "#1b1d21";
      g.font = "bold 34px Arial, sans-serif";
      g.textAlign = "center";
      g.textBaseline = "middle";
      g.fillText(text, w / 2, h / 2 + 2);
    })
  );
}

// Asset tag sticker for rack side panels
export function assetTagTexture(id) {
  return cached(`asset|${id}`, () =>
    canvasTexture(256, 116, (g, w, h) => {
      g.fillStyle = "#e9ebee";
      g.fillRect(0, 0, w, h);
      g.fillStyle = "#1f5fd6";
      g.fillRect(0, 0, w, 26);
      g.fillStyle = "#fff";
      g.font = "bold 16px Arial, sans-serif";
      g.textBaseline = "middle";
      g.fillText("ASSET TAG · PROPERTY OF DC-EAST", 10, 14);
      g.fillStyle = "#111";
      g.font = "bold 22px Arial, sans-serif";
      g.fillText(`${id}-${Math.floor(hashString(id) * 90000 + 10000)}`, 10, 44);
      barcode(g, id, 10, 62, w - 20, 44);
    })
  );
}
