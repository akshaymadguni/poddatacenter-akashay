import * as THREE from "three";

// Temperature (°C) → color stops: cold blue → yellow → orange → hot red
export const THERMAL_STOPS = [
  [20, "#2f6bff"],
  [50, "#ffd400"],
  [68, "#ff8a00"],
  [85, "#ff2020"],
];
export const AMBIENT_TEMP = THERMAL_STOPS[0][0]; // empty rack levels read as cold

const stops = THERMAL_STOPS.map(([t, c]) => [t, new THREE.Color(c)]);

export function tempColor(t, target = new THREE.Color()) {
  if (t <= stops[0][0]) return target.copy(stops[0][1]);
  for (let i = 1; i < stops.length; i++) {
    const [t1, c1] = stops[i];
    if (t <= t1) {
      const [t0, c0] = stops[i - 1];
      return target.copy(c0).lerp(c1, (t - t0) / (t1 - t0));
    }
  }
  return target.copy(stops[stops.length - 1][1]);
}

const SPREAD = 0.06; // meters of heat bleed above/below each server

// Rack temperature at height y: each server heats its own level and fades out around it
export function rackProfile(points) {
  return (y) =>
    points.reduce((t, p) => {
      const d = Math.max(0, Math.abs(y - p.y) - p.half);
      const w = Math.exp(-(d * d) / (2 * SPREAD * SPREAD));
      return Math.max(t, AMBIENT_TEMP + (p.temp - AMBIENT_TEMP) * w);
    }, AMBIENT_TEMP);
}

// Vertical gradient texture; v = 0 at the rack floor, v = 1 at its top
export function thermalTexture(profile, height, rows = 256) {
  const canvas = document.createElement("canvas");
  canvas.width = 1;
  canvas.height = rows;
  const g = canvas.getContext("2d");
  const color = new THREE.Color();
  for (let i = 0; i < rows; i++) {
    const y = height * (1 - (i + 0.5) / rows); // canvas row 0 is the top
    g.fillStyle = `#${tempColor(profile(y), color).getHexString()}`;
    g.fillRect(0, i, 1, 1);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export const LEGEND_GRADIENT = `linear-gradient(90deg, ${THERMAL_STOPS.map(
  ([t, c]) => `${c} ${((t - AMBIENT_TEMP) / (THERMAL_STOPS.at(-1)[0] - AMBIENT_TEMP)) * 100}%`
).join(", ")})`;
