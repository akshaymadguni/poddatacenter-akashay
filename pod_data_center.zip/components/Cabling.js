import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { RACK } from "./rackGeometry";

// Every other cable size derives from these two (bundle 1.4x, power 1.3x the bundle)
export const CABLE_RADIUS = 0.0045;
export const PATCH_RADIUS = 0.00175; // short server-to-server patch leads
export const BUNDLE_RADIUS = CABLE_RADIUS * 1.4;
export const BUNDLE_Y = RACK.height + 1.5; // center network bundle, 1.5 m above the rack tops
export const TRAY_RISE = 0.28; // row tray floor height above the rack tops
export const TRAY_OFFSET = -0.25; // row tray sits over the rear half of each rack (rack-local z)
export const SERVER_CABLE_COLORS = ["#2f7bff", "#202226", "#202226", "#e5484d"];

// Power line: live / neutral / earth, running just above the network bundle
export const POWER_COLORS = ["#c62828", "#1f5fd6", "#202226"];
export const POWER_RADIUS = BUNDLE_RADIUS * 1.3;
export const POWER_Y = BUNDLE_Y + 0.22;
const POWER_SPACING = POWER_RADIUS * 2.3;
export const POWER_HALF_WIDTH = POWER_SPACING * 1.5;

const BUNDLE_COLORS = ["#2f7bff", "#202226", "#202226", "#e5484d", "#2f7bff", "#202226", "#202226", "#202226"];
const BUNDLE_SPACING = BUNDLE_RADIUS * 2.15;
export const BUNDLE_HALF_WIDTH = BUNDLE_SPACING * 2;

// One PVC-jacket material per color, shared by every cable
const materials = new Map();
function cableMaterial(color) {
  if (!materials.has(color)) {
    materials.set(
      color,
      new THREE.MeshPhysicalMaterial({ color, roughness: 0.42, metalness: 0, clearcoat: 0.35, clearcoatRoughness: 0.5 })
    );
  }
  return materials.get(color);
}

// Galvanized steel
const trayMaterial = new THREE.MeshPhysicalMaterial({ color: "#8d939b", metalness: 0.75, roughness: 0.38 });

const noRaycast = () => null;

export function Cable({ points, color, radius = CABLE_RADIUS, segments = 40 }) {
  const geometry = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(...p)));
    return new THREE.TubeGeometry(curve, segments, radius, 6, false);
  }, [points, radius, segments]);

  useEffect(() => () => geometry.dispose(), [geometry]);

  // Cables ignore pointer events so they never steal clicks from racks
  return <mesh geometry={geometry} material={cableMaterial(color)} raycast={noRaycast} />;
}

// Open cable tray running along z, hung from rods that disappear into the dark above
export function Tray({ x, y, from, to, width }) {
  const length = to - from;
  const z = (from + to) / 2;
  const hangers = [];
  for (let hz = from + 0.5; hz < to; hz += 1.5) hangers.push(hz);

  return (
    <group position={[x, y, z]}>
      <mesh material={trayMaterial} raycast={noRaycast}>
        <boxGeometry args={[width, 0.01, length]} />
      </mesh>
      {[-1, 1].map((s) => (
        <mesh key={s} position={[(s * width) / 2, 0.03, 0]} material={trayMaterial} raycast={noRaycast}>
          <boxGeometry args={[0.01, 0.06, length]} />
        </mesh>
      ))}
      {hangers.flatMap((hz) =>
        [-1, 1].map((s) => (
          <mesh key={`${hz}${s}`} position={[(s * width) / 2, 2, hz - z]} material={trayMaterial} raycast={noRaycast}>
            <cylinderGeometry args={[0.006, 0.006, 4, 6]} />
          </mesh>
        ))
      )}
    </group>
  );
}

function StraightRun({ colors, radius, spacing, y, perRow, length }) {
  const cables = useMemo(
    () =>
      colors.map((color, i) => {
        const x = ((i % perRow) - (perRow - 1) / 2) * spacing;
        const cy = y + Math.floor(i / perRow) * spacing;
        return { color, points: [[x, cy, -length / 2], [x, cy, length / 2]] };
      }),
    [colors, perRow, spacing, y, length]
  );
  return cables.map((c, i) => <Cable key={i} points={c.points} color={c.color} radius={radius} segments={1} />);
}

// Central wiring over the cold aisle: 8 thick network cables, with the power line above them
export function AisleBundle({ length }) {
  return (
    <group>
      <Tray x={0} y={BUNDLE_Y - BUNDLE_RADIUS - 0.006} from={-length / 2} to={length / 2} width={BUNDLE_HALF_WIDTH * 2 + 0.03} />
      <StraightRun colors={BUNDLE_COLORS} radius={BUNDLE_RADIUS} spacing={BUNDLE_SPACING} y={BUNDLE_Y} perRow={4} length={length} />

      <Tray x={0} y={POWER_Y - POWER_RADIUS - 0.006} from={-length / 2} to={length / 2} width={POWER_HALF_WIDTH * 2 + 0.03} />
      <StraightRun colors={POWER_COLORS} radius={POWER_RADIUS} spacing={POWER_SPACING} y={POWER_Y} perRow={3} length={length} />
    </group>
  );
}

// A few patch cables linking neighbouring racks through the row tray (world space)
export function RackLinks({ x, rackTop, zs }) {
  const trayY = rackTop + TRAY_RISE + 0.03;
  const links = useMemo(() => {
    const sorted = [...zs].sort((a, b) => a - b);
    const out = [];
    for (let i = 0; i < sorted.length - 1; i++) {
      const [z1, z2] = [sorted[i], sorted[i + 1]];
      ["#202226", "#202226", "#2f7bff"].forEach((color, k) => {
        const cx = x + (k - 1) * 0.06;
        out.push({
          color,
          points: [
            [cx, rackTop, z1],
            [cx, trayY - 0.05, z1 + 0.08],
            [cx, trayY, z1 + 0.25],
            [cx, trayY, z2 - 0.25],
            [cx, trayY - 0.05, z2 - 0.08],
            [cx, rackTop, z2],
          ],
        });
      });
    }
    return out;
  }, [x, rackTop, trayY, zs]);

  return links.map((l, i) => <Cable key={i} points={l.points} color={l.color} />);
}
