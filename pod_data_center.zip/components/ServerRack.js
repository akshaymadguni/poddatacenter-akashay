import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Edges } from "@react-three/drei";
import * as THREE from "three";
import { rackHealth } from "./health";
import { latestTemp } from "./temperature";
import {
  BUNDLE_HALF_WIDTH,
  BUNDLE_Y,
  Cable,
  PATCH_RADIUS,
  POWER_COLORS,
  POWER_HALF_WIDTH,
  POWER_RADIUS,
  POWER_Y,
  SERVER_CABLE_COLORS,
  TRAY_OFFSET,
  TRAY_RISE,
} from "./Cabling";
import {
  DRAWER_OUT,
  PANEL,
  RACK,
  SERVER_FRONT_Z,
  SERVER_WIDTH,
  STATUS_COLORS,
  U,
  portX,
  serverCenterY,
} from "./rackGeometry";
import Server from "./Server";
import { RACK_BRAND, assetTagTexture, brandTexture, rackNameTexture } from "./textures";
import { rackProfile, tempColor, thermalTexture } from "./thermal";

export { RACK, STATUS_COLORS };

const DOOR_OPEN_ANGLE = -1.9; // ~110°, swings outward
// Door frame glow when open. Kept modest: at high intensity the orange's green channel blows
// out under tone mapping + bloom and the rim reads yellow.
const GLOW = 1.5;
const POWER_INLET = [-RACK.width / 2 + 0.09, RACK.height, 0.18]; // top-mounted power inlet box

const hardwareMaterial = new THREE.MeshPhysicalMaterial({ color: "#2a2d32", metalness: 0.6, roughness: 0.4 });
const noRaycast = () => null;

function setCursor(value) {
  document.body.style.cursor = value;
}

function Decal({ texture, size, ...props }) {
  return (
    <mesh {...props} raycast={noRaycast}>
      <planeGeometry args={size} />
      <meshPhysicalMaterial map={texture} roughness={0.6} metalness={0} clearcoat={0.4} />
    </mesh>
  );
}

// 4 cables per server: up the rear of the rack, out the top, through the row tray,
// then sagging across to the center bundle over the cold aisle (rack-local space)
function ServerCables({ servers, rackU, aisleOffset }) {
  const cables = useMemo(() => {
    const { depth, height } = RACK;
    const rearZ = -depth / 2 + PANEL + 0.012;
    const trayY = height + TRAY_RISE + 0.03;
    const landZ = aisleOffset - BUNDLE_HALF_WIDTH - 0.01;
    return servers.flatMap((server, si) => {
      const y = serverCenterY(server, rackU);
      return SERVER_CABLE_COLORS.map((color, ci) => {
        const x = (ci - 1.5) * 0.055 + ((si % 3) - 1) * 0.012;
        const z = rearZ + (si % 2) * 0.008;
        return {
          key: `${server.id}-${ci}`,
          color,
          points: [
            [x, y, z],
            [x, height - 0.06, z],
            [x, height + 0.1, z + 0.06],
            [x * 0.85, trayY, TRAY_OFFSET],
            [x * 0.7, (trayY + BUNDLE_Y) / 2 - 0.2, (TRAY_OFFSET + landZ) / 2],
            [x * 0.6, BUNDLE_Y + BUNDLE_HALF_WIDTH / 4, landZ],
          ],
        };
      });
    });
  }, [servers, rackU, aisleOffset]);

  return cables.map((c) => <Cable key={c.key} points={c.points} color={c.color} />);
}

// Front patch leads daisy-chaining neighbouring servers (port 1 → next server's port 2),
// routed through the side cable channel. A pulled-out server drags its leads with it.
function PatchCables({ servers, rackU, selectedServerId }) {
  const cables = useMemo(() => {
    const sorted = [...servers].sort((a, b) => a.uPosition - b.uPosition);
    const sideX = SERVER_WIDTH / 2 + 0.01;
    const frontZ = (s) => SERVER_FRONT_Z + 0.002 + (s.id === selectedServerId ? DRAWER_OUT : 0);
    return sorted.slice(1).map((b, i) => {
      const a = sorted[i];
      const [ya, yb] = [serverCenterY(a, rackU), serverCenterY(b, rackU)];
      const [za, zb] = [frontZ(a), frontZ(b)];
      const [xa, xb] = [portX(0), portX(1)];
      const loopZ = Math.max(za, zb) + 0.022;
      return {
        key: `${a.id}-${b.id}`,
        color: i % 2 ? "#202226" : "#2f7bff",
        points: [
          [xa, ya, za],
          [xa, ya, za + 0.03],
          [sideX, ya, loopZ],
          [sideX, yb, loopZ],
          [xb, yb, zb + 0.03],
          [xb, yb, zb],
        ],
      };
    });
  }, [servers, rackU, selectedServerId]);

  return cables.map((c) => <Cable key={c.key} points={c.points} color={c.color} radius={PATCH_RADIUS} segments={32} />);
}

// Live / neutral / earth from the top inlet up to the central power line
function PowerDrop({ aisleOffset }) {
  const wires = useMemo(() => {
    const [ix, iy, iz] = POWER_INLET;
    const landZ = aisleOffset - POWER_HALF_WIDTH - 0.01;
    return POWER_COLORS.map((color, k) => {
      const x = ix + (k - 1) * 0.024;
      return {
        color,
        points: [
          [x, iy + 0.04, iz],
          [x, iy + 0.35, iz + 0.05],
          [x * 0.6, (iy + POWER_Y) / 2 + 0.05, (iz + landZ) / 2],
          [(k - 1) * 0.03, POWER_Y, landZ],
        ],
      };
    });
  }, [aisleOffset]);

  return wires.map((w, i) => <Cable key={i} points={w.points} color={w.color} radius={POWER_RADIUS * 0.7} />);
}

function GlassDoor({ name, working, open, onToggle }) {
  const { width, height, depth } = RACK;
  const pivot = useRef();
  const [hovered, setHovered] = useState(false);

  const frame = 0.035;
  const thickness = 0.02;

  // Shared by all four frame bars so the glow animates as one
  const frameMaterial = useMemo(
    () =>
      new THREE.MeshPhysicalMaterial({
        color: "#1a1c20",
        metalness: 0.7,
        roughness: 0.35,
        clearcoat: 0.3,
        emissive: "#ff5200", // deep orange: stays orange (not yellow) when bloomed
        emissiveIntensity: 0,
        toneMapped: false,
      }),
    []
  );
  useEffect(() => () => frameMaterial.dispose(), [frameMaterial]);

  useFrame((_, delta) => {
    pivot.current.rotation.y = THREE.MathUtils.damp(pivot.current.rotation.y, open ? DOOR_OPEN_ANGLE : 0, 6, delta);
    frameMaterial.emissiveIntensity = THREE.MathUtils.damp(frameMaterial.emissiveIntensity, open ? GLOW : 0, 6, delta);
  });

  const statusColor = working ? "#39ff7a" : "#ff3030";

  return (
    // Hinge on the left front edge; door geometry extends along +x from it
    <group ref={pivot} position={[-width / 2, height / 2, depth / 2 + thickness / 2]}>
      <group position={[width / 2, 0, 0]}>
        {[
          [0, height / 2 - frame / 2, width, frame],
          [0, -height / 2 + frame / 2, width, frame],
          [-width / 2 + frame / 2, 0, frame, height],
          [width / 2 - frame / 2, 0, frame, height],
        ].map(([x, y, w, h], i) => (
          <mesh key={i} position={[x, y, 0]} material={frameMaterial}>
            <boxGeometry args={[w, h, thickness]} />
          </mesh>
        ))}

        {/* Glass */}
        <mesh>
          <boxGeometry args={[width - frame * 2, height - frame * 2, 0.006]} />
          <meshPhysicalMaterial
            color="#a8d8ff"
            transparent
            opacity={0.16}
            roughness={0.04}
            metalness={0}
            clearcoat={1}
            ior={1.5}
            depthWrite={false}
          />
        </mesh>

        {/* Rack status LED, top-right of the rim */}
        <mesh position={[width / 2 - frame / 2, height / 2 - frame / 2, thickness / 2 + 0.002]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.006, 0.006, 0.004, 16]} />
          <meshStandardMaterial color={statusColor} emissive={statusColor} emissiveIntensity={4} toneMapped={false} />
        </mesh>

        {/* Stickers: name on the glass, brand plate on the bottom rail */}
        <Decal texture={rackNameTexture(name)} size={[0.13, 0.05]} position={[-width / 2 + frame + 0.08, height / 2 - frame - 0.045, 0.0035]} />
        <Decal texture={brandTexture(RACK_BRAND)} size={[0.12, 0.03]} position={[0, -height / 2 + frame / 2, thickness / 2 + 0.001]} />

        {/* Handle */}
        <mesh
          position={[width / 2 - frame - 0.03, 0, thickness / 2 + 0.02]}
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
          onPointerOver={(e) => {
            e.stopPropagation();
            setHovered(true);
            setCursor("pointer");
          }}
          onPointerOut={() => {
            setHovered(false);
            setCursor("auto");
          }}
        >
          <boxGeometry args={[0.025, 0.3, 0.03]} />
          <meshPhysicalMaterial color={hovered ? "#4da3ff" : "#c9ccd1"} metalness={0.9} roughness={0.22} clearcoat={0.5} />
        </mesh>
      </group>
    </group>
  );
}

// Top-of-rack hardware: power inlet, brush cable entry, leveling feet
function RackHardware() {
  const { width, depth, height } = RACK;
  return (
    <group>
      <mesh position={[POWER_INLET[0], height + 0.02, POWER_INLET[2]]} material={hardwareMaterial}>
        <boxGeometry args={[0.1, 0.04, 0.08]} />
      </mesh>
      <mesh position={[0, height + 0.015, -depth / 2 + 0.07]} material={hardwareMaterial}>
        <boxGeometry args={[0.32, 0.03, 0.09]} />
      </mesh>
      {[-1, 1].flatMap((sx) =>
        [-1, 1].map((sz) => (
          <mesh
            key={`${sx}${sz}`}
            position={[sx * (width / 2 - 0.05), -0.015, sz * (depth / 2 - 0.06)]}
            material={hardwareMaterial}
          >
            <cylinderGeometry args={[0.025, 0.03, 0.03, 12]} />
          </mesh>
        ))
      )}
    </group>
  );
}

// Local space: door faces +z, rack sits on y = 0
export default function ServerRack({
  rack,
  open, // controlled by the parent so only one rack is open at a time
  selectedServerId,
  onOpen,
  onClose,
  onSelectServer,
  aisleOffset, // distance from the rack's center to the cold aisle centerline
  thermal = false,
  ...props
}) {
  const { width, depth, height } = RACK;
  const rackU = rack.totalU ?? 42;
  const health = rackHealth(rack);

  // Thermal view: panels show a vertical blue → yellow → orange → red gradient built from the
  // servers' temperatures in pod-data.json, so hot levels show where they are
  const heat = useMemo(() => {
    if (!thermal) return null;
    const profile = rackProfile(
      rack.servers.map((s) => ({ y: serverCenterY(s, rackU), half: (s.heightU * U) / 2, temp: latestTemp(s.temperature) }))
    );
    return {
      map: thermalTexture(profile, height),
      bottom: tempColor(profile(0)),
      top: tempColor(profile(height)),
    };
  }, [thermal, rack.servers, rackU, height]);

  useEffect(() => () => heat?.map.dispose(), [heat]);

  // Normal view: the original powder-coated steel. Thermal view: unlit heat colours, with the
  // gradient on the side/back panels and the solid colour at that level on top/bottom.
  // In thermal view each panel also gets a black outline, like the servers, so racks stay readable
  const panelMaterial = (color) =>
    heat ? (
      <>
        <meshBasicMaterial map={color ? null : heat.map} color={color ?? "#ffffff"} />
        <Edges color="#000000" />
      </>
    ) : (
      <meshPhysicalMaterial color="#16181c" metalness={0.55} roughness={0.48} clearcoat={0.3} clearcoatRoughness={0.55} />
    );

  const toggleDoor = () => (open ? onClose(rack.id) : onOpen(rack.id));

  return (
    // Click anywhere on the rack to toggle its door: a closed rack opens (closing any other open
    // rack) and is selected; an open rack closes. A double-click always ends closed, whatever
    // its two clicks toggled. Handle and open-door server clicks stop propagation.
    <group
      {...props}
      onClick={(e) => {
        e.stopPropagation();
        toggleDoor();
      }}
      onDoubleClick={(e) => {
        e.stopPropagation();
        onClose(rack.id);
      }}
    >
      {/* Sides, each with an asset tag near the top front */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <mesh position={[s * (width / 2 - PANEL / 2), height / 2, 0]}>
            <boxGeometry args={[PANEL, height, depth]} />
            {panelMaterial()}
          </mesh>
          {!thermal && (
            <Decal
              texture={assetTagTexture(rack.id)}
              size={[0.1, 0.045]}
              position={[s * (width / 2 + 0.0008), height - 0.2, depth / 2 - 0.12]}
              rotation={[0, (s * Math.PI) / 2, 0]}
            />
          )}
        </group>
      ))}
      {/* Top & bottom: solid color of the temperature at that level */}
      {[
        [PANEL / 2, heat?.bottom],
        [height - PANEL / 2, heat?.top],
      ].map(([y, color]) => (
        <mesh key={y} position={[0, y, 0]}>
          <boxGeometry args={[width, PANEL, depth]} />
          {panelMaterial(color)}
        </mesh>
      ))}
      {/* Back */}
      <mesh position={[0, height / 2, -depth / 2 + PANEL / 2]}>
        <boxGeometry args={[width, height, PANEL]} />
        {panelMaterial()}
      </mesh>

      <RackHardware />

      {rack.servers.map((server) => (
        <Server
          key={server.id}
          server={server}
          rackU={rackU}
          out={selectedServerId === server.id}
          interactive={open}
          thermal={thermal}
          onSelect={() => onSelectServer(rack.id, server.id)}
        />
      ))}

      <PatchCables servers={rack.servers} rackU={rackU} selectedServerId={selectedServerId} />
      <ServerCables servers={rack.servers} rackU={rackU} aisleOffset={aisleOffset} />
      <PowerDrop aisleOffset={aisleOffset} />

      <GlassDoor name={rack.name} working={health.level !== "alert"} open={open} onToggle={toggleDoor} />
    </group>
  );
}
