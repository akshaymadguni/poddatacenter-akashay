import { readFile } from "fs/promises";
import { POD_DATA_FILE } from "@/lib/podFile";

// Reads the file on every request so edits show up without a rebuild
export default async function handler(req, res) {
  try {
    const text = await readFile(POD_DATA_FILE, "utf8");
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Type", "application/json");
    res.status(200).send(text);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
