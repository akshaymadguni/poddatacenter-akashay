import { readFile, writeFile } from "fs/promises";
import seedPod, { reseedPod } from "@/lib/seedPod";
import { POD_DATA_FILE } from "@/lib/podFile";

// Re-randomises the live readings in public/pod-data.json (statuses, temperatures, power)
// while keeping the layout fixed. Falls back to a brand-new pod if the file is missing or invalid.
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  try {
    let current = null;
    try {
      current = JSON.parse(await readFile(POD_DATA_FILE, "utf8"));
    } catch {
      // no usable file yet: generate a full pod below
    }
    const data = current?.pod?.racks?.length ? reseedPod(current) : seedPod();
    await writeFile(POD_DATA_FILE, JSON.stringify(data, null, 2) + "\n");
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
