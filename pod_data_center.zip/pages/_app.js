import { Inter, JetBrains_Mono } from "next/font/google";
import "@/styles/globals.css";

// Inter for all interface text, JetBrains Mono for data values (IPs, IDs, readings).
// Both are variable fonts, so no weight list is needed.
const ui = Inter({ subsets: ["latin"], variable: "--font-ui" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

export default function App({ Component, pageProps }) {
  return (
    <div className={`${ui.variable} ${mono.variable}`} style={{ height: "100%" }}>
      <Component {...pageProps} />
    </div>
  );
}
